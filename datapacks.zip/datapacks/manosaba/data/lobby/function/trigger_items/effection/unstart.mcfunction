#advancement reset
advancement revoke @s only lobby:unstart
#return
execute if score manosaba:data Gaming matches 1 run return fail
execute if score manosaba:data lobby_minus matches 0 run return fail
#sound
stopsound @a
execute as @a at @s run playsound ui.cartography_table.take_result ambient @a ~ ~ ~ 1 1.2

#condition
execute if score manosaba:data needAdmin matches 1 unless score @s isAdmin matches 1 run return run tellraw @s [{text:"*  ",color:white,italic:false},{text:"请确认你具备命令权限再进行操作\n",color:gold,italic:true},{text:"【我确认】",color:green,bold:true,italic:false,underlined:true,click_event:{action:"run_command",command:"/function lobby:trigger_items/effection/permission_check"}}]

#text
tellraw @a [{text:"*  ",color:white,italic:false},{text:"倒计时被取消",color:red,italic:true},{text:"    *操作者:",color:gray,italic:true},{selector:"@s",color:gray,italic:true},{text:"*",color:gray,italic:true}]

#item
function lobby:trigger_items/item/start
execute as @a[gamemode=!creative] run function lobby:trigger_items/item/start

#minus kill
schedule clear lobby:game_start/minus_progress
scoreboard players set #lobby:start lobby_minus 0

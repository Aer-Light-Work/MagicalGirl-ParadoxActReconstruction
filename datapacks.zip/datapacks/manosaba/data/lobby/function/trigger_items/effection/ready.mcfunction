#advancement reset
advancement revoke @s only lobby:ready
#return
execute if score manosaba:data Gaming matches 1 run return fail
execute if score @s tutorialT matches 1.. run return fail
##msg
#calc
execute as @a run scoreboard players add #lobby:online alive 1
execute as @a[scores={ready=1}] run scoreboard players add #lobby:readycheck alive 1
#score
execute unless score #lobby:readycheck alive matches 20.. run execute if score manosaba:data Gaming matches 0 run scoreboard players set @s ready 1
#ready display
execute as @a[scores={ready=1}] run scoreboard players add #lobby:ready alive 1
#player max
execute if score #lobby:readycheck alive matches 20.. run return run function lobby:trigger_items/effection/ready_fail_max
#msg
tellraw @a [{text:"*  ",color:white,bold:false,italic:false},{text:"玩家 ",color:gold,bold:false,italic:false},{selector:"@s",color:yellow,bold:true,italic:false},{text:" 将参演本场 ",color:gold,bold:false,italic:false},{text:"『囚庭演定』",color:"#ED777F",italic:true,bold:true},{text:" ...  ",color:gold,bold:false,italic:false},{text:" [ ",color:gray,bold:false,italic:true},{score:{name:"#lobby:ready",objective:"alive"},color:green,bold:false,italic:true},{text:" / ",color:gray,bold:false,italic:true},{score:{name:"#lobby:online",objective:"alive"},color:white,bold:false,italic:true},{text:"  ]",color:gray,bold:false,italic:true}]
#score reset
scoreboard players set #lobby:online alive 0
scoreboard players set #lobby:readycheck alive 0
scoreboard players set #lobby:ready alive 0

#sound
execute at @s run playsound block.rooted_dirt.break ambient @a ~ ~ ~ 1 2
execute at @s run playsound block.suspicious_gravel.break ambient @a ~ ~ ~ 0.3 2
execute at @s run playsound block.moss.break ambient @a ~ ~ ~ 1 2
execute at @s run playsound block.note_block.pling ambient @s ~ ~ ~ 0.5 2
execute as @a at @s run playsound ui.button.click ambient @s ~ ~ ~ 0.5 1.75
#item
function lobby:trigger_items/item/unready

#title
title @s times 10 70 20
title @s title ""
title @s subtitle [{text:"你将参演本场 ",color:gold},{text:"『囚庭演定』",color:"#ED777F",italic:false,bold:true},{text:" ...",color:gold}]
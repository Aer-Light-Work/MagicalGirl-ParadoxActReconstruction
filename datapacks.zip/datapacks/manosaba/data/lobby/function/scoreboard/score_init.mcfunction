#start_minus
scoreboard objectives add lobby_minus dummy

#tutorial offline exit
scoreboard objectives add tutorialTrecord dummy

#hub
scoreboard objectives add hub trigger

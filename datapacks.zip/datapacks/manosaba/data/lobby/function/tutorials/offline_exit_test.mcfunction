##自调用组件

#test
execute as @a[scores={tutorialT=1..}] unless score @s tutorialTrecord matches 0 if score @s tutorialT = @s tutorialTrecord run function manosaba:spectator/spectator_hub

#record
execute as @a[scores={tutorialT=1..}] run scoreboard players operation @s tutorialTrecord = @s tutorialT

#zdy
execute if score manosaba:data Gaming matches 0 run schedule function lobby:tutorials/offline_exit_test 4s
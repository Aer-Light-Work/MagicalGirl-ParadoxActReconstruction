##stat记录最新的受伤类型 damage记录受到该类型伤害的总值

##凭单次伤害值决定程度的伤害：
#坠落伤状态记录
scoreboard objectives add fall_stat dummy
scoreboard objectives add fall_degree dummy
#玩家伤害状态
scoreboard objectives add playerdmg_stat dummy
scoreboard objectives add playerdmg_degree dummy
#动能(弹射物)伤害状态
scoreboard objectives add projectile_stat dummy
scoreboard objectives add projectile_degree dummy
#爆炸伤害状态
scoreboard objectives add explode_stat dummy
scoreboard objectives add explode_degree dummy
##能够凭伤害次数决定程度的伤害：
#烧烫伤状态
scoreboard objectives add burn_stat dummy
scoreboard objectives add burn_degree dummy
#冻伤状态
scoreboard objectives add freeze_stat dummy
scoreboard objectives add freeze_degree dummy
#溺水状态
scoreboard objectives add drown_stat dummy
scoreboard objectives add drown_degree dummy
scoreboard objectives add isDrowning dummy
#窒息状态
scoreboard objectives add inwall_stat dummy
scoreboard objectives add inwall_degree dummy
scoreboard objectives add isInwalling dummy
#触电状态
scoreboard objectives add shock_stat dummy
scoreboard objectives add shock_degree dummy
#其它伤害
scoreboard objectives add other_stat dummy
scoreboard objectives add other_degree dummy

#流血伤害
scoreboard objectives add bleed_stat dummy
scoreboard objectives add bleed_degree dummy
#失血程度
scoreboard objectives add hemorrhagic_degree dummy
#流血计时
scoreboard objectives add bleed_minus dummy

#blunt
scoreboard objectives add blunt_stat dummy
scoreboard objectives add blunt_degree dummy
scoreboard objectives add blunt_minus dummy

##受击次数
scoreboard objectives add sharpC dummy
scoreboard objectives add bluntC dummy

##血量记录
#总HP记录
scoreboard objectives add HPsave dummy
#最大生命上限
scoreboard objectives add HPmax dummy
#fall
scoreboard objectives add fall_damage dummy
#player
scoreboard objectives add player_damage dummy
#projectile
scoreboard objectives add projectile_damage dummy
#explode
scoreboard objectives add explode_damage dummy
#burn
scoreboard objectives add burn_damage dummy
#freeze
scoreboard objectives add freeze_damage dummy
#drown
scoreboard objectives add drown_damage dummy
#inwall
scoreboard objectives add inwall_damage dummy
#shock
scoreboard objectives add shock_damage dummy
#other
scoreboard objectives add other_damage dummy

#bleed
scoreboard objectives add bleed_damage dummy

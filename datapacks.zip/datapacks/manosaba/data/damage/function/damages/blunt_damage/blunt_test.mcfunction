
#unready return
execute unless entity @s[scores={ready=1,dead=0,Playing=1}] run return fail

#tag -
tag @s remove temp_blunt

#stat test
scoreboard players operation @s blunt_stat = @s playerdmg_stat
#const
scoreboard players set #blunt1 blunt_stat 5
scoreboard players set #blunt2 blunt_stat 8
scoreboard players set #blunt3 blunt_stat 10

##lv3
execute if score @s blunt_stat matches 11.. run scoreboard players set @s blunt_degree 3
execute if score @s blunt_degree matches 3 run scoreboard players operation @s blunt_stat *= #blunt1 blunt_stat
##lv2
execute if score @s blunt_stat matches 8..10 run scoreboard players set @s blunt_degree 2
execute if score @s blunt_degree matches 2 run scoreboard players operation @s blunt_stat *= #blunt2 blunt_stat
##lv1
execute if score @s blunt_stat matches 3..7 run scoreboard players set @s blunt_degree 1
execute if score @s blunt_degree matches 1 run scoreboard players operation @s blunt_stat *= #blunt3 blunt_stat
#storage stat
execute store result storage damage:blunt stat int 1.0 run scoreboard players get @s blunt_stat

#func assign
function damage:damages/blunt_damage/blunt_assign with storage damage:blunt

#score reset
scoreboard players set #bluntProb blunt_stat 0
scoreboard players set @s blunt_degree 0
#storage clear
data remove storage damage:blunt stat





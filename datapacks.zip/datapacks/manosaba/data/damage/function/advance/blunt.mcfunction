#advancement reset
advancement revoke @s only damage:blunt

#hit count add
scoreboard players add @s bluntC 1

#temp tag (+)
tag @s add temp_blunt
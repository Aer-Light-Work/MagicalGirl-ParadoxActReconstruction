##接收参数 $(slot)

#item replace
$item replace entity @s container.$(slot) from entity @s player.cursor
#cursor clear
item replace entity @s player.cursor with air

#temp tag + --阻止屏障替换
tag @s add show_clue

#storage components
$data modify storage clue:show components set from entity @s Inventory[{Slot:$(slot)b}].components
#storage name
$data modify storage clue:show name set from entity @s Inventory[{Slot:$(slot)b}].components."minecraft:custom_name"

#name
function clues:show_clue/custom_name_append with storage clue:show

#macro func
function clues:show_clue/show_clue_macro with storage clue:show

#storage clear
data remove storage clue:show components
data remove storage clue:show name
data remove storage clue:show color
$data modify storage clue:show name merge value {hover_event:{action:"show_item",id:"minecraft:short_grass",components:$(components)}}

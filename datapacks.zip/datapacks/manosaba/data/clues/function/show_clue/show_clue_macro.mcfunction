##接收参数 $(id) $(components) $(name)--custom_name $(color) -name_Color

#sound
execute as @a at @s run playsound manosaba:notice ambient @s ~ ~ ~ 0.3

#text
$tellraw @a [{text:"*  ",color:white,bold:false,italic:false},\
            {selector:"@s",color:gold,bold:false,italic:false},\
            {text:" 出示了证物:  ",color:yellow,bold:false,italic:false},\
            {text:"『",color:white,bold:false,italic:false},\
            $(name),\
            {text:"』",color:white,bold:false,italic:false},\
            {text:"  (指针悬浮以查看)",color:gray,bold:false,italic:true},\
]
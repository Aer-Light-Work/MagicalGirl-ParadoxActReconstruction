##受summon开启 自调用组件

#血污附近玩家
execute as @e[type=armor_stand,tag=blood_dropping] at @s as @a[scores={ready=1,dead=0},distance=..0.35] run function clues:api/bloody_body/bloodstain

#自身落地/落水效果
execute as @e[type=armor_stand,tag=blood_dropping] at @s if block ~ ~-0.2 ~ water positioned ~ ~ ~ run function clues:blood/drop/blood_inwater

execute as @e[type=armor_stand,tag=blood_dropping] if predicate manosaba:on_ground at @s positioned ~ ~ ~ run function clues:blood/drop/blood_onground

execute if entity @e[type=armor_stand,tag=blood_dropping] run schedule function clues:blood/drop/blood_dropping 1t
#advancement reset
advancement revoke @s only clues:sharp
advancement revoke @s only magics:1_ice/sharp

#hit count add
scoreboard players add @s sharpC 1

#temp tag (+)
tag @s add temp_sharp
#func 
execute as @s at @s run function clues:api/blood/splash/blood_splash_assign
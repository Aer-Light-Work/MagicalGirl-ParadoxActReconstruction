##组件头
#魔耗
scoreboard players remove @s MP 30
#cd
scoreboard players set @s cd1 30
scoreboard players set @s raycast_distance 0

tag @s add magic6a_listening

effect give @s minecraft:darkness 20 0 true
effect give @s minecraft:night_vision 20 0 true
effect give @s minecraft:blindness 20 0 true

schedule function magics:effection/6_listen/magic6a_80tick 1t


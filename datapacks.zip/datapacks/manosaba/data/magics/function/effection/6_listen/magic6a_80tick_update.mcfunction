execute if score @s raycast_distance matches 6.. run tag @a remove magic6a_listening
execute if score @s raycast_distance matches 6.. run return 0

playsound minecraft:entity.warden.heartbeat player @s ~ ~ ~ 0.7 1

scoreboard players add @a[distance=0.01..8,scores={magic6a_times=..6}] magic6a_times 1

execute as @a[distance=0.01..8,scores={magic6a_times=..5},gamemode=adventure] run tellraw @p[tag=magic6a_listening] [{text:"👂 "},{text:"聆听魔法中：",color:"#4169e1"},{selector:"@s",color:"#87ceeb",bold:true},{"text":"当前进度: "},{"score":{"name":"@s","objective":"magic6a_times"}},{"text":"/6"}]
execute as @a[distance=0.01..8,scores={magic6a_times=6},gamemode=adventure] run function magics:effection/6_listen/magic6a_times_6_at

scoreboard players add @s raycast_distance 1



execute if score @s raycast_distance matches 6.. run return 0

execute as @a[tag=magic6a_listening] at @s run function magics:effection/6_listen/magic6a_80tick_update
schedule function magics:effection/6_listen/magic6a_80tick 80t




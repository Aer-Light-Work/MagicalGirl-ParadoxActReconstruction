##组件头
#魔耗
scoreboard players remove @s MP 60
#cd
scoreboard players set @s cd2 120
effect give @a[distance=0.01..8] weakness 1 5 false

execute as @a[distance=0.01..8,scores={magic6a_times=6..}] run function magics:effection/6_listen/magic6b_at
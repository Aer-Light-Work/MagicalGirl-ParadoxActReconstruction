##组件头
#魔耗
scoreboard players remove @s MP 60
#cd
scoreboard players set @s cd1 30

##效果
#给予怪力标签和初始化计时器
#音效和粒子
playsound entity.lightning_bolt.thunder ambient @a ~ ~ ~ 1.0
particle electric_spark ~ ~1 ~ 0.5 0.5 0.5 0.1 10 force


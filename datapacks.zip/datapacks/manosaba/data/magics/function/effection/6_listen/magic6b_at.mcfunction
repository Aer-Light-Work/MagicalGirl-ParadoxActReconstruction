effect give @s weakness 5 5 false
particle minecraft:trial_spawner_detection ~ ~2 ~ 0.1 1 0.1 0 30 force


execute store result storage magic:data duration int 0.05 run data get entity @s active_effects[{id:"minecraft:levitation"}].duration

function magics:effection/14_gravity_control/magic14a_self/slow_falling_apply with storage magic:data
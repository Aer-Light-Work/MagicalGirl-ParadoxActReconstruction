effect clear @s levitation

$effect give @s slow_falling $(duration) 1 true
execute as @a[scores={MagicSort=14,dead=0}] unless predicate manosaba:is_sneaking run return run function magics:effection/14_gravity_control/magic14a_self/duration_get

execute as @a[scores={MagicSort=14,dead=0},nbt={active_effects:[{id:"minecraft:levitation"}]}] run schedule function magics:effection/14_gravity_control/magic14a_self/shift_detect 1t
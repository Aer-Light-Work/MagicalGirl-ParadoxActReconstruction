tag @a remove magic14_act
$effect give @s levitation $(duration) 1 true

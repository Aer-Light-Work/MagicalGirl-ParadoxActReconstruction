#魔耗
scoreboard players remove @s MP 40

#cd
scoreboard players set @s cd1 10

$effect give @s levitation $(duration) 1 true

schedule function magics:effection/14_gravity_control/magic14a_self/shift_detect 1t
scoreboard players operation @s general_compute = @p[tag=magic14_act] witchProg
scoreboard players add @s general_compute 10

execute store result storage magic:data duration int 0.1 run scoreboard players get @s general_compute
function magics:effection/14_gravity_control/magic14a_check/effect_apply with storage magic:data
particle minecraft:explosion_emitter
particle minecraft:end_rod ~ ~ ~ 1.5 0.2 1.5 0.5 30 force
playsound minecraft:entity.dragon_fireball.explode ambient @a[distance=..16] ~ ~ ~ 0.5 0.5

execute as @a[distance=..7] at @s run function magics:effection/12_charge/magic12a_back_at
scoreboard players set @a MP_B_conut 0

tag @a remove charge_b_user

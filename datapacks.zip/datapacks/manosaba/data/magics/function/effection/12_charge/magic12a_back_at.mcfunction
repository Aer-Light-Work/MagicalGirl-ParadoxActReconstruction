effect give @s minecraft:slowness 10 0 false
particle minecraft:end_rod ~ ~2 ~ 0 1 0 0.5 30 force

execute if score @s MP_B_conut matches 1 run damage @s 5 magic by @p[tag=magic12a_starter]
execute if score @s MP_B_conut matches 2 run damage @s 9 magic by @p[tag=magic12a_starter]
execute if score @s MP_B_conut matches 3 run damage @s 12 magic by @p[tag=magic12a_starter]
execute if score @s MP_B_conut matches 4 run damage @s 15 magic by @p[tag=magic12a_starter]
execute if score @s MP_B_conut matches 5 run damage @s 17 magic by @p[tag=magic12a_starter]
execute if score @s MP_B_conut matches 6.. run damage @s 18 magic by @p[tag=magic12a_starter]

tag @a remove magic12a_starter

scoreboard players set @a MP_B_conut 0
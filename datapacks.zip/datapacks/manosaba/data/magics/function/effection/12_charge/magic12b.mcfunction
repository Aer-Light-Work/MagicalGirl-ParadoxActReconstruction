##组件头
#魔耗
tag @s add charge_b_user

scoreboard players remove @s MP 80
#cd
scoreboard players set @s cd2 120

execute as @e[type=block_display,tag=magic12a_circle] at @s run tag @s add magic12b_circle_back

#音效和粒子(仅自己)
playsound entity.experience_orb.pickup ambient @s ~ ~ ~ 1.0
playsound block.beacon.power_select ambient @s ~ ~ ~ 0.8



schedule clear magics:effection/17_vampire/magic17b_20_ticks
effect clear @s minecraft:speed
effect clear @s minecraft:absorption
tag @s remove magic17b_vping
tag @s add magic17b_vping_end




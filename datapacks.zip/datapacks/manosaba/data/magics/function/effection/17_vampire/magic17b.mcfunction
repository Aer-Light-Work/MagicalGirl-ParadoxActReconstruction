


#魔耗
scoreboard players remove @s MP 5
#cd
scoreboard players set @s cd2 8

tag @s remove magic17b_vping_end

execute if entity @s[tag=magic17b_vping] run function magics:effection/17_vampire/magic17b_again
execute if entity @s[tag=magic17b_vping_end] run return 0

effect give @s minecraft:speed infinite 1 true
effect give @s minecraft:absorption infinite 9 true

tag @s add magic17b_vping

scoreboard players set @s raycast_distance 0

schedule function magics:effection/17_vampire/magic17b_20_ticks 1t
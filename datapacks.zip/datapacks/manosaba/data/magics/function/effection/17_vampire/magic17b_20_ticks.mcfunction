execute if score @s raycast_distance matches 6.. run return 0

execute as @a[tag=magic17b_vping] at @s run function magics:effection/17_vampire/magic17b_update

execute if entity @a[tag=magic17b_vping,scores={ready=1,dead=0}] at @s run schedule function magics:effection/17_vampire/magic17b_20_ticks 20t

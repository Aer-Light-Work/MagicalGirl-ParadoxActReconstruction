
scoreboard players add @s raycast_distance 1

scoreboard players add @s vampire_Sacrifice 1

particle minecraft:raid_omen ~ ~1.5 ~ 0.5 1 0.5 0 20 force

attribute @s minecraft:max_health modifier remove nvp

execute if score @s vampire_Sacrifice matches 1 run attribute @s minecraft:max_health modifier add nvp -1 add_value
execute if score @s vampire_Sacrifice matches 2 run attribute @s minecraft:max_health modifier add nvp -2 add_value
execute if score @s vampire_Sacrifice matches 3 run attribute @s minecraft:max_health modifier add nvp -3 add_value
execute if score @s vampire_Sacrifice matches 4 run attribute @s minecraft:max_health modifier add nvp -4 add_value
execute if score @s vampire_Sacrifice matches 5 run attribute @s minecraft:max_health modifier add nvp -5 add_value
execute if score @s vampire_Sacrifice matches 6 run attribute @s minecraft:max_health modifier add nvp -6 add_value
execute if score @s vampire_Sacrifice matches 7 run attribute @s minecraft:max_health modifier add nvp -7 add_value
execute if score @s vampire_Sacrifice matches 8 run attribute @s minecraft:max_health modifier add nvp -8 add_value
execute if score @s vampire_Sacrifice matches 9 run attribute @s minecraft:max_health modifier add nvp -9 add_value
execute if score @s vampire_Sacrifice matches 10 run attribute @s minecraft:max_health modifier add nvp -10 add_value
execute if score @s vampire_Sacrifice matches 11 run attribute @s minecraft:max_health modifier add nvp -11 add_value
execute if score @s vampire_Sacrifice matches 12 run attribute @s minecraft:max_health modifier add nvp -12 add_value
execute if score @s vampire_Sacrifice matches 13 run attribute @s minecraft:max_health modifier add nvp -13 add_value
execute if score @s vampire_Sacrifice matches 14 run attribute @s minecraft:max_health modifier add nvp -14 add_value
execute if score @s vampire_Sacrifice matches 15 run attribute @s minecraft:max_health modifier add nvp -15 add_value
execute if score @s vampire_Sacrifice matches 16 run attribute @s minecraft:max_health modifier add nvp -16 add_value
execute if score @s vampire_Sacrifice matches 17 run attribute @s minecraft:max_health modifier add nvp -17 add_value
execute if score @s vampire_Sacrifice matches 18 run attribute @s minecraft:max_health modifier add nvp -18 add_value
execute if score @s vampire_Sacrifice matches 19 run attribute @s minecraft:max_health modifier add nvp -19 add_value
execute if score @s vampire_Sacrifice matches 20 run attribute @s minecraft:max_health modifier add nvp -20 add_value
execute if score @s vampire_Sacrifice matches 21 run attribute @s minecraft:max_health modifier add nvp -21 add_value
execute if score @s vampire_Sacrifice matches 22 run attribute @s minecraft:max_health modifier add nvp -22 add_value
execute if score @s vampire_Sacrifice matches 23 run attribute @s minecraft:max_health modifier add nvp -23 add_value
execute if score @s vampire_Sacrifice matches 24 run attribute @s minecraft:max_health modifier add nvp -24 add_value
execute if score @s vampire_Sacrifice matches 25 run attribute @s minecraft:max_health modifier add nvp -25 add_value
execute if score @s vampire_Sacrifice matches 26 run attribute @s minecraft:max_health modifier add nvp -26 add_value
execute if score @s vampire_Sacrifice matches 27 run attribute @s minecraft:max_health modifier add nvp -27 add_value
execute if score @s vampire_Sacrifice matches 28 run attribute @s minecraft:max_health modifier add nvp -28 add_value
execute if score @s vampire_Sacrifice matches 29 run attribute @s minecraft:max_health modifier add nvp -29 add_value
execute if score @s vampire_Sacrifice matches 30 run attribute @s minecraft:max_health modifier add nvp -30 add_value
execute if score @s vampire_Sacrifice matches 31 run attribute @s minecraft:max_health modifier add nvp -31 add_value
execute if score @s vampire_Sacrifice matches 32 run attribute @s minecraft:max_health modifier add nvp -32 add_value
execute if score @s vampire_Sacrifice matches 33 run attribute @s minecraft:max_health modifier add nvp -33 add_value
execute if score @s vampire_Sacrifice matches 34 run attribute @s minecraft:max_health modifier add nvp -34 add_value
execute if score @s vampire_Sacrifice matches 35 run attribute @s minecraft:max_health modifier add nvp -35 add_value
execute if score @s vampire_Sacrifice matches 36 run attribute @s minecraft:max_health modifier add nvp -36 add_value
execute if score @s vampire_Sacrifice matches 37 run attribute @s minecraft:max_health modifier add nvp -37 add_value
execute if score @s vampire_Sacrifice matches 38 run attribute @s minecraft:max_health modifier add nvp -38 add_value
execute if score @s vampire_Sacrifice matches 39 run attribute @s minecraft:max_health modifier add nvp -39 add_value
execute if score @s vampire_Sacrifice matches 40 run attribute @s minecraft:max_health modifier add nvp -40 add_value

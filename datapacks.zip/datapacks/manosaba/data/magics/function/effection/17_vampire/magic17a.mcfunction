#魔耗
scoreboard players remove @s MP 80
#cd
scoreboard players set @s cd1 30
playsound minecraft:entity.phantom.bite ambient @a[distance=..5] ~ ~ ~ 0.4 0.9

##组件头
execute at @s unless entity @a[distance=0.01..4] run return 0
damage @p[distance=0.01..4] 4 magic by @s
effect give @p[distance=0.01..4] weakness 3 0 true
effect give @p[distance=0.01..4] slowness 3 0 true



scoreboard players add @s vampire_rank 1

#根据随机数给予不同的药水
execute if score @s vampire_rank matches 1 run effect give @s minecraft:night_vision infinite 0 true
execute if score @s vampire_rank matches 1 run attribute @s minecraft:max_health modifier add vp_1 4 add_value
execute if score @s vampire_rank matches 2 run attribute @s minecraft:max_health modifier add vp_2 4 add_value
execute if score @s vampire_rank matches 3 run attribute @s minecraft:max_health modifier add vp_3 4 add_value
execute if score @s vampire_rank matches 4 run attribute @s minecraft:max_health modifier add vp_4 4 add_value
execute if score @s vampire_rank matches 5 run attribute @s minecraft:max_health modifier add vp_5 4 add_value
execute if score @s vampire_rank matches 6.. run effect give @s minecraft:absorption 30 0 true

effect give @s minecraft:regeneration 3 2
effect give @s minecraft:saturation 3 5 true



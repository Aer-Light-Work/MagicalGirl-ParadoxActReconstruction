
# 将当前marker的num值存储到临时变量
scoreboard players operation #temp_num raycast_distance = @s num

# 传送拥有相同num值的玩家到尘的位置
execute as @a if score @s num = #temp_num raycast_distance run tp @s ~ ~1 ~

# 传送效果
particle dust{color:[0.5,0.4,0.3],scale:2.0} ~ ~ ~ 1.0 1.0 1.0 0.1 30 force
playsound entity.enderman.teleport ambient @a ~ ~ ~ 1.0

tag @a remove magic11a_ash_user
# 移除尘
kill @s
particle minecraft:campfire_cosy_smoke ~ ~ ~ 0.4 1 0.4 0.4 18 force
playsound minecraft:entity.generic.explode ambient @a[distance=..20] ~ ~ ~ 0.5 1.5

effect give @a[distance=..3,gamemode=adventure] minecraft:blindness 2 0 false
effect give @a[distance=..3,gamemode=adventure] minecraft:weakness 2 0 false
effect give @a[distance=..3,gamemode=adventure] minecraft:slowness 2 0 false

kill @s

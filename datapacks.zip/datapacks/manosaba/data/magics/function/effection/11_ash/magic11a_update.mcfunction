execute if entity @a[tag=magic11a_ash_user,predicate=manosaba:is_sneaking] at @s run function magics:effection/11_ash/magic11a_back
execute if entity @a[tag=magic11a_ash_user,predicate=manosaba:is_sneaking] at @s run return 0
# 减少生命周期
execute store result score #ash_lifetime raycast_distance run data get entity @s data.lifetime
scoreboard players remove #ash_lifetime raycast_distance 1
execute store result entity @s data.lifetime int 1 run scoreboard players get #ash_lifetime raycast_distance


# 如果生命周期结束或碰到方块，传送玩家并移除尘
execute if score #ash_lifetime raycast_distance matches ..0 run function magics:effection/11_ash/magic11a_teleport
execute if score #ash_lifetime raycast_distance matches ..0 run return 0
execute unless block ~ ~ ~ #minecraft:air run function magics:effection/11_ash/magic11a_teleport
execute unless block ~ ~ ~ #minecraft:air run return 0

# 缓缓向前移动
tp @s ^ ^ ^0.3

# 生成尘土粒子特效
particle dust{color:[0.5,0.4,0.3],scale:1.0} ~ ~ ~ 0.3 0.3 0.3 0.05 5 force
particle smoke ~ ~ ~ 0.2 0.2 0.2 0.02 3 force
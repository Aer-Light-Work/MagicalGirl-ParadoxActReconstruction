##组件头
#魔耗
scoreboard players remove @s MP 80
#cd
scoreboard players set @s cd2 60

##效果
#召唤灵尘block_display并让玩家骑乘
execute anchored eyes positioned ^ ^ ^ run summon block_display ^ ^ ^ {Tags:["magic11b_spirit_ash"],data:{lifetime:600,owner_uuid:[I;0,0,0,0]},block_state:{Name:"minecraft:gray_concrete_powder"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.65f,-0.1f,-0.65f],scale:[1.3f,0.2f,1.3f]}}

# 设置灵尘的旋转信息和owner
execute anchored eyes positioned ^ ^ ^ as @e[type=block_display,tag=magic11b_spirit_ash,distance=..5,limit=1,sort=nearest] run data modify entity @s Rotation set from entity @p[distance=..10] Rotation
execute as @e[type=block_display,tag=magic11b_spirit_ash,distance=..10] run data modify entity @s data.owner_uuid set from entity @p[distance=..10] UUID

# 让玩家骑乘灵尘
ride @s mount @e[type=block_display,tag=magic11b_spirit_ash,distance=..10,limit=1,sort=nearest]

#启动灵尘效果处理 - 只在有灵尘时才调度
execute if entity @e[type=block_display,tag=magic11b_spirit_ash] run schedule function magics:effection/11_ash/magic11b_tick 1t

#音效和粒子
playsound block.sand.break ambient @a ~ ~ ~ 1.0
playsound entity.phantom.ambient ambient @a ~ ~ ~ 0.5
particle dust{color:[0.3,0.3,0.3],scale:1.5} ~ ~1 ~ 0.8 0.8 0.8 0.1 30 force
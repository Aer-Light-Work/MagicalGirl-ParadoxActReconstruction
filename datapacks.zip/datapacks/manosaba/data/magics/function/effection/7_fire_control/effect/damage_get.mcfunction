advancement revoke @s only magics:7_fire_control/magic7a_effect

execute store result score @s general_compute run attribute @s attack_speed get

execute if score @s attack_cooling matches 1.. run scoreboard players set @s attack_cooling 20
execute if score @s attack_cooling matches 1.. run return run scoreboard players operation @s attack_cooling /= @s general_compute

scoreboard players set @s attack_cooling 20
scoreboard players operation @s attack_cooling /= @s general_compute

attribute @s attack_damage modifier add temp_add 1 add_value
execute unless score @s magic2 matches 1 if entity @s[nbt={OnGround:1b}] store result storage magic:data damage float 1 run attribute @s attack_damage get
execute unless score @s magic2 matches 1 unless entity @s[nbt={OnGround:1b}] store result storage magic:data damage float 1.5 run attribute @s attack_damage get
attribute @s attack_damage modifier remove temp_add

execute if score @s magic2 matches 1 if entity @s[nbt={OnGround:1b}] store result storage magic:data damage float 1.5 run attribute @s attack_damage get
execute if score @s magic2 matches 1 unless entity @s[nbt={OnGround:1b}] store result storage magic:data damage float 2 run attribute @s attack_damage get

data modify storage magic:data UUID set from entity @s UUID
tag @a remove attack_from
tag @s add attack_from
function magics:effection/7_fire_control/effect/damage_apply with storage magic:data
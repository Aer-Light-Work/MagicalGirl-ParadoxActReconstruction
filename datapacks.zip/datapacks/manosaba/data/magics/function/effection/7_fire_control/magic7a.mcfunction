##组件头
#魔耗
scoreboard players remove @s MP 100
#cd
scoreboard players set @s cd1 150

##效果
scoreboard players operation @s general_compute = @s witchProg
scoreboard players add @s general_compute 25
execute store result storage magic:data duration int 0.2 run scoreboard players get @s general_compute
function magics:effection/7_fire_control/effect/activatied with storage magic:data


schedule function magics:effection/7_fire_control/effect/tick 1s


$scoreboard players set @s general_magic_duration $(duration)
tag @s add magic7_act

kill @e[type=item,distance=..5]
kill @e[type=block_display,tag=blood,distance=..5]

execute unless score @s magic2 matches 1 run return 0
execute store result score @s general_random run random value 1..2
execute if score @s general_random matches 2 at @s run return run scoreboard players add @e[type=mannequin,tag=Corpse,distance=..5] burn_damage 10

execute at @s if entity @e[type=mannequin,tag=Corpse,distance=..5] run tellraw @s {text:"尸体焚毁成功",color:yellow}
execute at @s run tp @e[type=mannequin,tag=Corpse,distance=..5] ~ ~100 ~
execute at @s positioned ~ ~100 ~ run kill @e[type=mannequin,tag=Corpse,distance=..5]


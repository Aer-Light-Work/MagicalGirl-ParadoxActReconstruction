function clues:api/broken_item/broken_summon {\
        name:"",\
        color:"",\
        desc:[{"text":"",color:"",italic:false,bold:false}],\
        item_model:"",\
    }
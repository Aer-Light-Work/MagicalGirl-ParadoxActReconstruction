##组件头
#魔耗
scoreboard players remove @s MP 90
#cd
scoreboard players set @s cd2 30

##效果
#标记施法者
tag @s add eye_curse_caster

#对被洞察的玩家施加诅咒
execute as @a run execute if score @s num = @a[tag=eye_curse_caster,limit=1] eye_insight_num run function magics:effection/21_eye/magic21b_curse

#特效
particle soul ~ ~1.6 ~ 0.5 0.5 0.5 0 15 normal

#声音
execute as @s at @s run playsound entity.wither.spawn ambient @a ~ ~ ~ 0.5

tag @s remove eye_curse_caster

#标记最近的玩家为被洞察状态
tag @e[type=player,tag=!eye_caster,limit=1,sort=nearest] add eye_insight

#获取目标的UUID
scoreboard players operation @s eye_insight_num = @e[type=player,tag=eye_insight,limit=1,sort=nearest] num

#给目标提示
execute as @e[type=player,tag=eye_insight,limit=1] run tellraw @s [{text:"⚠ "},{text:"你已被洞察！",color:"#4169e1",bold:true}]
#给施法者提示（包含目标名字）
execute as @e[type=player,tag=eye_insight,limit=1] run tellraw @p[tag=eye_caster] [{text:"✓ "},{text:"已洞察目标：",color:"#4169e1"},{selector:"@s",color:"#87ceeb",bold:true}]
#给目标去除
execute as @e[type=player,tag=eye_insight,limit=1] run tag @s remove eye_insight

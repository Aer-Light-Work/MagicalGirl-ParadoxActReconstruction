##组件头
#魔耗
scoreboard players remove @s MP 100
#cd
scoreboard players set @s cd2 10

#初始化射线计数
scoreboard players set @s raycast_distance 0

#标记施法者，用于排除自己
tag @s add red_curse_user

##效果 - 对指向的玩家施加诅咒
# 执行raycast找到指向的玩家
execute at @s positioned ~ ~1.6 ~ run function magics:effection/22_red/magic22b_cast_step

#自身魔女化程度增加5点
scoreboard players add @s dwitchProg 5

#特效
particle dust{color:[0.5,0.0,0.0],scale:1.5} ~ ~1.5 ~ 0.5 0.5 0.5 0 15 normal
#声音
execute as @s at @s run playsound block.enchantment_table.use ambient @a ~ ~ ~ 0.5
execute as @s at @s run playsound entity.wither.spawn ambient @a ~ ~ ~ 0.5

#清理标记
tag @s remove red_curse_user

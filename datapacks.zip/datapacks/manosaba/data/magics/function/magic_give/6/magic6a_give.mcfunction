item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"👂",color:aqua,bold:false,italic:false},\
            {text:"聆听",color:aqua,bold:true,italic:false},\
            {text:"👂",color:aqua,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"以失明20秒为代价，持续聆听附近玩家的魔法种类",color:white,bold:false,italic:true},\
            {text:"范围：8",color:gold,bold:false,italic:false},\
            {text:"魔力消耗:  30 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  30 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_6a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

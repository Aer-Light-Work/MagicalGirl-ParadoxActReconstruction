item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"⚪",color:aqua,bold:false,italic:false},\
            {text:"凝视",color:aqua,bold:true,italic:false},\
            {text:"⚪",color:aqua,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"对附近角色施加1秒虚弱6，如果你知晓其魔法，增强为5秒",color:white,bold:false,italic:true},\
            {text:"范围：8",color:gold,bold:false,italic:false},\
            {text:"魔力消耗:  60 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  120 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_6b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

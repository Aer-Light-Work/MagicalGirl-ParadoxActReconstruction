item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"❣",color:light_purple,bold:false,italic:false},\
            {text:"生命汲取",color:light_purple,bold:true,italic:false},\
            {text:"❣",color:light_purple,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"最近的玩家失去4点生命值并且获得负面效果。获得吸血鬼增益。",color:white,bold:false,italic:true},\
            {text:"范围：4",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  50 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  30 s",color:gold,bold:false,italic:false},\
        ],\
    item_model="magics:magic_17a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

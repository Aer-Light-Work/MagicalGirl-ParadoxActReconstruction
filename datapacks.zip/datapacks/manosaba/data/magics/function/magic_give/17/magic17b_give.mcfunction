item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"⌘",color:dark_purple,bold:false,italic:false},\
            {text:"祭品",color:dark_purple,bold:true,italic:false},\
            {text:"⌘",color:dark_purple,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"进入吸血鬼形态，持续获得速度2，获得高额伤害吸收，代价是每秒扣除1最大生命值",color:white,bold:false,italic:true},\
            {text:"再次使用取消形态",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  5 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  8 s",color:gold,bold:false,italic:false},\
        ],\
    item_model="magics:magic_17b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"◉",color:white,bold:false,italic:false},\
            {text:"法阵反噬",color:yellow,bold:true,italic:false},\
            {text:"◉",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"秘密将在场的魔力法阵转换为反噬法阵，结束时周围角色根据其获得的魔力数量收到伤害和缓速惩罚。",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  80 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  120 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_12b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
    item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"G ",color:yellow,bold:false,italic:false},\
            {text:"重力操控",color:gold,bold:true,italic:false},\
            {text:" G",color:yellow,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"自身下次攻击将使目标漂浮x秒(正比于压力值)",color:white,bold:false,italic:true},\
            {text:"按下shift使用此技能可令自身漂浮5*x秒,漂浮期间松开shift键获得缓降",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  40 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  10 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_14a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

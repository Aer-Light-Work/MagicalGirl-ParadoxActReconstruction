#advancement reset
advancement revoke @s only clues:sharp

#temp tag (+)
tag @s add temp_sharp
#func 
execute as @s at @s run function clues:api/blood/splash/blood_splash_assign
#血液生成
summon armor_stand ~ ~ ~ {Silent:true,Invisible:true,Invulnerable:true,Tags:["blood_dropping"],attributes:[{id:scale,base:0.01f}],Passengers:[{id:item_display,item:{count: 1, id: "minecraft:nether_wart_block"}, transformation: {left_rotation: [0.0f, 0.0f, 0.0f, 1.0f], right_rotation: [0.0f, 0.0f, 0.0f, 1.0f], scale: [0.15f, 0.15f, 0.15f], translation: [0.0f, 0.0f, 0.0f]},Tags:["blood_dropping"]}]}

#落地检测进行
schedule function clues:blood/drop/blood_dropping 1t replace


#blood onground summon
particle dust{color:[0.5,0.0,0.0],scale:4} ~ ~ ~
#clear dropping entity
kill @e[type=armor_stand,tag=blood_dropping,distance=..0.2]
kill @e[type=item_display,tag=blood_dropping,distance=..0.2]

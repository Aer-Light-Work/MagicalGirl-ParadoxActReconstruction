#random
execute store result score manosaba:data bloodSize run random value 75..155
execute store result score manosaba:data bloodRotat run random value -50..50
#blood onground summon
summon minecraft:block_display ~ ~0.5025 ~ {Tags:["blood","clues","summon"],block_state: {Name: "minecraft:redstone_wire", Properties: {east: "none", north: "none", power: "0", south: "none", west: "none"}}, transformation: {left_rotation: [0.0f, 0.0f, 0.0f, 1.0f], right_rotation: [0.0f, 0.0f, 0.0f, 1.0f], scale: [1.0f, 1.0f, 1.0f], translation: [-0.5f, -0.5f, -0.5f]}}
#size
execute store result entity @n[type=block_display,tag=blood,tag=summon] transformation.scale[0] float 0.01 run scoreboard players get manosaba:data bloodSize
execute store result entity @n[type=block_display,tag=blood,tag=summon] transformation.scale[2] float 0.01 run scoreboard players get manosaba:data bloodSize
#rotat
execute store result entity @n[type=block_display,tag=blood,tag=summon] transformation.left_rotation[1] float 0.01 run scoreboard players get manosaba:data bloodRotat
#clear dropping entity
tag @e[type=block_display,tag=blood,tag=summon] remove summon
kill @e[type=armor_stand,tag=blood_dropping,distance=..0.2]
kill @e[type=item_display,tag=blood_dropping,distance=..0.2]
#sound
playsound block.honey_block.place ambient @a ~ ~ ~ 0.5 1.2

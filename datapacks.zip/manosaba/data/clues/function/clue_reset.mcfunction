#blood clear
kill @e[tag=blood,type=block_display]
kill @e[tag=blood_dropping,type=armor_stand]
kill @e[tag=blood_dropping,type=item_display]
#clue
kill @e[type=item,nbt={Item:{components:{"minecraft:custom_data":{surveyable:1b}}}}]
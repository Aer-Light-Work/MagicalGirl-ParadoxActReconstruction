##接收参数 $(name) $(color) $(desc) $(item_model)

$summon item ~ ~ ~ {Item:{id:amethyst_shard,components:{custom_name:{text:"$(name)",color:"$(color)",bold:true,italic:false},\
                    lore:[$(desc),\
                            {text:">>该道具掉落物状态可被调查<<",color:red,italic:false,bold:false},\
                            {text:"surveyable",color:green,italic:true,bold:true},\
                        ],\
                    item_model:"$(item_model)",\
                    custom_data:{surveyable:1b},\
                    max_stack_size:1}},\
                    PickupDelay:60,\
                    Tags:["clue_tip"],\
                    }
return 1

##example
function clues:api/broken_item/broken_summon {\
        name:"",\
        color:"",\
        desc:[{"text":"",color:"",italic:false,bold:false}],\
        item_model:"",\
    }
##多行文本描述请不要调用此api，按一下步骤操作
#复制本函数内容
#去除传参
#添加item_name="special_clue"
#添加max_damage=x(x为行数)



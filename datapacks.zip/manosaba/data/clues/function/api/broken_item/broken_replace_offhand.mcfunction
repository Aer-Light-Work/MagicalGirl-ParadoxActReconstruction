##接收参数 $(name) $(color) $(desc) $(item_model)

$item replace entity @s weapon.offhand with amethyst_shard[custom_name={text:"$(name)",color:"$(color)",bold:true,italic:false},\
                                                            lore=[$(desc),\
                                                                    {text:">>该道具掉落物状态可被调查<<",color:red,italic:false,bold:false},\
                                                                    {text:"surveyable",color:green,italic:true,bold:true},\
                                                                ],\
                                                            item_model="$(item_model)",\
                                                            custom_data={surveyable:1b},\
                                                            !max_stack_size\
                                                        ]


return 1
##多行文本描述请不要调用此api，按一下步骤操作
#复制本函数内容
#去除传参
#添加item_name="special_clue"
#添加max_damage=x(x为行数)
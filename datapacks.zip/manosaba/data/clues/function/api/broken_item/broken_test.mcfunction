
##example
function clues:api/broken_item/broken_replace {\
        name:"牛牛爱吃的草",\
        color:"green",\
        desc:[{"text":"牛牛最爱吃的草料",color:"white",italic:false,bold:false}],\
        item_model:"minecraft:short_grass",\
    }

    
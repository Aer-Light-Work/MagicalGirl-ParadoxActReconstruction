##调用时需要位置上下文

#random bloodCount
execute store result score splashCount bloodCount run random value 5..7

#4
execute if score splashCount bloodCount matches 5 run function clues:api/blood/splash/splash5
#5
execute if score splashCount bloodCount matches 6 run function clues:api/blood/splash/splash6
#6
execute if score splashCount bloodCount matches 7 run function clues:api/blood/splash/splash7

#temp reset
scoreboard players reset splashCount bloodCount
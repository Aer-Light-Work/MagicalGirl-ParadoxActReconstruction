##接收参数 storage clue:common

# #debug
# say lore_append run

data modify storage clue:common lore append value {text:"发现时间:",color:yellow,italic:false}
$data modify storage clue:common lore append value [{text:"第 ",color:dark_purple,italic:true},{text:"$(day)",color:red,italic:true},{text:" 天",color:dark_purple,italic:true},{text:"  任务 ",color:light_purple,italic:true},{text:"$(taskC)",color:gold,italic:true}]
data modify storage clue:common lore append value {text:">>>该物品能够放入线索槽<<<",color:green,bold:false}
data modify storage clue:common lore append value {text:"庭审时单击线索槽中线索即可出示",color:yellow,bold:false}
data modify storage clue:common lore append value {text:"丢弃以永久删除此条线索(不可找回)",color:red,bold:false}
data modify storage clue:common lore append value {text:"clues",color:aqua,bold:true,italic:true}
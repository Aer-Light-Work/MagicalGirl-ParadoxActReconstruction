##接收参数 surveyable:1b掉落物实体数据 实体、位置上下文

##player
#storage UUID of player
data modify storage clue:common UUID set from entity @p[tag=eye_detect] UUID

##time
#storage time data
#day
execute store result storage clue:common day int 1.0 run scoreboard players get manosaba:data day
#taskC
execute store result storage clue:common taskC int 1.0 run scoreboard players get manosaba:data taskC

##Item
#custom_name
data modify storage clue:common custom_name set from entity @s Item.components."minecraft:custom_name"
#lore init
data modify storage clue:common lore set value []
#lore append
data modify storage clue:common lore append from entity @s Item.components."minecraft:lore"[0]
#extra lore
item replace block 1029 43 999 container.0 from entity @s container.0
execute if block 1029 43 999 barrel{Items:[{Slot:0b,components:{"minecraft:item_name":"special_clue"}}]} run function clues:api/common/extra_get
#lore append time
function clues:api/common/lore_append with storage clue:common
#item_model
data modify storage clue:common item_model set from entity @s Item.components."minecraft:item_model"

##宏调用
execute positioned ~ ~ ~ run function clues:api/common/common_summon with storage clue:common

##item lock
scoreboard players set @s discovered 1
data modify entity @s PickupDelay set value 32767
data modify entity @s Glowing set value 1b
data modify entity @s Age set value -32768

# ##storage clear
# data remove storage clue:common UUID
# data remove storage clue:common day
# data remove storage clue:common taskC
# data remove storage clue:common custom_name
# data remove storage clue:common lore
# data remove storage clue:common item_model

##接受参数 $(item_model) $(custom_name) $(lore) $(UUID)

# #debug
# say common_summon run

#particle
particle minecraft:electric_spark ~ ~0.3 ~ 0.1 0.1 0.1 0.5 32
#sound
playsound block.amethyst_block.step ambient @a ~ ~ ~ 0.5 1.2
#线索生成
$summon item ~ ~ ~ {Item:{id:"minecraft:short_grass",components:{custom_data:{clue:1b},item_model:"$(item_model)",custom_name:$(custom_name),lore:$(lore)}},Tags:["clues","clues_get","summon"],PickupDelay:0,Invulnerable:true,Age:5900,Owner:$(UUID),Glowing:1b,NoGravity:1b,Motion:[0.0,0.04,0.0]}
#team join
team join Clue @e[type=item,tag=clues_get]
#tag -
tag @e[type=item] remove clues_get
#线索初始化
scoreboard players add @e[type=item,tag=clues] discovered 0


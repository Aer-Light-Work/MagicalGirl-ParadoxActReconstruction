
execute store result score @s general_compute run data get block 1029 43 999 Items[0].components."minecraft:max_damage"
execute if score @s general_compute matches 1.. run data modify storage clue:common lore append from entity @s Item.components."minecraft:lore"[1]
execute if score @s general_compute matches 2.. run data modify storage clue:common lore append from entity @s Item.components."minecraft:lore"[2]
execute if score @s general_compute matches 3.. run data modify storage clue:common lore append from entity @s Item.components."minecraft:lore"[3]
execute if score @s general_compute matches 4.. run data modify storage clue:common lore append from entity @s Item.components."minecraft:lore"[4]
execute if score @s general_compute matches 5.. run data modify storage clue:common lore append from entity @s Item.components."minecraft:lore"[5]
#data get entity @n[type=item] Item.components."minecraft:item_name"
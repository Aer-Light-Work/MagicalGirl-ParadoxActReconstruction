#first cue
execute as @a[tag=bloody_body,scores={isTipBloody=0}] run function manosaba:cue/tips/bloodstain

#score +
scoreboard players remove @a[tag=bloody_body,scores={bloodyLvl=2..,bloodyT=1..}] bloodyLvl 1
#score reset
scoreboard players set @a[tag=bloody_body,scores={bloodyT=0}] bloodyLvl 4
#time +
scoreboard players add @a[tag=bloody_body] bloodyT 100
#temp tag remove
tag @a remove bloody_body
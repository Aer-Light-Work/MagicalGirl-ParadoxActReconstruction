##自调用组件 游戏开始时调用

##particle
#lv4
execute as @a[scores={ready=1,dead=0,bloodyDisplay=1,bloodyLvl=1,bloodyT=1..}] at @s run particle minecraft:dust{color:[0.75,0,0],scale:0.8} ~ ~1 ~ 0.3 0.5 0.3 64 32 force
#lv3
execute as @a[scores={ready=1,dead=0,bloodyDisplay=1,bloodyLvl=2,bloodyT=1..}] at @s run particle minecraft:dust{color:[0.75,0,0],scale:0.7} ~ ~1 ~ 0.3 0.5 0.3 64 24 force
#lv2
execute as @a[scores={ready=1,dead=0,bloodyDisplay=1,bloodyLvl=3,bloodyT=1..}] at @s run particle minecraft:dust{color:[0.75,0,0],scale:0.6} ~ ~1 ~ 0.3 0.5 0.3 64 16 force
#lv1
execute as @a[scores={ready=1,dead=0,bloodyDisplay=1,bloodyLvl=4,bloodyT=1..}] at @s run particle minecraft:dust{color:[0.75,0,0],scale:0.5} ~ ~1 ~ 0.3 0.5 0.3 64 8 force

#score --
scoreboard players remove @a[scores={ready=1,dead=0,bloodyDisplay=1..,bloodyT=1..}] bloodyDisplay 1

#display T reset
execute as @a[scores={ready=1,dead=0,bloodyDisplay=0,bloodyT=1..}] run scoreboard players operation @s bloodyDisplay = @s bloodyLvl

#自调用
execute if entity @a[scores={ready=1,dead=0,bloodyT=1..}] run schedule function clues:api/bloody_body/bloody_body_progress 5t
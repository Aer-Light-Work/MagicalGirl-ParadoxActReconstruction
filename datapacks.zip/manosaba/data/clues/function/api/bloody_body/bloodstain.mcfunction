#temp tag +
tag @s add bloody_body

#schedule func
schedule function clues:api/bloody_body/bloodylvl_plus 3t replace

#progress func
schedule function clues:api/bloody_body/bloody_body_progress 3t replace
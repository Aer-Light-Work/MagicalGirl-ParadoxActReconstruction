#splash单次血迹数量
scoreboard objectives add bloodCount dummy
#bleeding随机动量
scoreboard objectives add bleedMotionX dummy
scoreboard objectives add bleedMotionZ dummy
#blood(on_ground)随机大小/角度
scoreboard objectives add bloodSize dummy
scoreboard objectives add bloodRotat dummy


##玩家身上血迹残留
#残留等级
scoreboard objectives add bloodyLvl dummy
#播放倒计时
scoreboard objectives add bloodyDisplay dummy
#洗去时间
scoreboard objectives add bloodyT dummy
#advancement reset
advancement revoke @s only damage:blunt

#temp tag (+)
tag @s add temp_blunt
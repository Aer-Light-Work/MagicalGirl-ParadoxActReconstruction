##stat记录最新的受伤类型 damage记录受到该类型伤害的总值



##凭单次伤害值决定程度的伤害：
#坠落伤状态记录
scoreboard players set @s fall_stat 0
scoreboard players set @s fall_degree 0
#玩家伤害状态
scoreboard players set @s playerdmg_stat 0
scoreboard players set @s playerdmg_degree 0
#动能(弹射物)伤害状态
scoreboard players set @s projectile_stat 0
scoreboard players set @s projectile_degree 0
#爆炸伤害状态
scoreboard players set @s explode_stat 0
scoreboard players set @s explode_degree 0
##能够凭伤害次数决定程度的伤害：
#烧烫伤状态
scoreboard players set @s burn_stat 0
scoreboard players set @s burn_degree 0
#冻伤状态
scoreboard players set @s freeze_stat 0
scoreboard players set @s freeze_degree 0
#溺水状态
scoreboard players set @s drown_stat 0
scoreboard players set @s drown_degree 0
#窒息状态
scoreboard players set @s inwall_stat 0
scoreboard players set @s inwall_degree 0
#触电状态
scoreboard players set @s shock_stat 0
scoreboard players set @s shock_degree 0
#其它
scoreboard players set @s other_stat 0
scoreboard players set @s other_damage 0

#休克程度
scoreboard players set @s hemorrhagic_degree 0

#钝伤
scoreboard players set @s blunt_stat 0
scoreboard players set @s blunt_degree 0

##血量记录
#获取最大生命上限
execute store result score @s HPmax run attribute @s max_health base get
#总HP记录
scoreboard players operation @s HPsave = @s HPmax
#fall
scoreboard players set @s fall_damage 0
#player
scoreboard players set @s player_damage 0
#projectile
scoreboard players set @s projectile_damage 0
#explode
scoreboard players set @s explode_damage 0
#burn
scoreboard players set @s burn_damage 0
#freeze
scoreboard players set @s freeze_damage 0
#drown
scoreboard players set @s drown_damage 0
#inwall
scoreboard players set @s inwall_damage 0
#others
scoreboard players set @s shock_damage 0

#bleed
scoreboard players set @s bleed_damage 0

##受伤效果重置
execute as @a run function damage:damages/fall_damage/fall_clear
execute as @a run function damage:damages/burn_damage/burn_clear
execute as @a run function damage:damages/explode_damage/explode_clear
execute as @a run function damage:damages/drown_damage/drown_clear
execute as @a run function damage:damages/shock_damage/shock_clear
execute as @a run function damage:damages/drown_damage/drown_clear
execute as @a run function damage:damages/inwall_damage/inwall_clear

#tag
tag @s remove temp_sharp
tag @s remove temp_blunt
##regn 
#drown & inwall
execute if entity @a[scores={ready=1,dead=0,drown_damage=1..}] run function damage:regens/drown_regen
execute if entity @a[scores={ready=1,dead=0,inwall_damage=1..}] run function damage:regens/inwall_regen

#fall & burn & freeze
execute as @a[scores={ready=1,dead=0,fall_damage=0,fall_degree=1..}] run function damage:damages/fall_damage/fall_clear
execute as @a[scores={ready=1,dead=0,burn_damage=0,burn_degree=1..}] run function damage:damages/burn_damage/burn_clear
execute as @a[scores={ready=1,dead=0,freeze_damage=0,freeze_degree=1..}] run function damage:damages/freeze_damage/freeze_clear

##damage
#bleed
execute if entity @a[scores={ready=1,dead=0,bleed_degree=1..}] run function damage:damages/bleed_damage/bleed_main
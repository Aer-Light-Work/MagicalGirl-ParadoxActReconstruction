
#初次受伤提示
execute unless entity @s[scores={freeze_degree=2}] run tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『冻伤 III 级』",color:aqua,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"在该异常状态被治愈前",color:gray},{text:" 攻击速度 ",color:"#C99FFF"},{text:"大幅度降低",color:gray}]}}]
attribute @s attack_speed base set 1
execute at @s run playsound entity.player.hurt_freeze ambient @a ~ ~ ~ 0.5 2
scoreboard players set @s freeze_degree 3
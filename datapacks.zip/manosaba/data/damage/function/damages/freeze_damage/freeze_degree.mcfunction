##受伤程度判定 --仅受伤时调用
execute as @s[scores={freeze_damage=5..8}] run function damage:damages/freeze_damage/freeze_mild
execute as @s[scores={freeze_damage=9..14}] run function damage:damages/freeze_damage/freeze_moderate
execute as @s[scores={freeze_damage=15..}] run function damage:damages/freeze_damage/freeze_severe


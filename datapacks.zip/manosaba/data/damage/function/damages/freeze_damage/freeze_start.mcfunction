
execute as @a[tag=temp_freeze] run function damage:damages/freeze_damage/freezedmg_save
#tag remove
tag @a[tag=temp_freeze] remove temp_freeze

#if dead
execute if entity @s[scores={ready=1,dead=1,freeze_damage=0}] run scoreboard players operation @s freeze_stat = @s HPsave
execute if entity @s[scores={ready=1,dead=1,freeze_damage=0}] run return run scoreboard players operation @s freeze_damage = @s HPsave
execute if entity @s[scores={ready=1,dead=1,freeze_damage=1..}] run return run scoreboard players set @s freeze_stat 1
#stat refresh
function damage:stat_reset
#stat calc.
scoreboard players operation @s freeze_stat = @s HPsave
scoreboard players operation @s freeze_stat -= @s HP
#legal check
execute if entity @s[scores={freeze_stat=..-1}] run scoreboard players set @s freeze_stat 0
#damage cast
scoreboard players operation @s freeze_damage += @s freeze_stat
#damage legal check
execute if entity @s[scores={freeze_damage=21..}] run scoreboard players set @s freeze_damage 20
#degree check
function damage:damages/freeze_damage/freeze_degree
#burn degree check
function damage:damages/burn_damage/burn_degree
#witchprog cast
scoreboard players operation @s dwitchProg += @s freeze_stat
scoreboard players operation @s dwitchProg += @s freeze_stat
#end
scoreboard players operation @s HPsave = @s HP
tellraw @s[scores={freeze_degree=1..}] [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『冻伤』",color:aqua,italic:true,bold:true},{text:" 已痊愈！",color:green,italic:true,bold:false}]
execute as @s[scores={freeze_degree=1..}] at @s run playsound manosaba:notice ambient @s ~ ~ ~ 0.5
#degree reset
attribute @s attack_speed base set 4
scoreboard players set @s freeze_degree 0


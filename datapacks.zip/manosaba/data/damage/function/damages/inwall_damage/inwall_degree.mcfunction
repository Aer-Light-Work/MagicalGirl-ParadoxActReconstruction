##受伤程度判定 --仅受伤时调用
execute as @s[scores={inwall_damage=3..8}] run function damage:damages/inwall_damage/inwall_mild
execute as @s[scores={inwall_damage=9..14}] run function damage:damages/inwall_damage/inwall_moderate
execute as @s[scores={inwall_damage=15..}] run function damage:damages/inwall_damage/inwall_severe


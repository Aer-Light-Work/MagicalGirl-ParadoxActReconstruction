#初次受伤提示
execute unless entity @s[scores={inwall_degree=1}] run tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『窒息 I 级』",color:"#9B000A",italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"该异常状态将使你感到四肢轻微无力",color:gray}]}}]
effect give @s slowness 5 1 true
effect give @s mining_fatigue 5 2 true
scoreboard players set @s inwall_degree 1
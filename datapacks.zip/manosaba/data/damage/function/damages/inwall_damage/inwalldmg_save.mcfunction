#isDrowning
scoreboard players set @s isInwalling 8

#if dead
execute if entity @s[scores={ready=1,dead=1,inwall_damage=0}] run scoreboard players operation @s inwall_stat = @s HPsave
execute if entity @s[scores={ready=1,dead=1,inwall_damage=0}] run return run scoreboard players operation @s inwall_damage = @s HPsave
execute if entity @s[scores={ready=1,dead=1,inwall_damage=1..}] run return run scoreboard players set @s inwall_stat 1
#stat refresh
function damage:stat_reset
#stat calc.
scoreboard players operation @s inwall_stat = @s HPsave
scoreboard players operation @s inwall_stat -= @s HP
#legal check
execute if entity @s[scores={inwall_stat=..-1}] run scoreboard players set @s inwall_stat 0
#damage cast
scoreboard players operation @s inwall_damage += @s inwall_stat
#damage legal check
execute if entity @s[scores={inwall_damage=21..}] run scoreboard players set @s inwall_damage 20
#degree check
function damage:damages/inwall_damage/inwall_degree
#burn degree check
function damage:damages/burn_damage/burn_degree
#witchprog cast
scoreboard players operation @s dwitchProg += @s inwall_stat
scoreboard players operation @s dwitchProg += @s inwall_stat
scoreboard players operation @s dwitchProg += @s inwall_stat
#end
scoreboard players operation @s HPsave = @s HP
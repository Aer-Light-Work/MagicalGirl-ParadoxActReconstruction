
execute as @a[tag=temp_inwall] run function damage:damages/inwall_damage/inwalldmg_save
#tag remove
tag @a[tag=temp_inwall] remove temp_inwall
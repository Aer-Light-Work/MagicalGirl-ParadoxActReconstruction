#初次受伤提示
execute unless entity @s[scores={inwall_degree=2}] run tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『窒息 II 级』",color:"#9B000A",italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"该异常状态将使你感到四肢无力，视线黯淡",color:gray}]}}]
effect give @s slowness 5 2 true
effect give @s mining_fatigue 5 4 true
effect give @s blindness 6 1 true
effect give @s darkness 6 1 true
scoreboard players set @s inwall_degree 2
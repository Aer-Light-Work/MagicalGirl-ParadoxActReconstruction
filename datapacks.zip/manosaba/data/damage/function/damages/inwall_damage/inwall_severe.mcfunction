#初次受伤提示
execute unless entity @s[scores={inwall_degree=3}] run tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『窒息 III 级』",color:"#9B000A",italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"该异常状态将使你感到四肢无力，意识昏沉",color:gray}]}}]
effect give @s slowness 10 3 true
effect give @s mining_fatigue 10 6 true
effect give @s blindness 10 1 true
effect give @s darkness 10 1 true
effect give @s nausea 34 255 true
scoreboard players set @s inwall_degree 3
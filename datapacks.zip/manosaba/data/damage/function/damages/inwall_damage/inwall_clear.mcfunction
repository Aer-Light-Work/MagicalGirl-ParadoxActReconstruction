#degree reset
scoreboard players set @s inwall_degree 0
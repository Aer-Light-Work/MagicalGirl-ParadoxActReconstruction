tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『触电 II 级』",color:"#FFF98E",italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"该异常状态将较短暂击晕角色,并进入一段时间的中度虚弱状态",color:gray}]}}]
effect give @s slowness 5 255 true
effect give @s weakness 30 0 true
effect give @s mining_fatigue 30 2 true
effect give @s darkness 7 0 true
effect give @s blindness 7 0 true
effect give @s nausea 14 255 true
scoreboard players set @s shock_degree 2
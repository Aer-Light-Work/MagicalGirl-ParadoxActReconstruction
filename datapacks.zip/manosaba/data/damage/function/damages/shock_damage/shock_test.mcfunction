
#advancement reset
advancement revoke @s only damage:shock_test

#unready return
execute unless entity @s[scores={ready=1,dead=0,Playing=1}] run return fail

#save condition
execute unless entity @s[scores={ready=1,dead=0}] run return fail
#temp tag(+)
tag @s add temp_shock
#schedule save
schedule function damage:damages/shock_damage/shock_start 2t replace
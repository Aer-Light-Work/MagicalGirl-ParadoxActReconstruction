tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『触电 III 级』",color:"#FFF98E",italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"该异常状态将直接使角色失能一段时间,并进入一段时间的严重虚弱状态",color:gray}]}}]
effect give @s slowness 15 9 true
effect give @s darkness 25 0 true
effect give @s blindness 25 0 true
effect give @s nausea 38 255 true
effect give @s weakness 30 1 true
effect give @s mining_fatigue 30 3 true
scoreboard players set @s shock_degree 2
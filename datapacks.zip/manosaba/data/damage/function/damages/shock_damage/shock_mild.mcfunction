tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『触电 I 级』",color:"#FFF98E",italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"该异常状态将短暂击晕角色,并进入一段时间的轻微虚弱状态",color:gray}]}}]
effect give @s slowness 2 255 true
effect give @s weakness 15 0 true
effect give @s mining_fatigue 15 1 true
effect give @s darkness 4 0 true
effect give @s blindness 4 0 true
effect give @s nausea 7 255 true
scoreboard players set @s shock_degree 1
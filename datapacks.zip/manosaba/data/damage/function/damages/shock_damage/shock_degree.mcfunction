##受伤程度判定 --仅受伤时调用
execute as @s[scores={shock_stat=1..4}] run function damage:damages/shock_damage/shock_mild
execute as @s[scores={shock_stat=5..11}] run function damage:damages/shock_damage/shock_moderate
execute as @s[scores={shock_stat=12..}] run function damage:damages/shock_damage/shock_severe

execute as @a[tag=temp_shock] run function damage:damages/shock_damage/shockdmg_save
#tag remove
tag @a[tag=temp_shock] remove temp_shock
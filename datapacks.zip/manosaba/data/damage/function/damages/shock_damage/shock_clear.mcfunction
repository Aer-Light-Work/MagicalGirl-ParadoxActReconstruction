
#degree reset
scoreboard players set @s shock_degree 0

#if dead
execute if entity @s[scores={ready=1,dead=1,projectile_damage=0}] run scoreboard players operation @s projectile_stat = @s HPsave
execute if entity @s[scores={ready=1,dead=1,projectile_damage=0}] run return run scoreboard players operation @s projectile_damage = @s HPsave
execute if entity @s[scores={ready=1,dead=1,projectile_damage=1..}] run return run scoreboard players set @s projectile_stat 1
#stat refresh
function damage:stat_reset
#stat calc.
scoreboard players operation @s projectile_stat = @s HPsave
scoreboard players operation @s projectile_stat -= @s HP
#legal check
execute if entity @s[scores={projectile_stat=..-1}] run scoreboard players set @s projectile_stat 0
#damage cast
scoreboard players operation @s projectile_damage += @s projectile_stat
#damage legal check
execute if entity @s[scores={projectile_damage=21..}] run scoreboard players set @s projectile_damage 20
#burn degree check
function damage:damages/burn_damage/burn_degree
#witchprog cast
scoreboard players operation @s dwitchProg += @s projectile_stat
scoreboard players operation @s dwitchProg += @s projectile_stat
#end
scoreboard players operation @s HPsave = @s HP
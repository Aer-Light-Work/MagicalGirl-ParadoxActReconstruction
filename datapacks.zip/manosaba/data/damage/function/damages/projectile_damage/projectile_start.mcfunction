
execute as @a[tag=temp_projectile] run function damage:damages/projectile_damage/projectiledmg_save
#tag remove
tag @a[tag=temp_projectile] remove temp_projectile
#isDrowning
scoreboard players set @s isDrowning 8

#if dead
execute if entity @s[scores={ready=1,dead=1}] run scoreboard players operation @s drown_stat = @s HPsave
execute if entity @s[scores={ready=1,dead=1}] run return run scoreboard players operation @s drown_damage = @s HPsave
execute if entity @s[scores={ready=1,dead=1,drown_damage=1..}] run return run scoreboard players set @s drown_stat 1
#stat refresh
function damage:stat_reset
#stat calc.
scoreboard players operation @s drown_stat = @s HPsave
scoreboard players operation @s drown_stat -= @s HP
#legal check
execute if entity @s[scores={burn_stat=..-1}] run scoreboard players set @s burn_stat 0
#damage cast
scoreboard players operation @s drown_damage += @s drown_stat
#damage legal check
execute if entity @s[scores={drown_damage=21..}] run scoreboard players set @s drown_damage 20
#degree check
function damage:damages/drown_damage/drown_degree
#burn degree check
function damage:damages/burn_damage/burn_degree
#witchprog cast
scoreboard players operation @s dwitchProg += @s drown_stat
#end
scoreboard players operation @s HPsave = @s HP

#advancement reset
advancement revoke @s only damage:drown_test

#unready return
execute unless entity @s[scores={ready=1,dead=0,Playing=1}] run return fail

#save condition
execute unless entity @s[scores={ready=1,dead=0}] run return fail
#temp tag(+)
tag @s add temp_drown
#schedule save
schedule function damage:damages/drown_damage/drown_start 2t replace
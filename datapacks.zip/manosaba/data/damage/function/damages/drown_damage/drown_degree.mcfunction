##受伤程度判定 --仅受伤时调用
execute as @s[scores={drown_damage=3..8}] run function damage:damages/drown_damage/drown_mild
execute as @s[scores={drown_damage=9..14}] run function damage:damages/drown_damage/drown_moderate
execute as @s[scores={drown_damage=15..}] run function damage:damages/drown_damage/drown_severe


#degree reset
scoreboard players set @s drown_degree 0
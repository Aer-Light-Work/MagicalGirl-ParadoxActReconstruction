
execute as @a[tag=temp_drown] run function damage:damages/drown_damage/drowndmg_save
#tag remove
tag @a[tag=temp_drown] remove temp_drown
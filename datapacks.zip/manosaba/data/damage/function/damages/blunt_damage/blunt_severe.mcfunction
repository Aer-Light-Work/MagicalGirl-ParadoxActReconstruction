#tellback
tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『钝伤 III』",color:dark_gray,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"头部受到钝性冲击，短暂失去意识",color:gray}]}}]
#effection
effect give @s slowness 15 2 true
effect give @s nausea 23 0 true
effect give @s darkness 13 4 true
effect give @s blindness 13 4 true
#attribute
attribute @s movement_speed modifier add manosaba:blunt -10 add_value
attribute @s jump_strength modifier add manosaba:blunt -10 add_value
#score
scoreboard players set @s blunt_minus 7
#cycle
function damage:damages/blunt_damage/blunt_seeground
schedule function damage:damages/blunt_damage/blunt_cycle 1s replace
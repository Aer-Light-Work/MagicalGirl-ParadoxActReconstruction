##自调用组件

#minus
scoreboard players remove @a[scores={ready=1,dead=0,blunt_minus=1..}] blunt_minus 1
#attribute clear
execute as @a[scores={ready=1,dead=0,blunt_minus=0}] run function damage:damages/blunt_damage/blunt_severe_clear

#自调用
execute if entity @a[scores={ready=1,dead=0,blunt_minus=1..}] run schedule function damage:damages/blunt_damage/blunt_cycle 1s

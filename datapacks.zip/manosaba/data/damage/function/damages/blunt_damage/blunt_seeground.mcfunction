##自调用 看地板

execute as @a[scores={blunt_minus=1..}] at @s run tp @s ~ ~ ~ facing ~ ~-1 ~

#自调用
execute if entity @a[scores={blunt_minus=1..}] run schedule function damage:damages/blunt_damage/blunt_seeground 1t
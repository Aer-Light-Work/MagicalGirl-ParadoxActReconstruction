#tellback
tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『钝伤 II』",color:dark_gray,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"头部受到钝性冲击，眩晕，意识恍惚",color:gray}]}}]
#effection
effect give @s slowness 10 1 true
effect give @s nausea 15 0 true
effect give @s darkness 5 0 true
effect give @s blindness 5 0 true
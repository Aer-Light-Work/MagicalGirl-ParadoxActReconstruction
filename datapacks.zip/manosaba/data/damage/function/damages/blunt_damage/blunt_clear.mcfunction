
attribute @s movement_speed modifier remove manosaba:blunt
attribute @s minecraft:jump_strength modifier remove manosaba:blunt
scoreboard players set @s blunt_minus 0
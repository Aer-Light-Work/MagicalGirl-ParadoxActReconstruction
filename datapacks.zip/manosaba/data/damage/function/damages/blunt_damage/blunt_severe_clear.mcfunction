
#attribute
attribute @s movement_speed modifier remove manosaba:blunt
attribute @s jump_strength modifier remove manosaba:blunt
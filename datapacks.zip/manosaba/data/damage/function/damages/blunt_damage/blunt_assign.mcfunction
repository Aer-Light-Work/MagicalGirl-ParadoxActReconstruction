##prob check 接收参数 $(stat) -钝伤概率
#随机数
execute store result score #bluntProb blunt_stat run random value 1..100

#condition
$execute unless score #bluntProb blunt_stat matches 1..$(stat) run return fail

##effect assign
execute if score @s blunt_degree matches 3 run function damage:damages/blunt_damage/blunt_severe with storage damage:blunt
execute if score @s blunt_degree matches 2 run function damage:damages/blunt_damage/blunt_moderate with storage damage:blunt
execute if score @s blunt_degree matches 1 run function damage:damages/blunt_damage/blunt_mild with storage damage:blunt

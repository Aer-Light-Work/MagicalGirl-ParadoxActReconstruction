#tellback
tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『钝伤 I』",color:dark_gray,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"头部受到钝性冲击，轻微眩晕",color:gray}]}}]
#effection
effect give @s slowness 6 0 true
effect give @s nausea 8 0 true
effect give @s blindness 1 0 true
effect give @s darkness 2 0 true
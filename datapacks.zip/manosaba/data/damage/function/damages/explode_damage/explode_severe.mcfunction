tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『震荡 III 级』",color:gray,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"该异常状态将造成角色暂时失能，严重受限",color:gray}]}}]
effect give @s slowness 15 9 true
effect give @s darkness 25 0 true
effect give @s blindness 25 0 true
effect give @s nausea 38 255 true
execute at @s run playsound manosaba:ear_ringing ambient @s ~ ~ ~ 0.05 2
scoreboard players set @s explode_degree 2
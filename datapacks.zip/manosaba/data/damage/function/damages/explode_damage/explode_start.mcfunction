
execute as @a[tag=temp_explode] run function damage:damages/explode_damage/explodedmg_save
#tag remove
tag @a[tag=temp_explode] remove temp_explode
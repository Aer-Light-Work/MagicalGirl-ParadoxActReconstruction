tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『震荡 I 级』",color:gray,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"该异常状态将造成短暂的轻微机动受限与眩晕",color:gray}]}}]
effect give @s slowness 5 1 true
effect give @s nausea 9 255 true
execute at @s run playsound manosaba:ear_ringing ambient @s ~ ~ ~ 0.01 2
scoreboard players set @s explode_degree 1
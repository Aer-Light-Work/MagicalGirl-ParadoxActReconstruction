##受伤程度判定 --仅受伤时调用
execute as @s[scores={explode_stat=1..3}] run function damage:damages/explode_damage/explode_mild
execute as @s[scores={explode_stat=4..11}] run function damage:damages/explode_damage/explode_moderate
execute as @s[scores={explode_stat=12..}] run function damage:damages/explode_damage/explode_severe
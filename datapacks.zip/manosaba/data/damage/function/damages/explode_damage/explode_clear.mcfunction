
#degree reset
scoreboard players set @s explode_degree 0
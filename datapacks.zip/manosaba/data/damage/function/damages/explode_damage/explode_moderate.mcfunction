tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『震荡 II 级』",color:gray,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"该异常状态将造成短暂的机动受限与眩晕、失明",color:gray}]}}]
effect give @s slowness 6 3 true
effect give @s blindness 8 0 true
effect give @s darkness 8 0 true
effect give @s nausea 17 255 true
execute at @s run playsound manosaba:ear_ringing ambient @s ~ ~ ~ 0.03 2
scoreboard players set @s explode_degree 2
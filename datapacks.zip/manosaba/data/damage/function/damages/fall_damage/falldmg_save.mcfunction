
#if dead
# execute if entity @s[scores={ready=1,dead=1,fall_damage=0}] run say falldmg test0
execute if entity @s[scores={ready=1,dead=1,fall_damage=0}] run scoreboard players operation @s fall_stat = @s HPsave
execute if entity @s[scores={ready=1,dead=1,fall_damage=0}] run return run scoreboard players operation @s fall_damage = @s HPsave
# execute if entity @s[scores={ready=1,dead=1,fall_damage=1..}] run say falldmg test1
execute if entity @s[scores={ready=1,dead=1,fall_damage=1..}] run return run scoreboard players set @s fall_stat 1
# say foo
#stat refresh
function damage:stat_reset
#stat calc.
scoreboard players operation @s fall_stat = @s HPsave
scoreboard players operation @s fall_stat -= @s HP
#legal check
execute if entity @s[scores={fall_stat=..-1}] run scoreboard players set @s fall_stat 0
#damage cast
scoreboard players operation @s fall_damage += @s fall_stat
#damage legal check
execute if entity @s[scores={fall_damage=21..}] run scoreboard players set @s fall_damage 20
#degree check
function damage:damages/fall_damage/fall_degree
#burn degree check
function damage:damages/burn_damage/burn_degree
#witchprog cast
scoreboard players operation @s dwitchProg += @s fall_stat
#end
scoreboard players operation @s HPsave = @s HP
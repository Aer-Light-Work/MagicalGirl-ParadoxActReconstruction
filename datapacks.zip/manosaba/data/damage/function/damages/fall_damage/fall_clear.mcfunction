tellraw @s[scores={fall_degree=1..}] [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『坠伤』",color:red,italic:true,bold:true},{text:" 已痊愈！",color:green,italic:true,bold:false}]
execute as @s[scores={fall_degree=1..}] at @s run playsound manosaba:notice ambient @s ~ ~ ~ 0.5
#安全高度
attribute @s safe_fall_distance modifier remove damage:fall
attribute @s fall_damage_multiplier base set 1
#slow (-)
effect clear @s slowness
#degree reset
scoreboard players set @s fall_degree 0


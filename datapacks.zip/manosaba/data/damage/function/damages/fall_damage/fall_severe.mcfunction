execute unless entity @s[scores={fall_degree=3}] run tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『坠伤 III 级』",color:red,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"在该异常状态被治愈前机动性严重受限",color:gray},{text:" 安全衰落高度 ",color:"#FFF8AE"},{text:"进一步降低,",color:gray},{text:" 摔落伤害倍率 ",color:red},{text:"将中幅度增加!",color:gray}]}}]
effect give @s slowness infinite 2 true
attribute @s safe_fall_distance modifier remove damage:fall
attribute @s safe_fall_distance modifier add damage:fall -2.9 add_value
attribute @s fall_damage_multiplier base set 2
execute at @s run playsound entity.turtle.egg_break player @a ~ ~ ~ 1 0.75
scoreboard players set @s fall_degree 3
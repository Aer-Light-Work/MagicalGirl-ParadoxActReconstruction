
execute as @a[tag=temp_fall] run function damage:damages/fall_damage/falldmg_save
#tag remove
tag @a[tag=temp_fall] remove temp_fall
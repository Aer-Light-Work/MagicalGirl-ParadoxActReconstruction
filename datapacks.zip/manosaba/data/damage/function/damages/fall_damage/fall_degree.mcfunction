##受伤程度判定 --仅受伤时调用
execute as @s[scores={fall_damage=3..7}] unless entity @s[scores={fall_degree=1}] run function damage:damages/fall_damage/fall_mild
execute as @s[scores={fall_damage=8..12}] unless entity @s[scores={fall_degree=2}] run function damage:damages/fall_damage/fall_moderate
execute as @s[scores={fall_damage=13..}] unless entity @s[scores={fall_degree=3}] run function damage:damages/fall_damage/fall_severe
#初次受伤提示
execute unless entity @s[scores={fall_degree=1}] run tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『坠伤 I 级』",color:red,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"在该异常状态被治愈前机动性轻微受限，下落超过",color:gray},{text:" 1m ",color:"#FFF8AE"},{text:"将会受伤",color:gray}]}}]
effect give @s slowness infinite 0 true
attribute @s safe_fall_distance modifier remove damage:fall
attribute @s safe_fall_distance modifier add damage:fall -2 add_value
execute at @s run playsound entity.turtle.egg_break player @a ~ ~ ~ 1 2
scoreboard players set @s fall_degree 1
#初次受伤提示
execute unless entity @s[scores={fall_degree=2}] run tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『坠伤 II 级』",color:red,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"在该异常状态被治愈前机动性受限",color:gray},{text:" 起跳后落地 ",color:"#FFF8AE"},{text:"将也会受伤,",color:gray},{text:" 摔落伤害倍率 ",color:red},{text:"将小幅度增加!",color:gray}]}}]
effect give @s slowness infinite 1 true
attribute @s safe_fall_distance modifier remove damage:fall
attribute @s safe_fall_distance modifier add damage:fall -2.8 add_value
attribute @s fall_damage_multiplier base set 1.5
execute at @s run playsound entity.turtle.egg_break player @a ~ ~ ~ 1 1
scoreboard players set @s fall_degree 2
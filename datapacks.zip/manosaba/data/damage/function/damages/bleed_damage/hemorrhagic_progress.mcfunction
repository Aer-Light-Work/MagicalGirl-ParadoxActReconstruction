##自调用组件 --游戏开始时调用

#hemorrhagic reset
execute as @a[scores={ready=1,dead=0,bleed_damage=0,hemorrhagic_degree=1..}] run function damage:damages/bleed_damage/hemorrhagic_cure

#condition-func
execute as @a[scores={ready=1,dead=0,bleed_damage=1..}] run function damage:damages/bleed_damage/hemorrhagic_degree

#自调用
execute if score manosaba:data Gaming matches 1 run schedule function damage:damages/bleed_damage/hemorrhagic_progress 5s
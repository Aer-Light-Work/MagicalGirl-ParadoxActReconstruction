##出血程度判定
execute as @s[scores={bleed_damage=16..24}] run function damage:damages/bleed_damage/bleed_mild
execute as @s[scores={bleed_damage=25..32}] run function damage:damages/bleed_damage/bleed_moderate
execute as @s[scores={bleed_damage=33..}] run function damage:damages/bleed_damage/bleed_severe


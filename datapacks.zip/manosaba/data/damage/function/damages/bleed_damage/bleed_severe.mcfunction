
#初次受伤提示
execute unless entity @s[scores={hemorrhagic_degree=3}] run tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『休克 III 级』",color:dark_purple,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"你感到意识昏沉，四肢麻木，视线模糊",color:gray}]}}]
#effection
effect give @s slowness 30 2 true
effect give @s nausea 30 0 true
effect give @s mining_fatigue 30 6 true
effect give @s darkness 30 0 true
effect give @s blindness 30 0 true
#degree set
scoreboard players set @s hemorrhagic_degree 3
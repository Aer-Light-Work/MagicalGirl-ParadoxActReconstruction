
#初次受伤提示
execute unless entity @s[scores={hemorrhagic_degree=1}] run tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『休克 I 级』",color:dark_purple,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"你感到轻微头晕，四肢活动不利",color:gray}]}}]
#effection
effect give @s slowness 6 0 true
effect give @s nausea 5 0 true
effect give @s mining_fatigue 6 2 true
#degree set
scoreboard players set @s hemorrhagic_degree 1
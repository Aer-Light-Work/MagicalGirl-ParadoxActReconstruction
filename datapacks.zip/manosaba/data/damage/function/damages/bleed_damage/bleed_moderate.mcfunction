
#初次受伤提示
execute unless entity @s[scores={hemorrhagic_degree=2}] run tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『休克 II 级』",color:dark_purple,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"你感到头晕，四肢麻木",color:gray}]}}]
#effection
effect give @s slowness 14 1 true
effect give @s nausea 14 0 true
effect give @s mining_fatigue 14 4 true
#degree set
scoreboard players set @s hemorrhagic_degree 2
##every 5t

#bleed effection
execute as @a[scores={ready=1,dead=0,bleed_degree=1..,bleed_minus=0}] at @s run function damage:damages/bleed_damage/bleeding

#reset
scoreboard players set @a[scores={ready=1,dead=0,bleed_degree=1,bleed_minus=0}] bleed_minus 16
scoreboard players set @a[scores={ready=1,dead=0,bleed_degree=2,bleed_minus=0}] bleed_minus 10
scoreboard players set @a[scores={ready=1,dead=0,bleed_degree=3,bleed_minus=0}] bleed_minus 4
scoreboard players set @a[scores={ready=1,dead=0,bleed_degree=4,bleed_minus=0}] bleed_minus 1
#minus
scoreboard players remove @a[scores={ready=1,dead=0,bleed_degree=1..,bleed_minus=1..}] bleed_minus 1

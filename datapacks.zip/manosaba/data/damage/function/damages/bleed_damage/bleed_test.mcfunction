
#unready return
execute unless entity @s[scores={ready=1,dead=0,Playing=1}] run return fail

#tag -
tag @s remove temp_sharp
#stat test
scoreboard players add @s[scores={bleed_degree=0,playerdmg_stat=1..5}] bleed_degree 1
scoreboard players add @s[scores={bleed_degree=1..,playerdmg_stat=3..5}] bleed_degree 1
scoreboard players add @s[scores={playerdmg_stat=6..10}] bleed_degree 2
scoreboard players add @s[scores={playerdmg_stat=11..15}] bleed_degree 3
scoreboard players add @s[scores={playerdmg_stat=16..}] bleed_degree 4
#legal check
scoreboard players set @s[scores={bleed_degree=5..}] bleed_degree 4

#tellback
tellraw @s[scores={bleed_degree=1}] [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『浅表出血 I』",color:dark_red,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"浅表性出血，缓慢损失生命值，容易自愈",color:gray}]}}]
tellraw @s[scores={bleed_degree=2}] [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『浅表出血 II』",color:dark_red,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"浅表性出血，缓慢损失生命值，较容易自愈",color:gray}]}}]
tellraw @s[scores={bleed_degree=3}] [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『静脉出血』",color:dark_red,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"中小静脉破损所致出血，较快损失生命值，难以自愈",color:gray}]}}]
tellraw @s[scores={bleed_degree=4}] [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『大出血』",color:dark_red,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"大血管破裂所致的出血，缓慢损失生命值，几乎不可能自愈",color:gray}]}}]

#bleed_stat (+)
scoreboard players set @s bleed_stat 160
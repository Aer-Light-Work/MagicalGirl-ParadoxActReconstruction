#cure text
tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『休克』",color:dark_purple,italic:true,bold:true},{text:" 已结束！",color:green,italic:true,bold:false}]
execute as @s at @s run playsound manosaba:notice ambient @s ~ ~ ~ 0.5
#score
scoreboard players set @s hemorrhagic_degree 0

tellraw @s[scores={bleed_degree=1..}] [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『出血』",color:dark_red,italic:true,bold:true},{text:" 已停止！",color:green,italic:true,bold:false}]
execute as @s[scores={bleed_degree=1..}] at @s run playsound manosaba:notice ambient @s ~ ~ ~ 0.5
#degree reset
scoreboard players set @s bleed_degree 0
scoreboard players set @s bleed_minus 0
scoreboard players set @s bleed_stat 0
scoreboard players set @s hemorrhagic_degree 0

##流血效果

#stat
scoreboard players remove @s[scores={bleed_degree=1}] bleed_stat 16
scoreboard players remove @s[scores={bleed_degree=2}] bleed_stat 8
scoreboard players remove @s[scores={bleed_degree=3}] bleed_stat 1
scoreboard players remove @s[scores={bleed_degree=4}] bleed_stat 1

#motion random
execute store result score @s bleedMotionX run random value -10..10
execute store result score @s bleedMotionZ run random value -10..10

#blood summon
execute positioned ~ ~2.5 ~ run function clues:blood/drop/blood_summon

#motion edit
execute store result entity @e[type=armor_stand,tag=blood_dropping,limit=1,sort=nearest] Motion[0] float 0.01 run scoreboard players get @s bleedMotionX
execute store result entity @e[type=armor_stand,tag=blood_dropping,limit=1,sort=nearest] Motion[2] float 0.01 run scoreboard players get @s bleedMotionZ

##effection
#damage score
scoreboard players add @s bleed_damage 1
#damage
damage @s 0.5 damage:extra_damage

#hemorrhagic check
function damage:damages/bleed_damage/hemorrhagic_degree

#cure test
execute as @s[scores={bleed_stat=..0}] run function damage:damages/bleed_damage/bleed_clear

#score reset
# scoreboard players reset @s bleedMotionX
# scoreboard players reset @s bleedMotionZ
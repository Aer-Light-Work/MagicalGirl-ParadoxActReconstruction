
#advancement
advancement revoke @s only damage:total_test

#unready return
execute unless entity @s[scores={ready=1,dead=0,Playing=1}] run return fail


tag @s[tag=!temp_player] add beDamaged
schedule function damage:damages/total_test/total_delay 4t replace
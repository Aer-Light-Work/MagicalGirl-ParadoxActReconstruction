
#if dead
execute if entity @s[scores={ready=1,dead=1}] run return fail

#stat refresh
function damage:stat_reset
#stat calc.
scoreboard players operation @s other_stat = @s HPsave
scoreboard players operation @s other_stat -= @s HP
#damage cast
scoreboard players operation @s other_damage += @s other_stat
#burn degree check
function damage:damages/burn_damage/burn_degree
#witchprog cast
scoreboard players operation @s dwitchProg += @s other_stat
#end
scoreboard players operation @s HPsave = @s HP
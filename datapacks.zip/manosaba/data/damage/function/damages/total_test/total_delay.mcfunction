
#legal test
execute as @a[tag=beDamaged] unless score @s HP = @s HPsave run function damage:damages/total_test/otherdmg_save
#tag (-)
tag @a[tag=beDamaged] remove beDamaged
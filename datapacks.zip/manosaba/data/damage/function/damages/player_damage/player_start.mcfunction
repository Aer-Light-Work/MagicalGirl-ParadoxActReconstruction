
execute as @a[tag=temp_player] run function damage:damages/player_damage/playerdmg_save
#tag remove
tag @a[tag=temp_player] remove temp_player
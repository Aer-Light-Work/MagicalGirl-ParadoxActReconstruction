
#advancement reset
advancement revoke @s only damage:playerdmg_test

#unready return
execute unless entity @s[scores={ready=1,dead=0,Playing=1}] run return fail

#save condition
execute unless entity @s[scores={ready=1,dead=0}] run return fail
#temp tag(+)
tag @s add temp_player
#schedule save
schedule function damage:damages/player_damage/player_start 3t replace
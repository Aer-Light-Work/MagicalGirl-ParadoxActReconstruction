
#if dead
execute if entity @s[scores={ready=1,dead=1,player_damage=0}] run scoreboard players operation @s playerdmg_stat = @s HPsave
execute if entity @s[scores={ready=1,dead=1,player_damage=0}] run return run scoreboard players operation @s player_damage = @s HPsave
execute if entity @s[scores={ready=1,dead=1,player_damage=1..}] run return run scoreboard players set @s playerdmg_stat 1
#stat refresh
function damage:stat_reset
#stat calc.
scoreboard players operation @s playerdmg_stat = @s HPsave
scoreboard players operation @s playerdmg_stat -= @s HP
#legal check
execute if entity @s[scores={playerdmg_stat=..-1}] run scoreboard players set @s playerdmg_stat 0
#damage cast
scoreboard players operation @s player_damage += @s playerdmg_stat
#damage legal check
execute if entity @s[scores={player_damage=21..}] run scoreboard players set @s player_damage 20

#luminol label
execute if entity @s[scores={player_damage=3..}] at @s run tag @a[distance=..5,scores={ready=1,dead=0}] add Hb

#sharp check
execute as @s[tag=temp_sharp] run function damage:damages/bleed_damage/bleed_test
#blunt check
execute as @s[tag=temp_blunt] run function damage:damages/blunt_damage/blunt_test

#burn degree check
function damage:damages/burn_damage/burn_degree
#witchprog cast
scoreboard players operation @s dwitchProg += @s playerdmg_stat
scoreboard players operation @s dwitchProg += @s playerdmg_stat
#end
scoreboard players operation @s HPsave = @s HP
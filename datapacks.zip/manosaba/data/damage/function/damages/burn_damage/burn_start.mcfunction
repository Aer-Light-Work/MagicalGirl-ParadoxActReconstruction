
execute as @a[tag=temp_burn] run function damage:damages/burn_damage/burndmg_save
#tag remove
tag @a[tag=temp_burn] remove temp_burn
#advancement reset
advancement revoke @s only damage:burn_test

#unready return
execute unless entity @s[scores={ready=1,dead=0,Playing=1}] run return fail

#save condition
execute unless entity @s[scores={ready=1,dead=0}] run return fail
#temp tag(+)
tag @s add temp_burn
#schedule save
schedule function damage:damages/burn_damage/burn_start 2t replace
##受伤程度判定 --仅受伤时调用
execute as @s[scores={burn_damage=5..8}] run function damage:damages/burn_damage/burn_mild
execute as @s[scores={burn_damage=9..14}] run function damage:damages/burn_damage/burn_moderate
execute as @s[scores={burn_damage=15..}] run function damage:damages/burn_damage/burn_severe


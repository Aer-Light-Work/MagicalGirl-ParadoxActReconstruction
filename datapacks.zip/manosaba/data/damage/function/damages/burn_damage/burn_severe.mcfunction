
#初次受伤提示
execute unless entity @s[scores={burn_degree=3}] run tellraw @s [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『灼伤 III 级』",color:gold,italic:true,bold:true,hover_event:{action:"show_text",value:[{text:"在该异常状态被治愈前受伤将会受到额外的",color:gray},{text:" 2点 ",color:"#FFF8AE"},{text:"追加伤害",color:light_purple}]}}]
damage @s 2 damage:extra_damage
execute at @s run playsound entity.generic.extinguish_fire ambient @a ~ ~ ~ 0.5 2
scoreboard players set @s burn_degree 3
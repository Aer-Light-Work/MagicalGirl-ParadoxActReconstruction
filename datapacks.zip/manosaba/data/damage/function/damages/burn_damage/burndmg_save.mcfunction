
#if dead
execute if entity @s[scores={ready=1,dead=1,burn_damage=0}] run scoreboard players operation @s burn_stat = @s HPsave
execute if entity @s[scores={ready=1,dead=1,burn_damage=0}] run return run scoreboard players operation @s burn_damage = @s HPsave
execute if entity @s[scores={ready=1,dead=1,burn_damage=1..}] run return run scoreboard players set @s burn_stat 1
#stat refresh
function damage:stat_reset
#stat calc.
scoreboard players operation @s burn_stat = @s HPsave
scoreboard players operation @s burn_stat -= @s HP
#legal check
execute if entity @s[scores={burn_stat=..-1}] run scoreboard players set @s burn_stat 0
#damage cast
scoreboard players operation @s burn_damage += @s burn_stat
#damage legal check
execute if entity @s[scores={burn_damage=21..}] run scoreboard players set @s burn_damage 20
#burn degree check
function damage:damages/burn_damage/burn_degree
#witchprog cast
scoreboard players operation @s dwitchProg += @s burn_stat
scoreboard players operation @s dwitchProg += @s burn_stat
scoreboard players operation @s dwitchProg += @s burn_stat
#end
scoreboard players operation @s HPsave = @s HP
tellraw @s[scores={burn_degree=1..}] [{text:"* ",color:white,italic:false},{text:"异常状态:",color:yellow,italic:true},{text:"『灼伤』",color:gold,italic:true,bold:true},{text:" 已痊愈！",color:green,italic:true,bold:false}]
execute as @s[scores={burn_degree=1..}] at @s run playsound manosaba:notice ambient @s ~ ~ ~ 0.5
#degree reset
scoreboard players set @s burn_degree 0


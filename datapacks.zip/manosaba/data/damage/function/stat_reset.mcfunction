

##凭单次伤害值决定程度的伤害：
#坠落伤状态记录
scoreboard players set @s fall_stat 0
#玩家伤害状态
scoreboard players set @s playerdmg_stat 0
#动能(弹射物)伤害状态
scoreboard players set @s projectile_stat 0
#爆炸伤害状态
scoreboard players set @s explode_stat 0
##能够凭伤害次数决定程度的伤害：
#烧烫伤状态
scoreboard players set @s burn_stat 0
#冻伤状态
scoreboard players set @s freeze_stat 0
#溺水状态
scoreboard players set @s drown_stat 0
#窒息状态
scoreboard players set @s inwall_stat 0
#触电状态
scoreboard players set @s shock_stat 0
#其它状态
scoreboard players set @s other_stat 0
#钝伤
scoreboard players set @s blunt_stat 0

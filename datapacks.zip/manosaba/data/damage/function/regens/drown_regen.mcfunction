##sta. -1
scoreboard players remove @a[scores={ready=1,dead=0,isDrowning=1..}] isDrowning 1
##sta. 0 damage --
scoreboard players remove @a[scores={ready=1,dead=0,isDrowning=0,drown_damage=1..}] drown_damage 1
##sta. clear
execute as @a[scores={ready=1,dead=0,drown_damage=0}] run function damage:damages/drown_damage/drown_clear

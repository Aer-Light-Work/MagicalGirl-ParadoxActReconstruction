##everytick --func by game_progress

##HPsave +1
scoreboard players add @s HPsave 1

##full regen
execute if score @s HP = @s HPmax as @s run tellraw @s [{text:"*  ",color:white,italic:false},{text:"所有异常状态已治愈!",color:green,italic:true}]
execute if score @s HP = @s HPmax as @s at @s run playsound entity.experience_orb.pickup ambient @s ~ ~ ~ 0.5 1.2
execute if score @s HP = @s HPmax as @s run return run function damage:damage_reset_general

##damage regen
#bleed
execute if entity @s[scores={bleed_damage=1..}] run scoreboard players remove @s bleed_damage 2
execute if entity @s[scores={bleed_damage=..-1}] run return run scoreboard players set @s bleed_damage 0
#fall
execute if entity @s[scores={fall_damage=1..}] run return run scoreboard players remove @s fall_damage 1
#burn
execute if entity @s[scores={burn_damage=1..}] run return run scoreboard players remove @s burn_damage 1
#freeze
execute if entity @s[scores={freeze_damage=1..}] run return run scoreboard players remove @s freeze_damage 1
#explode
execute if entity @s[scores={explode_damage=1..}] run return run scoreboard players remove @s explode_damage 1
#shock
execute if entity @s[scores={shock_damage=1..}] run return run scoreboard players remove @s shock_damage 1
#projectile
execute if entity @s[scores={projectile_damage=1..}] run return run scoreboard players remove @s projectile_damage 1
#player
execute if entity @s[scores={player_damage=1..}] run return run scoreboard players remove @s player_damage 1
#other
execute if entity @s[scores={other_damage=1..}] run return run scoreboard players remove @s other_damage 1
#inwall
execute if entity @s[scores={inwall_damage=1..}] run return run scoreboard players remove @s inwall_damage 1
#drown
execute if entity @s[scores={drown_damage=1..}] run return run scoreboard players remove @s drown_damage 1

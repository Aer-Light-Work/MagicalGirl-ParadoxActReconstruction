##sta. -1
scoreboard players remove @a[scores={ready=1,dead=0,isInwalling=1..}] isInwalling 1
##sta. 0 damage --
scoreboard players remove @a[scores={ready=1,dead=0,isInwalling=0,inwall_damage=1..}] inwall_damage 1
##sta. clear
execute as @a[scores={ready=1,dead=0,inwall_damage=0}] run function damage:damages/inwall_damage/inwall_clear
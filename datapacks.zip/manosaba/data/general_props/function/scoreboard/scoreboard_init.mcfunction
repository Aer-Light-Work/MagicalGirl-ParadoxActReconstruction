
scoreboard objectives add PropsRandom dummy
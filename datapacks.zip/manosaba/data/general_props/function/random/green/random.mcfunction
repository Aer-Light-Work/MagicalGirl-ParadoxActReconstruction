execute store result storage manosaba:props_random propnum int 1 run random value 1..7
function general_props:random/green/green_give with storage manosaba:props_random
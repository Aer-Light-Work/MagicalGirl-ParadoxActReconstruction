execute store result storage manosaba:props_random propnum int 1 run random value 1..8
function general_props:random/potion/potion_give with storage manosaba:props_random
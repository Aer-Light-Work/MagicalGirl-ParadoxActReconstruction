give @s minecraft:stick[\
    item_model="minecraft:stick",\
    custom_name={\
        text:"扫帚棍",\
        color:"green",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"也许是魔法扫帚的残骸",color:white,bold:false,italic:true},\
        {text:"较长的木棍，能有效用来防身",color:white,bold:false,italic:true},\
        "",\
        {text:"简易长矛 (1/5)",color:gray,bold:false,italic:true},\
        {text:"tool",color:red,bold:true,italic:true}\
    ],\
    enchantment_glint_override=false,\
    enchantments={\
        knockback:1\
    },\
    max_stack_size=1,\
    max_damage=30,\
    damage=0,\
    weapon={\
        item_damage_per_attack:1\
    }\
]

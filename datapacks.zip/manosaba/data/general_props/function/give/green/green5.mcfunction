give @s minecraft:string[\
    item_model="manosaba:sewing_kit",\
    custom_name={\
        text:"针线包",\
        color:"green",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"一个被磨得有些发亮的小布包，像是用碎布头一点点拼凑缝制而成的",color:white,bold:false,italic:true},\
        "",\
        {text:"只穿一次就扔掉也太浪费了desuwa",color:"dark_green",bold:false,italic:true},\
        {text:"food",color:"red",bold:true,italic:true}\
    ],\
    max_stack_size=1,\
] 1
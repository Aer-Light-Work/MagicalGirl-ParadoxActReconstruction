give @s minecraft:writable_book[\
    item_model="minecraft:writable_book",\
    lore=[\
        {text:""},\
        {text:"随身携带记录的笔记本",color:white,bold:false,italic:true},\
        {text:"可以作为十分有价值的证物",color:white,bold:false,italic:true},\
        "",\
        {text:"将成书丢到图书馆樱花树附近",color:gray,bold:false,italic:true},\
        {text:"该书将被永久保存",color:gray,bold:false,italic:true},\
        {text:"tool",color:red,bold:true,italic:true}\
    ],\
    max_stack_size=1\
]

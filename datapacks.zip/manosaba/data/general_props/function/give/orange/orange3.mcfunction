give @s minecraft:bell[\
    item_model="manosaba:crystalball",\
    custom_name={\
        text:"水晶球",\
        color:"gold",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"蕴含魔力的水晶球",color:white,bold:false,italic:true},\
        {text:"附近的一切都将无处遁形",color:white,bold:false,italic:true},\
        "",\
        {text:"magical props",color:red,bold:true,italic:true}\
    ],\
    max_stack_size=1,\
    consumable={\
        animation:"none",\
        consume_seconds:0.6,\
        has_consume_particles:false,\
        sound:"minecraft:block.amethyst_cluster.step"\
    },\
    use_cooldown={\
        cooldown_group:"crystalball",\
        seconds:3\
    }\
]

give @s minecraft:bell[\
    item_model="minecraft:compass",\
    custom_name={\
        text:"死亡警报指南针",\
        color:"gold",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"",color:white,bold:false,italic:true},\
        {text:"持有者死亡时会提示附近的人",color:white,bold:false,italic:true},\
        "",\
        {text:"magical props",color:red,bold:true,italic:true}\
    ],\
    max_stack_size=1,\
    max_damage=1,\
    damage=0\
]

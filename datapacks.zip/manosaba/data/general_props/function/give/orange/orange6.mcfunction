give @s minecraft:bell[\
    item_model="manosaba:sculpture",\
    custom_name={\
        text:"肖像玩偶",\
        color:"gold",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"一尊造型别致的石膏像",color:white,bold:false,italic:true},\
        {text:"似乎可以与其沟通并减少些许压力",color:white,bold:false,italic:true},\
        "",\
        {text:"石膏像之中可能含有线索",color:gray,bold:false,italic:true},\
        {text:"可以尝试着打碎她",color:gray,bold:false,italic:true},\
        {text:"magic props",color:red,bold:true,italic:true}\
    ],\
    max_stack_size=1,\
    consumable={\
        animation:"none",\
        has_consume_particles:false,\
        consume_seconds:1,\
        sound:"minecraft:block.stone.break"\
    },\
    max_damage=4,\
    damage=0\
]

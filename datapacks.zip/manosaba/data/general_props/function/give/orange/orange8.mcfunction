give @s minecraft:bell[\
    item_model="manosaba:tarot_0",\
    custom_name={\
        text:"塔罗牌",\
        color:"gold",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"「信则其有，疑则其无」",color:white,bold:false,italic:true},\
        "",\
        {text:"有兴趣的话我也可以给你们占卜哦♡",color:dark_purple,bold:false,italic:true},\
        {text:"magical props",color:red,bold:true,italic:true}\
    ],\
    max_stack_size=1,\
    max_damage=8,\
    damage=0,\
    consumable={\
        consume_seconds:0,\
        has_consume_particles:false,\
        sound:"minecraft:block.amethyst_cluster.step"\
    },\
    use_cooldown={\
        cooldown_group:"tarot",\
        seconds:4\
    }\
]

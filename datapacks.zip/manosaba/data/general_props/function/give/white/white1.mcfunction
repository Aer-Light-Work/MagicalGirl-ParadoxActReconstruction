give @s minecraft:wheat[\
    item_model="minecraft:wheat",\
    custom_name={\
        text:"扫帚头",\
        color:"white",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"也许是魔法扫帚的残骸",color:white,bold:false,italic:true},\
        {text:"或许可以当作刷子使用",color:white,bold:false,italic:true},\
        "",\
        {text:"tool",color:red,bold:true,italic:true}\
    ],\
    max_stack_size=1\
]

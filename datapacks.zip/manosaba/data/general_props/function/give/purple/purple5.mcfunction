give @s minecraft:flint[\
    item_model="manosaba:landmine",\
    custom_name={\
        text:"地雷",\
        color:"dark_purple",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"丢弃以部署地雷",color:white,bold:false,italic:true},\
        {text:"可以把人炸飞 awa",color:white,bold:false,italic:true},\
        "",\
        {text:"你是一个郁娇豆芽菜地雷",color:blue,bold:false,italic:true},\
        {text:"weapon",color:red,bold:true,italic:true}\
    ],\
    max_stack_size=1\
]

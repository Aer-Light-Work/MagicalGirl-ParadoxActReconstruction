give @p minecraft:copper_chain[\
    item_model="manosaba:scarecrow",\
    custom_name={\
        text:"稻草人",\
        color:"dark_purple",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"用扫把拼出的稻草人，颇具人形",color:white,bold:false,italic:true},\
        "",\
        {text:"也许可以为它缝上一身衣服",color:gray,bold:false,italic:true},\
        {text:"magic_props",color:"red",bold:true,italic:true}\
    ],\
] 1
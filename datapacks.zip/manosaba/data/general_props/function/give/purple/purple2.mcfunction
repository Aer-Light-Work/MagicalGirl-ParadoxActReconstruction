give @s minecraft:bell[\
    item_model="manosaba:doll",\
    custom_name={\
        text:"巫毒娃娃",\
        color:"dark_purple",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"造型奇怪的娃娃",color:white,bold:false,italic:true},\
        {text:"散发着邪恶的气息",color:white,bold:false,italic:true},\
        "",\
        {text:"哎呀……",color:dark_purple,bold:false,italic:true},\
        {text:"magical props",color:red,bold:true,italic:true}\
    ],\
    max_stack_size=1,\
    consumable={\
        animation:"none",\
        consume_seconds:9999,\
        has_consume_particles:false\
    },\
    custom_data={doll:0},\
]

give @s minecraft:cactus_flower[\
    item_model="minecraft:lead",\
    custom_name={\
        text:"绳索",\
        color:"dark_purple",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"窒息 play（",color:white,bold:false,italic:true},\
        {text:"似乎是趁手的杀人工具",color:white,bold:false,italic:true},\
        "",\
        {text:"可以从背后勒住别人，直至窒息而亡",color:gray,bold:false,italic:true},\
        {text:"想要用绳子勒死别人可能需要消耗大量体力",color:gray,bold:false,italic:true},\
        {text:"tool",color:red,bold:true,italic:true}\
    ],\
    consumable={\
        animation:"none",\
        has_consume_particles:false,\
        consume_seconds:2147483647\
    },\
    max_stack_size=1,\
    max_damage=8\
]

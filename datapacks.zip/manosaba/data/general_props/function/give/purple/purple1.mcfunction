give @p minecraft:waxed_copper_door[\
    item_model="manosaba:broken_umbrella",\
    custom_name={\
        text:"坏掉的雨伞",\
        color:"dark_purple",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"一把损坏的雨伞，已经不能使用，伞面上依稀可见精美的花纹",color:white,bold:false,italic:true},\
        "",\
        {text:"也许可以用木棍替代伞骨?",color:gray,bold:false,italic:true},\
        {text:"magic props",color:"red",bold:true,italic:true}\
    ],\
    max_stack_size=1,\
    max_damage=2,\
    damage=2,\
] 1
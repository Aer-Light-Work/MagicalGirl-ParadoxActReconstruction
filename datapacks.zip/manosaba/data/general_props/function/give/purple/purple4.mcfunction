give @s minecraft:bell[\
    item_model="manosaba:pendant",\
    custom_name={\
        text:"水晶吊坠",\
        color:"dark_purple",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"具有魔力的水晶吊坠",color:white,bold:false,italic:true},\
        {text:"打碎后可以释放其蕴含的魔力",color:white,bold:false,italic:true},\
        "",\
        {text:"打碎后可能会发生奇怪的事情",color:gray,bold:false,italic:true},\
        {text:"magic props",color:red,bold:true,italic:true}\
    ],\
    max_stack_size=1,\
    consumable={\
        animation:"none",\
        has_consume_particles:false,\
        consume_seconds:1,\
        sound:"minecraft:block.amethyst_cluster.break"\
    }\
]

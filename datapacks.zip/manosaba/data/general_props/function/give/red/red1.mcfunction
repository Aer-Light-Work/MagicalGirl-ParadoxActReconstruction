give @s minecraft:bell[\
    item_model="manosaba:deathbook",\
    custom_name={\
        text:"死亡笔记",\
        color:"red",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"传说中只要将名字写在上面",color:white,bold:false,italic:true},\
        {text:"就会发生一些不好的事情",color:white,bold:false,italic:true},\
        "",\
        {text:"magical props",color:red,bold:true,italic:true}\
    ],\
    max_stack_size=1,\
    consumable={\
        animation:"none",\
        consume_seconds:9999,\
        has_consume_particles:false\
    }\
]

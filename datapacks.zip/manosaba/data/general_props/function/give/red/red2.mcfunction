give @s minecraft:bell[\
    item_model="manosaba:sparklingwater",\
    custom_name={\
        text:"气泡水",\
        color:"red",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"似乎是普通的饮料",color:white,bold:false,italic:true},\
        "",\
        {text:"彩色泡腾片 ww",color:aqua,bold:false,italic:true},\
        {text:"food",color:red,bold:true,italic:true}\
    ],\
    max_stack_size=1,\
    consumable={\
        animation:"drink",\
        consume_seconds:2.20,\
        has_consume_particles:false,\
        sound:"minecraft:entity.generic.drink"\
    }\
]

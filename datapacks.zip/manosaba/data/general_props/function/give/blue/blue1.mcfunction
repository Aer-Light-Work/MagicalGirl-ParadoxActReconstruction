give @s minecraft:kelp[\
    item_model="manosaba:pear",\
    custom_name={\
        text:"橘雪梨",\
        color:"blue",\
        bold:true,italic:false\
    },\
    lore=[\
        {text:""},\
        {text:"一个奇怪的的...雪梨?",color:white,bold:false,italic:true},\
        "",\
        {text:"雪莉酱卡哇伊daisuki",color:blue,bold:false,italic:true},\
        {text:"food",color:"red",bold:true,italic:true}\
    ],\
    consumable={\
        animation:"eat",\
        has_consume_particles:false,\
        consume_seconds:4,\
    },\
    food={\
        nutrition:2,\
        saturation:5,\
    },\
    damage_resistant={types:"#is_fire"},\
    max_stack_size=16,\
] 1
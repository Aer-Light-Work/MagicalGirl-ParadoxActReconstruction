##传入{x1,y1,z1,x2,y2,z2}
$fill $(x1) $(y1) $(z1) $(x2) $(y2) $(z2) air strict

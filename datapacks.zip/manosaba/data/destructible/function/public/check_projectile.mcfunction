##传入{x,y,z,dx,dy,dz}
$execute if entity @e[x=$(x),y=$(y),z=$(z),dx=$(dx),dy=$(dy),dz=$(dz),nbt={LeftOwner:true}] run scoreboard players set @s NearbyProjectileg 1
$execute unless entity @e[x=$(x),y=$(y),z=$(z),dx=$(dx),dy=$(dy),dz=$(dz),nbt={LeftOwner:true}] run scoreboard players set @s NearbyProjectileg 0

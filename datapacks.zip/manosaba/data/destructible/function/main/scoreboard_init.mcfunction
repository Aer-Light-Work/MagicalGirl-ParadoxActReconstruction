scoreboard objectives add DestructibleTemp dummy
scoreboard objectives add DestructibleBreak dummy
scoreboard objectives add DestructibleTime dummy
scoreboard objectives add LightPosX dummy
scoreboard objectives add LightPosY dummy
scoreboard objectives add LightPosZ dummy
scoreboard objectives add LightEndY dummy
scoreboard objectives add LightFalling dummy
scoreboard objectives add NearbyProjectileg dummy


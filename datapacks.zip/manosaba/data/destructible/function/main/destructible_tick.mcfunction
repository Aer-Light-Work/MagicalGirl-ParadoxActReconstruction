function destructible:light/light_check


##每秒自循环
execute if score manosaba:data Gaming matches 1 run schedule function destructible:main/destructible_tick 1t

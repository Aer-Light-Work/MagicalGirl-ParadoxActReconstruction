execute as @e[type=interaction,tag=destructible] run data remove entity @s attack
scoreboard players set @e[type=interaction,tag=destructible] DestructibleBreak 0
scoreboard players set @e[type=interaction,tag=destructible] LightFalling 0


function destructible:light/light_init

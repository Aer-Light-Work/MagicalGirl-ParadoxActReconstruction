scoreboard players set @s DestructibleTemp 3
scoreboard players operation @s DestructibleTemp += @s LightPosY
execute store result storage destructible:light_top x int 1 run scoreboard players get @s LightPosX
execute store result storage destructible:light_top y int 1 run scoreboard players get @s DestructibleTemp
execute store result storage destructible:light_top z int 1 run scoreboard players get @s LightPosZ
function destructible:light/light3/light3_fill_top with storage destructible:light_top

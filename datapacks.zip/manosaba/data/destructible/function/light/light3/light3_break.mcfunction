##传入{x,y,z}

scoreboard players set @s LightFalling 0
$clone 1012 42 1052 1018 45 1057 $(x) $(y) $(z) strict

$execute as @e[x=$(x),y=$(y),z=$(z),dx=6,dy=3,dz=5] run damage @s 20 falling_block

scoreboard players set @s DestructibleTemp 3
scoreboard players operation @s DestructibleTemp += @s LightPosX
execute store result storage destructible:light_fall x int 1 run scoreboard players get @s DestructibleTemp
scoreboard players set @s DestructibleTemp 2
scoreboard players operation @s DestructibleTemp += @s LightPosZ
execute store result storage destructible:light_fall z int 1 run scoreboard players get @s DestructibleTemp

function destructible:light/light3/light3_break_effect with storage destructible:light_fall

function destructible:light/light3/light3_top

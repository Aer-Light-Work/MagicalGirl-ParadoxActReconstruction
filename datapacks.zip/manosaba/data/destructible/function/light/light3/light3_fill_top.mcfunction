##传入{x,y,z}
$clone 1021 42 1052 1027 42 1057 $(x) $(y) $(z) strict masked

##传入{x,y,z}
$clone 1003 42 1052 1009 45 1057 $(x) $(y) $(z) strict

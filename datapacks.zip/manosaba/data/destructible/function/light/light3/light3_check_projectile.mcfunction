scoreboard players set @s DestructibleTemp 2
scoreboard players operation @s DestructibleTemp += @s LightPosX
execute store result storage destructible:light3 x int 1 run scoreboard players get @s DestructibleTemp

scoreboard players set @s DestructibleTemp 2
scoreboard players operation @s DestructibleTemp += @s LightPosY
execute store result storage destructible:light3 y int 1 run scoreboard players get @s DestructibleTemp

scoreboard players set @s DestructibleTemp 1
scoreboard players operation @s DestructibleTemp += @s LightPosZ
execute store result storage destructible:light3 z int 1 run scoreboard players get @s DestructibleTemp

data modify storage destructible:light3 dx set value 2
data modify storage destructible:light3 dy set value 1
data modify storage destructible:light3 dz set value 2

function destructible:public/check_projectile with storage destructible:light3
execute if score @s NearbyProjectileg matches 1 at @s run function destructible:light/light_break

execute as @e[type=interaction,tag=destructible,tag=light,scores={DestructibleBreak=0}] \
if data entity @s attack at @s run function destructible:light/light_break

execute as @e[type=interaction,tag=destructible,tag=light1,scores={DestructibleBreak=0}] \
run function destructible:light/light1/light1_check_projectile
execute as @e[type=interaction,tag=destructible,tag=light2,scores={DestructibleBreak=0}] \
run function destructible:light/light2/light2_check_projectile
execute as @e[type=interaction,tag=destructible,tag=light3,scores={DestructibleBreak=0}] \
run function destructible:light/light3/light3_check_projectile

execute as @e[type=interaction,tag=destructible,tag=light1,tag=root,scores={DestructibleBreak=1,LightFalling=1}] \
run function destructible:light/light1/light1_fall
execute as @e[type=interaction,tag=destructible,tag=light2,tag=root,scores={DestructibleBreak=1,LightFalling=1}] \
run function destructible:light/light2/light2_fall
execute as @e[type=interaction,tag=destructible,tag=light3,tag=root,scores={DestructibleBreak=1,LightFalling=1}] \
run function destructible:light/light3/light3_fall

function destructible:light/light2/light2_clear


execute store result score @s DestructibleTemp run time query gametime
scoreboard players operation @s DestructibleTemp -= @s DestructibleTime
scoreboard players operation @s DestructibleTemp *= @s DestructibleTemp
#四舍五入
scoreboard players add @s DestructibleTemp 24
execute store result storage destructible:light_fall height double 0.0204166667 run scoreboard players get @s DestructibleTemp
execute store result score #light_fall DestructibleTemp run data get storage destructible:light_fall height
scoreboard players operation @s DestructibleTemp = @s LightPosY
scoreboard players operation @s DestructibleTemp -= #light_fall DestructibleTemp
execute if score @s DestructibleTemp < @s LightEndY run scoreboard players operation @s DestructibleTemp = @s LightEndY

execute store result storage destructible:light_fall x int 1 run scoreboard players get @s LightPosX
execute store result storage destructible:light_fall y int 1 run scoreboard players get @s DestructibleTemp
execute store result storage destructible:light_fall z int 1 run scoreboard players get @s LightPosZ


execute if score @s DestructibleTemp <= @s LightEndY \
run return run function destructible:light/light2/light2_break with storage destructible:light_fall

function destructible:light/light2/light2_fill with storage destructible:light_fall

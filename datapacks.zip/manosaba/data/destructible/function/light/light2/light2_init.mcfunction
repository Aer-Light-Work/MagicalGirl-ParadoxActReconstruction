function destructible:light/light2/light2_clear
execute store result storage destructible:light x int 1 run scoreboard players get @s LightPosX
execute store result storage destructible:light y int 1 run scoreboard players get @s LightPosY
execute store result storage destructible:light z int 1 run scoreboard players get @s LightPosZ
function destructible:light/light2/light2_fill with storage destructible:light

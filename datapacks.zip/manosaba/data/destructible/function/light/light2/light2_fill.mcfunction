##传入{x,y,z}
$clone 1003 42 1044 1007 45 1049 $(x) $(y) $(z) strict

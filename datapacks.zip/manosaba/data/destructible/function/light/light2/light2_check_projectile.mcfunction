scoreboard players set @s DestructibleTemp 2
scoreboard players operation @s DestructibleTemp += @s LightPosX
execute store result storage destructible:light2 x int 1 run scoreboard players get @s DestructibleTemp

scoreboard players set @s DestructibleTemp 1
scoreboard players operation @s DestructibleTemp += @s LightPosY
execute store result storage destructible:light2 y int 1 run scoreboard players get @s DestructibleTemp

scoreboard players set @s DestructibleTemp 2
scoreboard players operation @s DestructibleTemp += @s LightPosZ
execute store result storage destructible:light2 z int 1 run scoreboard players get @s DestructibleTemp

data modify storage destructible:light2 dx set value 0
data modify storage destructible:light2 dy set value 2
data modify storage destructible:light2 dz set value 1

function destructible:public/check_projectile with storage destructible:light2
execute if score @s NearbyProjectileg matches 1 at @s run function destructible:light/light_break

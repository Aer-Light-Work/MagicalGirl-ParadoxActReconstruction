execute as @n[type=interaction,tag=root] if score @s DestructibleBreak matches 0 run \
execute store result score @s DestructibleTime run time query gametime
execute as @n[type=interaction,tag=root] if score @s DestructibleBreak matches 0 run playsound minecraft:block.chain.break master @a ~ ~ ~ 2 0.6
execute as @n[type=interaction,tag=root] if score @s DestructibleBreak matches 0 run scoreboard players set @s LightFalling 1
execute as @n[type=interaction,tag=root] if score @s DestructibleBreak matches 0 run scoreboard players set @s DestructibleBreak 1

scoreboard players set @s DestructibleBreak 1

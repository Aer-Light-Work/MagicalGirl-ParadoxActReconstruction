##传入{x,y,z}
$clone 1001 42 1036 1006 47 1041 $(x) $(y) $(z) strict

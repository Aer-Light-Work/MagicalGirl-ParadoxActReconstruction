##传入{x,y,z}

scoreboard players set @s LightFalling 0
$clone 1009 42 1036 1014 47 1041 $(x) $(y) $(z) strict

$execute as @e[x=$(x),y=$(y),z=$(z),dx=5,dy=5,dz=5] run damage @s 20 falling_block

scoreboard players set @s DestructibleTemp 3
scoreboard players operation @s DestructibleTemp += @s LightPosX
execute store result storage destructible:light_fall x int 1 run scoreboard players get @s DestructibleTemp
scoreboard players set @s DestructibleTemp 3
scoreboard players operation @s DestructibleTemp += @s LightPosZ
execute store result storage destructible:light_fall z int 1 run scoreboard players get @s DestructibleTemp
function destructible:light/light1/light1_break_effect with storage destructible:light_fall

execute store result storage destructible:clear_pos x1 int 1 run scoreboard players get @s LightPosX

execute store result storage destructible:clear_pos y1 int 1 run scoreboard players get @s LightEndY

execute store result storage destructible:clear_pos z1 int 1 run scoreboard players get @s LightPosZ

scoreboard players set @s DestructibleTemp 5
scoreboard players operation @s DestructibleTemp += @s LightPosX
execute store result storage destructible:clear_pos x2 int 1 run scoreboard players get @s DestructibleTemp

scoreboard players set @s DestructibleTemp 5
scoreboard players operation @s DestructibleTemp += @s LightPosY
execute store result storage destructible:clear_pos y2 int 1 run scoreboard players get @s DestructibleTemp

scoreboard players set @s DestructibleTemp 5
scoreboard players operation @s DestructibleTemp += @s LightPosZ
execute store result storage destructible:clear_pos z2 int 1 run scoreboard players get @s DestructibleTemp

function destructible:public/clear_area with storage destructible:clear_pos

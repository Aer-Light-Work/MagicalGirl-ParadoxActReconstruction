##传入{x,y,z}

$particle minecraft:explosion_emitter $(x) $(y) $(z) 0 0 0 0 0 force @a
$playsound minecraft:item.mace.smash_ground_heavy master @a $(x) $(y) $(z)

scoreboard players set @s DestructibleTemp 2
scoreboard players operation @s DestructibleTemp += @s LightPosX
execute store result storage destructible:light1 x int 1 run scoreboard players get @s DestructibleTemp

scoreboard players set @s DestructibleTemp 1
scoreboard players operation @s DestructibleTemp += @s LightPosY
execute store result storage destructible:light1 y int 1 run scoreboard players get @s DestructibleTemp

scoreboard players set @s DestructibleTemp 2
scoreboard players operation @s DestructibleTemp += @s LightPosZ
execute store result storage destructible:light1 z int 1 run scoreboard players get @s DestructibleTemp

data modify storage destructible:light1 dx set value 2
data modify storage destructible:light1 dy set value 3
data modify storage destructible:light1 dz set value 2

function destructible:public/check_projectile with storage destructible:light1
execute if score @s NearbyProjectileg matches 1 at @s run function destructible:light/light_break

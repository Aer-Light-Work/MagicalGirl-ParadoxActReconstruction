##test
scoreboard players set 3e411c62-f1bc-4117-afdf-76f4ac08b4ea LightPosX 1021
scoreboard players set 3e411c62-f1bc-4117-afdf-76f4ac08b4ea LightPosY 71
scoreboard players set 3e411c62-f1bc-4117-afdf-76f4ac08b4ea LightPosZ 1034
scoreboard players set 3e411c62-f1bc-4117-afdf-76f4ac08b4ea LightEndY 60

scoreboard players set cf9120f6-add0-458b-967b-384e99076947 LightPosX 1024
scoreboard players set cf9120f6-add0-458b-967b-384e99076947 LightPosY 72
scoreboard players set cf9120f6-add0-458b-967b-384e99076947 LightPosZ 1047
scoreboard players set cf9120f6-add0-458b-967b-384e99076947 LightEndY 60

scoreboard players set 43f4c488-803e-4561-a1d5-3e95eab4f481 LightPosX 1027
scoreboard players set 43f4c488-803e-4561-a1d5-3e95eab4f481 LightPosY 72
scoreboard players set 43f4c488-803e-4561-a1d5-3e95eab4f481 LightPosZ 1056
scoreboard players set 43f4c488-803e-4561-a1d5-3e95eab4f481 LightEndY 60

##light1
scoreboard players set 2f074841-dd8f-46d6-9a6b-cbd270f5acbe LightPosX 439
scoreboard players set 2f074841-dd8f-46d6-9a6b-cbd270f5acbe LightPosY 21
scoreboard players set 2f074841-dd8f-46d6-9a6b-cbd270f5acbe LightPosZ 423
scoreboard players set 2f074841-dd8f-46d6-9a6b-cbd270f5acbe LightEndY 17

scoreboard players set 3e1fad2e-ad14-42b5-ac43-1d532ebbe9a9 LightPosX 439
scoreboard players set 3e1fad2e-ad14-42b5-ac43-1d532ebbe9a9 LightPosY 21
scoreboard players set 3e1fad2e-ad14-42b5-ac43-1d532ebbe9a9 LightPosZ 435
scoreboard players set 3e1fad2e-ad14-42b5-ac43-1d532ebbe9a9 LightEndY 17

execute as @e[type=interaction,tag=destructible,tag=light1,tag=root] \
run function destructible:light/light1/light1_init


##light2
scoreboard players set 6949a553-498d-447e-a293-3aa66ef8da7c LightPosX 402
scoreboard players set 6949a553-498d-447e-a293-3aa66ef8da7c LightPosY -6
scoreboard players set 6949a553-498d-447e-a293-3aa66ef8da7c LightPosZ 413
scoreboard players set 6949a553-498d-447e-a293-3aa66ef8da7c LightEndY -12

scoreboard players set 3315c986-06ce-4309-914f-04fadae34820 LightPosX 420
scoreboard players set 3315c986-06ce-4309-914f-04fadae34820 LightPosY -6
scoreboard players set 3315c986-06ce-4309-914f-04fadae34820 LightPosZ 413
scoreboard players set 3315c986-06ce-4309-914f-04fadae34820 LightEndY -12

execute as @e[type=interaction,tag=destructible,tag=light2,tag=root] \
run function destructible:light/light2/light2_init

##light3
scoreboard players set 7849923b-c3bb-4af3-8214-121e3820b457 LightPosX 510
scoreboard players set 7849923b-c3bb-4af3-8214-121e3820b457 LightPosY 24
scoreboard players set 7849923b-c3bb-4af3-8214-121e3820b457 LightPosZ 487
scoreboard players set 7849923b-c3bb-4af3-8214-121e3820b457 LightEndY 17

execute as @e[type=interaction,tag=destructible,tag=light3,tag=root] \
run function destructible:light/light3/light3_init


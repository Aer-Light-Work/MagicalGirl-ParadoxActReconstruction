# 可破坏物简介

## 一、吊灯

### （一）二楼大厅吊灯

```
/summon minecraft:interaction ~ ~ ~ {Silent:true,Tags:[destructible,light,light1,root],height:4,width:1.2}
```

### （二）惩罚室吊灯

```
/summon minecraft:interaction ~ ~ ~ {Silent:true,Tags:[destructible,light,light2,root],height:2,width:0.5}
```
```
/summon minecraft:interaction ~ ~ ~ {Silent:true,Tags:[destructible,light,light2],height:2,width:0.5}
```

### （三）娱乐室吊灯

```
/summon minecraft:interaction ~ ~ ~ {Silent:true,Tags:[destructible,light,light3,root],height:3,width:1}
```

item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"▣",color:white,bold:false,italic:false},\
            {text:"微步",color:"#cfcfcf",bold:true,italic:false},\
            {text:"▣",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"短暂的隐身并加速",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  5 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  3 s",color:gold,bold:false,italic:false},\
        ],\
    item_model="magics:magic_8a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
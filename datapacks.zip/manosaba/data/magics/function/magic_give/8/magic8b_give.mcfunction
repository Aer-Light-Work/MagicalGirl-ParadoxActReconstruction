item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"▣",color:white,bold:false,italic:false},\
            {text:"出窍",color:"#cfcfcf",bold:true,italic:false},\
            {text:"▣",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"原地留下一个假身,本体隐身并加速,再次使可以回到假身位置",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  80 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  180 s",color:gold,bold:false,italic:false},\
            {text:"持续时间:  5~10 s",color:green,bold:false,italic:false},\
            {text:""},\
            {text:"被动",color:"dark_purple",bold:true,italic:false},\
            {text:"使用微步可以减少本技能的1 s冷却",color:yellow,bold:false,italic:true},\
            {text:"* 假身的血量与你当前相同",color:white,bold:false,italic:true},\
        ],\
    item_model="magics:magic_8b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
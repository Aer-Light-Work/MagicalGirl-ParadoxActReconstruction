item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"❆",color:white,bold:false,italic:false},\
            {text:"冰晶弹",color:aqua,bold:true,italic:false},\
            {text:"❆",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"向前发射出一枚受重力影响的冰晶,对碰到的目标造成减速与伤害",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  30 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  5 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_1a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
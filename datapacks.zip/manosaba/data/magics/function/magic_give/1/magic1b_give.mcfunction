item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"❆",color:white,bold:false,italic:false},\
            {text:"凝剑",color:aqua,bold:true,italic:false},\
            {text:"❆",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"凝聚出一把能够短时间存在的冰晶剑",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  100 MP",color:aqua,bold:false,italic:false},\
            {text:"*基础冷却:  180 s",color:gold,bold:false,italic:false},\
            {text:"持续时间:  10 s",color:green,bold:false,italic:false}\
        ],\
    item_model="magics:magic_1b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]


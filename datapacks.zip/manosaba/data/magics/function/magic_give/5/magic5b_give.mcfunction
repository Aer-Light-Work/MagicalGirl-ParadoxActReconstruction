item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"⚖",color:white,bold:false,italic:false},\
            {text:"仪式",color:"#870e0e",bold:true,italic:false},\
            {text:"⚖",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"举行仪式",color:white,bold:false,italic:true},\
            {text:"受到祝福之人会获得额外的生命",color:white,bold:false,italic:true},\
            {text:"受到诅咒之人会成为鲜美的祭品",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  280 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  666 s",color:gold,bold:false,italic:false},\
            {text:""},\
            {text:"被动",color:"dark_purple",bold:true,italic:false},\
            {text:"你死亡时如果魔力足够,cd为零也会发动仪式",color:yellow,bold:false,italic:true},\
        ],\
    item_model="magics:magic_5b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
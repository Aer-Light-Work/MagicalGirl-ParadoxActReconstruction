item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"⚖",color:white,bold:false,italic:false},\
            {text:"咒语",color:"#870e0e",bold:true,italic:false},\
            {text:"⚖",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"短暂失明缓慢饥饿,结束后获得40 MP",color:white,bold:false,italic:true},\
            {text:"魔女化低于70额外获得5点魔女化值",color:white,bold:false,italic:true},\
            {text:"第一次使用会给予一根咒杖",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  5 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  60 s",color:gold,bold:false,italic:false},\
            {text:""},\
            {text:"被动",color:"dark_purple",bold:true,italic:false},\
            {text:"如果未选择目标则赐福自己",color:yellow,bold:false,italic:true},\
        ],\
    item_model="magics:magic_5a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

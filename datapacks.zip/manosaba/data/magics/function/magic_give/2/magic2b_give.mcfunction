item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"✟",color:white,bold:false,italic:false},\
            {text:"诊断",color:"#5efcb5",bold:true,italic:false},\
            {text:"✟",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"精准持续的看到周围玩家的魔女化程度",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  100 MP",color:aqua,bold:false,italic:false},\
            {text:"*基础冷却:  210 s",color:gold,bold:false,italic:false},\
            {text:"持续时间:  3 s",color:green,bold:false,italic:false},\
            {text:""},\
            {text:"被动",color:"dark_purple",bold:true,italic:false},\
            {text:"通常技能的覆盖范围翻倍，所需魔力减半，大幅度减少冷却",color:yellow,bold:false,italic:true},\
            {text:"使用后减少本技能10 s冷却",color:yellow,bold:false,italic:true}\
        ],\
    item_model="magics:magic_2b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
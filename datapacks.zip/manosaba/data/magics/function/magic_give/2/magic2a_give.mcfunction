item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"✟",color:white,bold:false,italic:false},\
            {text:"感知",color:"#5efcb5",bold:true,italic:false},\
            {text:"✟",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"检查周围范围内除你以外的玩家魔女化状态",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  70 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  35 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_2a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
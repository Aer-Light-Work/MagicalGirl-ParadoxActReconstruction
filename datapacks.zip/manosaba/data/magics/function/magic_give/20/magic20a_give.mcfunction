item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"👻",color:white,bold:false,italic:false},\
            {text:"幽灵形态",color:"#b0c4de",bold:true,italic:false},\
            {text:"👻",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"在正常形态和幽灵形态间切换",color:white,bold:false,italic:true},\
            {text:"幽灵形态：获得隐身和零重力",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  80 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  3 s",color:gold,bold:false,italic:false},\
        ],\
    item_model="magics:magic_20a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"💀",color:gray,bold:false,italic:false},\
            {text:"死亡诅咒",color:"#8b0000",bold:true,italic:false},\
            {text:"💀",color:gray,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"指向敌人，将其生命值上限变为1",color:white,bold:false,italic:true},\
            {text:"自己永久获得凋零效果",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  100 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  999 s",color:gold,bold:false,italic:false},\
        ],\
    item_model="magics:magic_20b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

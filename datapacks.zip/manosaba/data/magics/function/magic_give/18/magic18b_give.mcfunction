item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"◉",color:yellow,bold:false,italic:false},\
            {text:"最终光炮",color:gold,bold:true,italic:false},\
            {text:"◉",color:yellow,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"召唤法阵，1秒后发射威力巨大的穿透光炮",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  100 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  80 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_18b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"◉",color:yellow,bold:false,italic:false},\
            {text:"扫帚飞行",color:gold,bold:true,italic:false},\
            {text:"◉",color:yellow,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"骑乘扫帚飞行，持续5秒",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  70 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  50 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_18a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

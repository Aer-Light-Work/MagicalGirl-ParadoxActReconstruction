item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"🔥",color:white,bold:false,italic:false},\
            {text:"火焰操控",color:"#25cb00",bold:true,italic:false},\
            {text:"🔥",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"攻击改为造成火焰伤害",color:white,bold:false,italic:true},\
            {text:"持续x秒(正比于压力值)",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  100 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  60 s",color:gold,bold:false,italic:false},\
            {text:""},\
            {text:"被动",color:"dark_purple",bold:true,italic:false},\
            {text:"焚毁周边掉落物及血迹",color:yellow,bold:false,italic:true},\
        ],\
    item_model="magics:magic_7a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"🔥",color:white,bold:false,italic:false},\
            {text:"解放技",color:"#25cb00",bold:true,italic:false},\
            {text:"🔥",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"解锁后自动激活，使一技能造成伤害提升50%",color:white,bold:false,italic:true},\
            {text:"且一技能被动效果将可以焚毁尸体",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  无",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  无限",color:gold,bold:false,italic:false},\
        ],\
    item_model="magics:magic_7b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"🔮",color:white,bold:false,italic:false},\
            {text:"念动力",color:"#ff6699",bold:true,italic:false},\
            {text:"🔮",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"持续8秒,攻击距离和方块交互距离变成50格",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  80 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  15 s",color:gold,bold:false,italic:false},\
            {text:"持续时间:  8 s",color:green,bold:false,italic:false}\
        ],\
    item_model="magics:magic_23b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"📏",color:white,bold:false,italic:false},\
            {text:"触及",color:"#66ccff",bold:true,italic:false},\
            {text:"📏",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"瞬间增加攻击距离和交互距离",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  50 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  10 s",color:gold,bold:false,italic:false},\
            {text:"持续时间:  5 s",color:green,bold:false,italic:false}\
        ],\
    item_model="magics:magic_23a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"◉",color:white,bold:false,italic:false},\
            {text:"灵尘",color:dark_gray,bold:true,italic:false},\
            {text:"◉",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"召唤灵尘并骑乘，持续30秒",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  80 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  60 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_11b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
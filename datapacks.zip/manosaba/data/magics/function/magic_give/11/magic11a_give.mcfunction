item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"◉",color:white,bold:false,italic:false},\
            {text:"尘",color:gray,bold:true,italic:false},\
            {text:"◉",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"召唤一团尘向前移动，2秒后传送过去",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  40 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  10 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_11a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
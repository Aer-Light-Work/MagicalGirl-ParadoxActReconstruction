item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"☁",color:white,bold:false,italic:false},\
            {text:"浮空诅咒",color:"#4169e1",bold:true,italic:false},\
            {text:"☁",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"指向目标玩家，使其进入浮空状态",color:white,bold:false,italic:true},\
            {text:"持续时间:  10 s",color:green,bold:false,italic:false},\
            {text:"魔力消耗:  50 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  8 s",color:gold,bold:false,italic:false},\
            {text:"范围:  30 格",color:green,bold:false,italic:false},\
        ],\
    item_model="magics:magic_16b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

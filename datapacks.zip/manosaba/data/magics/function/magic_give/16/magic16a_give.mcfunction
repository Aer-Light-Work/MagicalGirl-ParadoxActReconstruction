item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"☁",color:white,bold:false,italic:false},\
            {text:"浮空形态",color:"#87ceeb",bold:true,italic:false},\
            {text:"☁",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"切换浮空形态，在两种状态间来回切换",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  50 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  4 s",color:gold,bold:false,italic:false},\
            {text:"持续时间:  2 s 漂浮",color:green,bold:false,italic:false},\
        ],\
    item_model="magics:magic_16a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

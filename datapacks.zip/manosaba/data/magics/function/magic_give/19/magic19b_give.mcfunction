item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"🏮",color:yellow,bold:false,italic:false},\
            {text:"照亮",color:gold,bold:true,italic:false},\
            {text:"🏮",color:yellow,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"召唤法阵，五秒后将范围5以内最近的尸体摧毁，获得不死图腾",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  80 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  150 s",color:gold,bold:false,italic:false},\
            {text:"范围:  5 格",color:green,bold:false,italic:false}\
        ],\
    item_model="magics:magic_19b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

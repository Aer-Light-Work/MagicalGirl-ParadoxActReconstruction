item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"🏮",color:yellow,bold:false,italic:false},\
            {text:"查看存活",color:gold,bold:true,italic:false},\
            {text:"🏮",color:yellow,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"查看当前存活玩家数量",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  20 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  15 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_19a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

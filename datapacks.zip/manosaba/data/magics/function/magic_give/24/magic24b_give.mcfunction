item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"🎯",color:white,bold:false,italic:false},\
            {text:"指向传送",color:"#0099ff",bold:true,italic:false},\
            {text:"🎯",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"在指向位置释放传送门光点，下蹲在光点之间穿梭",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  85 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  3 s",color:gold,bold:false,italic:false},\
        ],\
    item_model="magics:magic_24b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

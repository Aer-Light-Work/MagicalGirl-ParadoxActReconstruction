item replace entity @s hotbar.6 with coal[\
    custom_name=\
        [\
            {text:"👁",color:white,bold:false,italic:false},\
            {text:"幻视",color:"#dc7f2d",bold:true,italic:false},\
            {text:"👁",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"使用后有x%机率(正比于压力值)获取一件稀有道具",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  10 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  40 s",color:gold,bold:false,italic:false},\
            {text:""},\
            {text:"被动",color:"dark_purple",bold:true,italic:false},\
            {text:"检定成功时压力值轻微上涨",color:yellow,bold:false,italic:true},\
        ],\
    item_model="magics:magic_3a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}\
    ]
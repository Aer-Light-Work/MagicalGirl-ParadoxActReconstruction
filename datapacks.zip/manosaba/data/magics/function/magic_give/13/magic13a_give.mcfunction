item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"⚡",color:yellow,bold:false,italic:false},\
            {text:"怪力",color:gold,bold:true,italic:false},\
            {text:"⚡",color:yellow,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"在十秒内下一次攻击获得怪力",color:white,bold:false,italic:true},\
            {text:"攻击力+4 击退+4",color:gold,bold:false,italic:false},\
            {text:"魔力消耗:  60 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  30 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_13a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

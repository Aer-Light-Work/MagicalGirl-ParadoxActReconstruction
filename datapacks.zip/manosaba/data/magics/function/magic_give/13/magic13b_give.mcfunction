item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"⚡",color:red,bold:false,italic:false},\
            {text:"绝对怪力",color:dark_red,bold:true,italic:false},\
            {text:"⚡",color:red,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"释放绝对怪力，获得30秒力量II增益",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  90 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  120 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_13b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

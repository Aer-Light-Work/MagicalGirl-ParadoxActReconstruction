item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"👁",color:"#8b0000",bold:false,italic:false},\
            {text:"诅咒之眼",color:"#8b0000",bold:true,italic:false},\
            {text:"👁",color:"#8b0000",bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"对被洞察的玩家施加诅咒",color:white,bold:false,italic:true},\
            {text:"生命值上限永久-5，获得失明、缓慢、虚弱 受诅咒五次将死亡",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  90 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  30 s",color:gold,bold:false,italic:false},\
        ],\
    item_model="magics:magic_21b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

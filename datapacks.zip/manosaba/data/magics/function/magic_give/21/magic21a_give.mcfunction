item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"👁",color:"#4169e1",bold:false,italic:false},\
            {text:"洞察之眼",color:"#4169e1",bold:true,italic:false},\
            {text:"👁",color:"#4169e1",bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"面向最近的玩家，标记其为被洞察状态",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  15 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  2 s",color:gold,bold:false,italic:false},\
        ],\
    item_model="magics:magic_21a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"🧪",color:light_purple,bold:false,italic:false},\
            {text:"随机药水",color:light_purple,bold:true,italic:false},\
            {text:"🧪",color:light_purple,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"获得一瓶随机滞留药水",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  50 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  3 s",color:gold,bold:false,italic:false},\
        ],\
    item_model="magics:magic_17a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

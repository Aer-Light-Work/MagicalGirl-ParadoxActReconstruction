item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"🧪",color:dark_purple,bold:false,italic:false},\
            {text:"高级药水",color:dark_purple,bold:true,italic:false},\
            {text:"🧪",color:dark_purple,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"获得一瓶随机滞留药水",color:white,bold:false,italic:true},\
            {text:"可堆叠至64瓶",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  90 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  6 s",color:gold,bold:false,italic:false},\
        ],\
    item_model="magics:magic_17b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

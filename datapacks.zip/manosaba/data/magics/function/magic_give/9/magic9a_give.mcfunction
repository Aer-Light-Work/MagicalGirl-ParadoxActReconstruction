item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"◉",color:white,bold:false,italic:false},\
            {text:"转",color:aqua,bold:true,italic:false},\
            {text:"◉",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"对指向的目标造成短暂缓慢，使其朝向反转",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  30 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  8 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_9a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
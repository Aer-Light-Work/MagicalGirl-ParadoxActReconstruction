item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"🐱",color:white,bold:false,italic:false},\
            {text:"兽化",color:"#e6e365",bold:true,italic:false},\
            {text:"🐱",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"变成猫咪",color:white,bold:false,italic:true},\
            {text:"猫咪状态下无敌,体型大大减小,速度大大提升,完全失去近战能力",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  80 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  180 s",color:gold,bold:false,italic:false},\
            {text:"持续时间:  15~30 s",color:green,bold:false,italic:false},\
            {text:""},\
            {text:"被动",color:"dark_purple",bold:true,italic:false},\
            {text:"通常技能的伤害翻倍",color:yellow,bold:false,italic:true},\
            {text:"使用后减少本技能5 s冷却",color:yellow,bold:false,italic:true}\
        ],\
    item_model="magics:magic_4b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
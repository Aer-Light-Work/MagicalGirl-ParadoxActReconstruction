item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"🐱",color:white,bold:false,italic:false},\
            {text:"哈气",color:"#e6e365",bold:true,italic:false},\
            {text:"🐱",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"向前方哈气造成眩晕,提升自身速度",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  40 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  8 s",color:gold,bold:false,italic:false},\
            {text:"持续时间:  3 s",color:green,bold:false,italic:false},\
            {text:""},\
            {text:"被动",color:"dark_purple",bold:true,italic:false},\
            {text:"哈气后获得永久夜视",color:yellow,bold:false,italic:true},\
        ],\
    item_model="magics:magic_4a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"🔴",color:"#8b0000",bold:false,italic:false},\
            {text:"魔女诅咒",color:"#8b0000",bold:true,italic:false},\
            {text:"🔴",color:"#8b0000",bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"对指向的玩家施加诅咒",color:white,bold:false,italic:true},\
            {text:"根据目标魔女化程度造成失明、凋零、禁用技能",color:white,bold:false,italic:true},\
            {text:"自身魔女化程度增加5点",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  100 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  50 s",color:gold,bold:false,italic:false},\
        ],\
    item_model="magics:magic_22b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"◉",color:"#fff0f0",bold:false,italic:false},\
            {text:"因子球",color:"#ffffff",bold:true,italic:false},\
            {text:"◉",color:"#fff0f0",bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"在鼠标指向位置生成因子球",color:white,bold:false,italic:true},\
            {text:"球附近的玩家每1.5秒减少1点魔女化值",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  70 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  8 s",color:gold,bold:false,italic:false},\
            {text:"持续时间:  9 s",color:green,bold:false,italic:false},\
        ],\
    item_model="magics:magic_22a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

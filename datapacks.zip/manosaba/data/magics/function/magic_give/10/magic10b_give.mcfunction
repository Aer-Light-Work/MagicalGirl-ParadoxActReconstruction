item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"◉",color:white,bold:false,italic:false},\
            {text:"花",color:yellow,bold:true,italic:false},\
            {text:"◉",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"向前方释放四个烟花，穿过的角色获得10s发光，清除隐身",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  80 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  10 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_10b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
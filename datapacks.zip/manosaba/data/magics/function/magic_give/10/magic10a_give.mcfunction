item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"◉",color:white,bold:false,italic:false},\
            {text:"照",color:yellow,bold:true,italic:false},\
            {text:"◉",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"向头顶释放烟花，获得30s发光效果，对周围人造成闪光效果",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  80 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  60 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_10a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
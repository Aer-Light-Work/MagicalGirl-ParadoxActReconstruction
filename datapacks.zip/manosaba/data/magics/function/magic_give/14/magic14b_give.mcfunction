
    item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"G ",color:yellow,bold:false,italic:false},\
            {text:"解放技",color:gold,bold:true,italic:false},\
            {text:" G",color:yellow,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"令前方3x8范围内玩家起飞,随后快速落下",color:white,bold:false,italic:true},\
            {text:"造成不低于10点摔落伤害",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  80 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  120 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_14b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

item replace entity @s hotbar.7 with coal\
    [item_model="magics:magicb_unlock",\
    custom_name={text:"未解锁",color:red,bold:true,italic:false},\
    lore=\
        [\
            {text:""},\
            {text:"???",color:white},\
            {text:"解锁条件:",color:yellow,bold:false,italic:false},\
            {text:"压力值大于 65 后右键即可解锁",color:red,bold:false,italic:false}\
        ],\
    consumable={animation:bow,consume_seconds:0,sound:intentionally_empty,has_consume_particles:false},\
    use_cooldown={seconds:3,cooldown_group:"manosaba:magicb_unlock"},\
    custom_data={"MagicSort":14,"noDrop":1b}]

item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"💀",color:white,bold:false,italic:false},\
            {text:"诅咒印记",color:"#8b008b",bold:true,italic:false},\
            {text:"💀",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"为最近四格内的其他玩家添加一层诅咒印记，魔女化程度越高越容易命中",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  40 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  6 s",color:gold,bold:false,italic:false},\
            {text:"范围:  4 格",color:green,bold:false,italic:false},\
        ],\
    item_model="magics:magic_15a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

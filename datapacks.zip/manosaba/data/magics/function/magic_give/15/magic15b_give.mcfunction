item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"💀",color:white,bold:false,italic:false},\
            {text:"诅咒引爆",color:"#ff0000",bold:true,italic:false},\
            {text:"💀",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"指向目标玩家引爆其身上的诅咒印记",color:white,bold:false,italic:true},\
            {text:"每层诅咒扣除4点生命",color:red,bold:false,italic:false},\
            {text:"每层诅咒给予10秒失明",color:red,bold:false,italic:false},\
            {text:"魔力消耗:  90 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  3 s",color:gold,bold:false,italic:false},\
            {text:"范围:  30 格",color:green,bold:false,italic:false},\
        ],\
    item_model="magics:magic_15b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]

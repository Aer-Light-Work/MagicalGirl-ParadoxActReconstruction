item replace entity @s hotbar.7 with coal\
    [custom_name=\
        [\
            {text:"♜",color:white,bold:false,italic:false},\
            {text:"领地",color:"#ffec17",bold:true,italic:false},\
            {text:"♜",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"召唤两种领地旗帜",color:white,bold:false,italic:true},\
            {text:"范围内的其他魔女会持续虚弱和缓慢",color:white,bold:false,italic:true},\
            {text:"守护形态下召唤获得高额抗性,进击形态下召唤获得高额力量",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  100 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  150 s",color:gold,bold:false,italic:false},\
            {text:"持续时间:  10~15 s",color:green,bold:false,italic:false},\
            {text:"* 旗帜拥有高亮效果",color:white,bold:false,italic:true},\
        ],\
    item_model="magics:magic_6b",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
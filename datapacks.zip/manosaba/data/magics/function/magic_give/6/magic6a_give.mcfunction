item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"♜",color:white,bold:false,italic:false},\
            {text:"骑士",color:"#ffec17",bold:true,italic:false},\
            {text:"♜",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"获得可以切换的两种被动",color:white,bold:false,italic:true},\
            {text:"受到/造成 的伤害始终 减少/增加 一点",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  30 MP",color:aqua,bold:false,italic:false},\
        ],\
    item_model="magics:magic_6a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
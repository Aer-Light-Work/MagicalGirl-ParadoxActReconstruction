item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"♜",color:white,bold:false,italic:false},\
            {text:"进击",color:"#ffec17",bold:true,italic:false},\
            {text:"♜",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"切换被动，使你受到的伤害始终提高一点",color:white,bold:false,italic:true},\
            {text:"魔力消耗:  10 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  30 s",color:gold,bold:false,italic:false},\
            {text:""},\
            {text:"被动",color:"dark_purple",bold:true,italic:false},\
            {text:"你造成的伤害始终提高一点",color:yellow,bold:false,italic:true},\
        ],\
    item_model="magics:magic_6a_attack",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
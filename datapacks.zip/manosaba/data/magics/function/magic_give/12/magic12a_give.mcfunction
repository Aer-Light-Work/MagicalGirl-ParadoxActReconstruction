item replace entity @s hotbar.6 with coal\
    [custom_name=\
        [\
            {text:"◉",color:white,bold:false,italic:false},\
            {text:"魔力法阵",color:aqua,bold:true,italic:false},\
            {text:"◉",color:white,bold:false,italic:false}\
        ],\
    lore=\
        [\
            {text:""},\
            {text:"创建魔力法阵，范围内玩家每秒回复4MP",color:white,bold:false,italic:true},\
            {text:"持续时间:  10 s",color:yellow,bold:false,italic:false},\
            {text:"魔力消耗:  60 MP",color:aqua,bold:false,italic:false},\
            {text:"冷却时间:  20 s",color:gold,bold:false,italic:false}\
        ],\
    item_model="magics:magic_12a",\
    consumable=\
        {\
            consume_seconds:0,\
            animation:bow,\
            has_consume_particles:false,\
            sound:intentionally_empty\
        },\
    custom_data={"noDrop":1b}]
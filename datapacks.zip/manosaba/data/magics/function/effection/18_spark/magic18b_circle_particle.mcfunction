# 圆形粒子绘制 - 在垂直于发射方向的平面上绘制圆形
# 调用者已经设置好朝向，这里绘制垂直于前进方向的圆形粒子

# 垂直于发射方向的圆形 - 8个点，半径2格
execute positioned ^ ^2 ^ run particle electric_spark ~ ~ ~ 0 0 0 0 1 force
execute positioned ^ ^1.4 ^1.4 run particle electric_spark ~ ~ ~ 0 0 0 0 1 force
execute positioned ^ ^ ^2 run particle electric_spark ~ ~ ~ 0 0 0 0 1 force
execute positioned ^ ^-1.4 ^1.4 run particle electric_spark ~ ~ ~ 0 0 0 0 1 force
execute positioned ^ ^-2 ^ run particle electric_spark ~ ~ ~ 0 0 0 0 1 force
execute positioned ^ ^-1.4 ^-1.4 run particle electric_spark ~ ~ ~ 0 0 0 0 1 force
execute positioned ^ ^ ^-2 run particle electric_spark ~ ~ ~ 0 0 0 0 1 force
execute positioned ^ ^1.4 ^-1.4 run particle electric_spark ~ ~ ~ 0 0 0 0 1 force

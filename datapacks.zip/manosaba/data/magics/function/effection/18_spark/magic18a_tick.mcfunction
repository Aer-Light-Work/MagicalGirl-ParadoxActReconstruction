# 扫帚术tick处理 - 只在有扫帚时运行，避免持续tick
execute as @e[type=block_display,tag=magic18a_broom] at @s run function magics:effection/18_spark/magic18a_update

# 只有当还有扫帚存在时才继续调度，实现自动停止
execute if entity @e[type=block_display,tag=magic18a_broom] run schedule function magics:effection/18_spark/magic18a_tick 1t

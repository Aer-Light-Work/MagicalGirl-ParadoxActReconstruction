# 方向指示圆 - 垂直于发射方向的旋转圆形粒子
# 这个armor_stand保存了发射方向，我们在它的位置生成垂直于发射方向的圆形粒子

# 获取法阵位置
execute as @e[type=block_display,tag=magic18b_circle,limit=1] at @s positioned ~ ~0.5 ~ run function magics:effection/18_spark/magic18b_direction_circle_draw


# 绘制方向指示圆 - 垂直于发射方向
# 使用armor_stand保存的朝向来确定发射方向
# 在垂直于发射方向的平面上绘制旋转圆

# 获取法阵和朝向holder，然后绘制圆形粒子和方向线
execute as @e[type=block_display,tag=magic18b_circle,limit=1] at @s \
    as @e[type=armor_stand,tag=magic18b_rotation_holder,limit=1] at @s rotated as @s \
    run function magics:effection/18_spark/magic18b_circle_particle

# 中心光点 - 从激光发射高度（~1.6）开始
execute as @e[type=block_display,tag=magic18b_circle,limit=1] at @s positioned ~ ~1.1 ~ \
    run particle end_rod ~ ~ ~ 0 0 0 0 1 force

# 方向指示线 - 显示发射方向（递归前进，比激光发射位置低1格）
execute as @e[type=block_display,tag=magic18b_circle,limit=1] at @s positioned ~ ~0.6 ~ \
    as @e[type=armor_stand,tag=magic18b_rotation_holder,limit=1] at @s rotated as @s \
    run function magics:effection/18_spark/magic18b_direction_line_step

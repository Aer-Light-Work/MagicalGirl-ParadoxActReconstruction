# dismount所有骑乘者

execute on passengers run ride @s dismount

# dismount效果
particle dust{color:[1.0,0.8,0.0],scale:2.0} ~ ~ ~ 1.2 1.2 1.2 0.1 40 force
particle explosion ~ ~ ~ 0.5 0.5 0.5 0.1 5 force
playsound minecraft:entity.dragon_fireball.explode ambient @a[distance=..10] ~ ~ ~ 0.5 1.5

# 移除扫帚
kill @s

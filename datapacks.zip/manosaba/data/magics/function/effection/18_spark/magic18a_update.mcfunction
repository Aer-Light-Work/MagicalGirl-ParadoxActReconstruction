# 减少生命周期
execute store result score #broom_lifetime raycast_distance run data get entity @s data.lifetime
scoreboard players remove #broom_lifetime raycast_distance 1
execute store result entity @s data.lifetime int 1 run scoreboard players get #broom_lifetime raycast_distance

# 如果生命周期结束或碰到方块，dismount玩家并移除扫帚
execute if score #broom_lifetime raycast_distance matches ..0 run function magics:effection/18_spark/magic18a_dismount

execute unless block ~ ~-1.1 ~ #minecraft:air run function magics:effection/18_spark/magic18a_dismount
execute if score #broom_lifetime raycast_distance matches ..0 run return 0
execute unless block ~ ~-1.1 ~ #minecraft:air run return 0

execute unless block ~ ~1 ~ #minecraft:air run function magics:effection/18_spark/magic18a_dismount
execute if score #broom_lifetime raycast_distance matches ..0 run return 0
execute unless block ~ ~1 ~ #minecraft:air run return 0

# 获取骑乘者的视角方向并向前移动
execute on passengers at @s run tp @e[type=block_display,tag=magic18a_broom,distance=..1,limit=1] ~ ~ ~ ~ ~
tp @s ^ ^ ^1.1

# 生成扫帚粒子特效
particle dust{color:[1.0,0.8,0.0],scale:1.2} ~ ~ ~ 0.4 0.4 0.4 0.05 8 force
particle smoke ~ ~ ~ 0.3 0.3 0.3 0.02 5 force
particle flame ~ ~ ~ 0.5 0.5 0.5 0.01 3 force

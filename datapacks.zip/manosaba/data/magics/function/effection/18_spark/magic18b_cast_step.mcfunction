#激光射线追踪（参考9_turn的cast实现）
#七彩粒子特效 - 强劲的发射效果
particle minecraft:end_rod ~ ~ ~ 0 0 0 0 3 force
particle electric_spark ~ ~ ~ 0.3 0.3 0.3 0.8 5 force
particle flame ~ ~ ~ 0.2 0.2 0.2 0.5 3 force
# 七彩尘埃粒子 - 超大尺寸，多数量
particle minecraft:flash{color:[1.0,1.0,1.0,2.0]} ~ ~1 ~ 0 0 0 0 1 force

particle dust{color:[1.0,0.0,0.0],scale:3.0} ~ ~ ~ 0.3 0.3 0.3 0.8 8 force
particle dust{color:[1.0,0.5,0.0],scale:3.0} ~ ~ ~ 0.3 0.3 0.3 0.8 8 force
particle dust{color:[1.0,1.0,0.0],scale:3.0} ~ ~ ~ 0.3 0.3 0.3 0.8 8 force
particle dust{color:[0.0,1.0,0.0],scale:3.0} ~ ~ ~ 0.3 0.3 0.3 0.8 8 force
particle dust{color:[0.0,0.0,1.0],scale:3.0} ~ ~ ~ 0.3 0.3 0.3 0.8 8 force
particle dust{color:[0.5,0.0,1.0],scale:3.0} ~ ~ ~ 0.3 0.3 0.3 0.8 8 force
particle dust{color:[1.0,0.0,1.0],scale:3.0} ~ ~ ~ 0.3 0.3 0.3 0.8 8 force

# 白色粒子 - 大量，营造光芒感
particle dust{color:[1.0,1.0,1.0],scale:3.0} ~ ~ ~ 0.6 0.6 0.6 0.8 15 force
particle dust{color:[1.0,1.0,1.0],scale:2.5} ~ ~ ~ 0.6 0.6 0.6 0.8 15 force

#检测范围内的实体并伤害（穿透形，不停止）
execute positioned ~-0.5 ~-0.5 ~-0.5 as @e[dx=0,dy=0,dz=0,tag=!spark_caster,nbt={DeathTime:0s},type=!armor_stand] run function magics:effection/18_spark/magic18b_cast_at

#距离计数
scoreboard players add @p[tag=spark_caster] raycast_distance 1

#距离限制（50格后停止）
execute if score @p[tag=spark_caster] raycast_distance matches 50.. run return 0

# ===== 继续前进 =====
execute positioned ^ ^ ^1 run function magics:effection/18_spark/magic18b_cast_step


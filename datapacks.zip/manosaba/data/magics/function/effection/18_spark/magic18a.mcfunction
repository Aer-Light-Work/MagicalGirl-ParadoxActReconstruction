##组件头
#魔耗
scoreboard players remove @s MP 70
#cd
scoreboard players set @s cd1 50

# 初始化UUID（如果尚未初始化）
execute unless score @s UUID0 = @s UUID0 run function magics:scoreboard/uuid_init

##效果
#召唤扫帚block_display并让玩家骑乘
execute anchored eyes positioned ^ ^ ^ run summon block_display ^ ^ ^ {Tags:["magic18a_broom"],data:{lifetime:100,owner_uuid:[I;0,0,0,0]},block_state:{Name:"minecraft:orange_concrete"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,-0.15f,-0.5f],scale:[1f,0.3f,1f]}}

# 设置扫帚的旋转信息和owner
execute anchored eyes positioned ^ ^ ^ as @e[type=block_display,tag=magic18a_broom,distance=..5,limit=1,sort=nearest] run data modify entity @s Rotation set from entity @p[distance=..10] Rotation
execute as @e[type=block_display,tag=magic18a_broom,distance=..10] run data modify entity @s data.owner_uuid set from entity @p[distance=..10] UUID

# 让玩家骑乘扫帚
ride @s mount @e[type=block_display,tag=magic18a_broom,distance=..10,limit=1,sort=nearest]

#启动扫帚效果处理 - 只在有扫帚时才调度
execute if entity @e[type=block_display,tag=magic18a_broom] run schedule function magics:effection/18_spark/magic18a_tick 1t

#音效和粒子
playsound block.wood.break ambient @a ~ ~ ~ 1.0
playsound minecraft:entity.dragon_fireball.explode ambient @a[distance=..10] ~ ~ ~ 0.3 2

particle dust{color:[1.0,0.8,0.0],scale:1.5} ~ ~1 ~ 0.8 0.8 0.8 0.1 10 force

# 方向指示线递归前进 - 参考16_fly的cast_step技术
# 绘制黄色粒子线，显示激光发射方向

# 绘制黄色粒子
particle dust{color:[1.0,1.0,0.0],scale:2.0} ~ ~1.4 ~ 0 0 0 0 1 force

# 距离计数
scoreboard players add @s raycast_distance 1

# 距离限制 (8格)
execute if score @s raycast_distance matches 8.. run return 0

# 继续前进
execute positioned ^ ^ ^1 run function magics:effection/18_spark/magic18b_direction_line_step

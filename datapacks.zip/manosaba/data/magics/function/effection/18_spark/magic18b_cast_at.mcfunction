#对目标造成伤害（穿透形，不会被拦住）
#检查是否已经被伤害过
execute if entity @s[tag=spark_hit] run return 0

#标记为已伤害
tag @s add spark_hit

#造成伤害
damage @s 18 explosion

#毁灭性爆炸特效
particle explosion ~ ~1 ~ 2.0 1.0 2.0 0.8 1 force
particle large_smoke ~ ~1 ~ 2.5 1.5 2.5 0.5 60 force
particle electric_spark ~ ~1 ~ 1.5 1.0 1.5 1.0 40 force
particle flame ~ ~1 ~ 1.5 0.8 1.5 0.5 30 force
particle end_rod ~ ~1 ~ 1.0 0.5 1.0 0.3 20 force

#毁灭性音效
playsound entity.generic.explode ambient @a ~ ~ ~ 1.5
playsound entity.lightning_bolt.thunder ambient @a ~ ~ ~ 1.2
playsound entity.warden.sonic_boom ambient @a ~ ~ ~ 1.0

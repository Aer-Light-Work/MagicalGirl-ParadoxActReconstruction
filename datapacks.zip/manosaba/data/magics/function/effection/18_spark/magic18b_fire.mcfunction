#从法阵位置开始发射激光
#关键：使用armor_stand保存的朝向（玩家使用魔法时的朝向）
#提高起始高度到玩家眼睛高度（~1.6）以避免弹道偏下
execute as @e[type=block_display,tag=magic18b_circle,limit=1] at @s positioned ~ ~1.6 ~ \
    rotated as @e[type=armor_stand,tag=magic18b_rotation_holder,limit=1] \
    run function magics:effection/18_spark/magic18b_cast_step

tag @a remove spark_hit

#清理法阵block_display
kill @e[type=block_display,tag=magic18b_circle]

#清理朝向holder
kill @e[type=armor_stand,tag=magic18b_rotation_holder]

#清理施法者标记
tag @a remove spark_caster

#清理旋转调度
schedule clear magics:effection/18_spark/magic18b_rotate_tick

#清理方向圆调度
schedule clear magics:effection/18_spark/magic18b_direction_circle_tick


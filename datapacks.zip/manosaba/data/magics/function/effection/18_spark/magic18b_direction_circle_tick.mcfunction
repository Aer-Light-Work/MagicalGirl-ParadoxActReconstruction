# 方向指示圆tick处理 - 垂直于发射方向的旋转圆
execute as @e[type=armor_stand,tag=magic18b_rotation_holder] at @s run function magics:effection/18_spark/magic18b_direction_circle

# 只有当还有朝向holder存在时才继续调度
execute if entity @e[type=armor_stand,tag=magic18b_rotation_holder] run schedule function magics:effection/18_spark/magic18b_direction_circle_tick 1t

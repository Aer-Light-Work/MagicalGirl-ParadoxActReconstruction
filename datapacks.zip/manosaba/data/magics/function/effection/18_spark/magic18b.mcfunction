##组件头
#魔耗
scoreboard players remove @s MP 100
#cd
scoreboard players set @s cd2 80

##效果
#初始化射线计数
scoreboard players set @s raycast_distance 0

#标记施法者
tag @s add spark_caster

#创建临时armor_stand来保存朝向（不可见）
summon armor_stand ~ ~ ~ {Tags:["magic18b_rotation_holder"],Invisible:1b,NoGravity:1b,Marker:1b}

#将玩家的朝向复制到armor_stand
execute as @e[type=armor_stand,tag=magic18b_rotation_holder,distance=..5,limit=1,sort=nearest] run data modify entity @s Rotation set from entity @p[distance=..10] Rotation

#召唤法阵block_display（正常显示在下方）
summon block_display ~ ~0.1 ~ {Tags:["magic18b_circle"],block_state:{Name:"minecraft:yellow_concrete"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-2f,-0.05f,-2f],scale:[4f,0.1f,4f]}}

#简洁的法阵激活音效
playsound block.beacon.activate ambient @a ~ ~ ~ 1.0
playsound entity.lightning_bolt.thunder ambient @a ~ ~ ~ 0.8

#简洁的法阵激活粒子
particle end_rod ~ ~1 ~ 2.0 0.1 2.0 0.1 20 force
particle electric_spark ~ ~1 ~ 2.0 0.5 2.0 0.5 30 force

#启动法阵旋转处理
execute if entity @e[type=block_display,tag=magic18b_circle] run schedule function magics:effection/18_spark/magic18b_rotate_tick 1t

#启动方向指示圆处理
execute if entity @e[type=armor_stand,tag=magic18b_rotation_holder] run schedule function magics:effection/18_spark/magic18b_direction_circle_tick 1t

#延迟发射（1秒后执行，使用armor_stand保存的朝向）
schedule function magics:effection/18_spark/magic18b_fire 1s

# 法阵旋转tick处理 - 只在有法阵时运行
execute as @e[type=block_display,tag=magic18b_circle] at @s run function magics:effection/18_spark/magic18b_rotate

# 只有当还有法阵存在时才继续调度
execute if entity @e[type=block_display,tag=magic18b_circle] run schedule function magics:effection/18_spark/magic18b_rotate_tick 1t

##组件头
#魔耗
scoreboard players remove @s MP 40
#cd
scoreboard players set @s cd1 6

##效果
#选择目标
tag @s add 15a
execute as @e[distance=0.01..4,sort=nearest,type=player,tag=!15a] run function magics:effection/15_curse/magic15a_mark

tag @s remove 15a

#为目标添加诅咒印记
execute store result score @s curse_roll run random value 1..100
execute if score @s curse_roll <= @s witchProg run scoreboard players add @s curse_mark 1
#通知施法者（只有施法者能看到）
execute if score @s curse_roll <= @s witchProg run tellraw @p[tag=15a] [{"text":"[诅咒]","color":"dark_purple","bold":true},{"text":" 命中 "},{"selector":"@s","color":"red"},{"text":" (诅咒层数: "},{"score":{"name":"@s","objective":"curse_mark"},"color":"gold"},{"text":")"}]

execute if score @s curse_roll > @s witchProg run tellraw @p[tag=15a] [{"text":"[诅咒]","color":"dark_purple","bold":true},{"text":" 未命中 "},{"selector":"@s","color":"red"},{"text":" (诅咒层数: "},{"score":{"name":"@s","objective":"curse_mark"},"color":"gold"},{"text":")"}]

#特效
particle soul ~ ~1 ~ 0.2 0.2 0.2 0 3 normal

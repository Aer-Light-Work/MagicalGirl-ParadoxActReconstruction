particle soul ~ ~ ~ 0 0 0 0 1 force

execute positioned ~-0.5 ~-0.5 ~-0.5 if entity @a[dx=0,dy=0,dz=0,tag=!curse_caster,nbt={DeathTime:0s}] run scoreboard players add @s raycast_distance 128
execute positioned ~-0.5 ~-0.5 ~-0.5 as @a[dx=0,dy=0,dz=0,tag=!curse_caster,nbt={DeathTime:0s}] run function magics:effection/15_curse/magic15b_cast_at

scoreboard players add @s raycast_distance 1

execute unless block ~ ~ ~ #minecraft:air run return 0

execute if score @s raycast_distance matches 30.. run return 0

# ===== 如果没有碰到障碍物，继续前进 =====
execute positioned ^ ^ ^1 run function magics:effection/15_curse/magic15b_cast_step

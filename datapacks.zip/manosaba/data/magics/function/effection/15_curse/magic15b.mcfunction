##组件头
#魔耗
scoreboard players remove @s MP 90
#cd
scoreboard players set @s cd2 3

#初始化射线计数
scoreboard players set @s raycast_distance 0

tag @s add curse_caster

execute at @s positioned ~ ~1.6 ~ run function magics:effection/15_curse/magic15b_cast_step

tag @s remove curse_caster

#给目标玩家添加标记
tag @s add curse_target

#获取诅咒印记数量
scoreboard players operation @s curse_temp = @s curse_mark

#计算伤害（每层4点生命 = 8点伤害值）
scoreboard players operation @s curse_damage = @s curse_mark
scoreboard players operation @s curse_damage *= #8 raycast_distance

#造成伤害（根据诅咒层数）
execute if score @s curse_mark matches 1 run damage @s 4 magic by @p[tag=curse_caster]
execute if score @s curse_mark matches 2 run damage @s 8 magic by @p[tag=curse_caster]
execute if score @s curse_mark matches 3 run damage @s 12 magic by @p[tag=curse_caster]
execute if score @s curse_mark matches 4 run damage @s 16 magic by @p[tag=curse_caster]
execute if score @s curse_mark matches 5 run damage @s 20 magic by @p[tag=curse_caster]
execute if score @s curse_mark matches 6.. run damage @s 24 magic by @p[tag=curse_caster]

#应用失明效果（每层10秒）
execute if score @s curse_mark matches 1 run effect give @s blindness 10 0 true
execute if score @s curse_mark matches 2 run effect give @s blindness 20 0 true
execute if score @s curse_mark matches 3 run effect give @s blindness 30 0 true
execute if score @s curse_mark matches 4 run effect give @s blindness 40 0 true
execute if score @s curse_mark matches 5.. run effect give @s blindness 50 0 true

#清除诅咒印记
scoreboard players set @s curse_mark 0

#特效
particle soul ~ ~1 ~ 0.5 0.5 0.5 0 15 force
particle explosion ~ ~1 ~ 0.3 0.3 0.3 0 5 force

#声音
playsound entity.wither.hurt ambient @a ~ ~ ~ 1.0

#清理标记
tag @s remove curse_target

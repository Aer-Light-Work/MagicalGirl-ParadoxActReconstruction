#魔耗
scoreboard players remove @s MP 40

#cd
scoreboard players set @s cd1 10

#生效
tag @s add magic14_act
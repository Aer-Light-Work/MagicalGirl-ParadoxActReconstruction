#魔耗
scoreboard players remove @s MP 80

#cd
scoreboard players set @s cd2 120

#初始化射线计数
tag @a remove magic14b_attack
execute as @s positioned ^ ^ ^1 run tag @a[distance=..1.5,scores={ready=1,dead=0}] add magic14b_attack
execute as @s positioned ^ ^ ^2 run tag @a[distance=..1.5,scores={ready=1,dead=0}] add magic14b_attack
execute as @s positioned ^ ^ ^3 run tag @a[distance=..1.5,scores={ready=1,dead=0}] add magic14b_attack
execute as @s positioned ^ ^ ^4 run tag @a[distance=..1.5,scores={ready=1,dead=0}] add magic14b_attack
execute as @s positioned ^ ^ ^5 run tag @a[distance=..1.5,scores={ready=1,dead=0}] add magic14b_attack
execute as @s positioned ^ ^ ^6 run tag @a[distance=..1.5,scores={ready=1,dead=0}] add magic14b_attack
execute as @s positioned ^ ^ ^7 run tag @a[distance=..1.5,scores={ready=1,dead=0}] add magic14b_attack
tag @s remove magic14b_attack

tag @a remove magic14b_attack_from
tag @s add magic14b_attack_from
effect give @a[tag=magic14b_attack] levitation infinite 1 true

schedule function magics:effection/14_gravity_control/magic14b_effect/detect 3s
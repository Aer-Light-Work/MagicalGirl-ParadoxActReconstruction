tag @a remove magic14_a
$effect give @s levitation $(duration) 1 true

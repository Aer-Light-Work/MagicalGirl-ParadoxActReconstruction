
execute as @a[tag=magic14b_attack,scores={ready=1,dead=0},nbt={OnGround:true}] run function magics:effection/14_gravity_control/magic14b_effect/damage

effect clear @a[tag=magic14b_attack,scores={ready=1,dead=0}] levitation
execute as @a[tag=magic14b_attack,scores={ready=1,dead=0}] run attribute @s minecraft:gravity base set 10

execute if entity @a[tag=magic14b_attack,scores={ready=1,dead=0}] run schedule function magics:effection/14_gravity_control/magic14b_effect/detect 1t
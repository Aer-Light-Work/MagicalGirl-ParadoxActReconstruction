clone ~ ~-1 ~ ~ ~-1 ~ ~ ~ ~
setblock ~ ~ ~ air destroy
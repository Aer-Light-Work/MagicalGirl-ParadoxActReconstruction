execute if block ~ ~ ~ air run function magics:effection/14_gravity_control/magic14b_effect/particle
damage @s 10 fall by @p[tag=magic14b_attack_from]
attribute @s minecraft:gravity base set 0.08
tag @s remove magic14b_attack
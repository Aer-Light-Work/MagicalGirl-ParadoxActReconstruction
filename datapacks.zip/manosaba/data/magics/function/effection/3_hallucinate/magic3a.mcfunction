##组件头
#魔耗
scoreboard players remove @s MP 10
#cd
scoreboard players set @s cd1 40
##效果
scoreboard players operation @s general_probability = @s witchProg
scoreboard players add @s general_probability 50
execute store result storage magic:data probability int 0.4 run scoreboard players get @s general_probability
function magics:effection/3_hallucinate/magic3a_check/random with storage magic:data

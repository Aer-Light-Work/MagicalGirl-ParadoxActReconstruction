$tellraw @s $(log_check)
# $say $(log_Num)
$execute store result score @s logNum run random value 1..$(log_Num)
execute store result storage magic:data log_Num int 1 run scoreboard players remove @s logNum 1
function magics:effection/3_hallucinate/magic3b_check/new_log/log_get with storage magic:data
# $say new:$(log_Num)
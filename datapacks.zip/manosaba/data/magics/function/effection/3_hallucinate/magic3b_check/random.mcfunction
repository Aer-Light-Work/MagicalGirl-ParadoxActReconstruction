execute store result score @s general_random run random value 1..100
$execute if score @s general_random matches $(probability).. run return run function magics:effection/3_hallucinate/magic3b_check/last_log/log_check with storage game:logs

execute store result storage magic:data log_Num int 1 run scoreboard players get manosaba:data logNum
function magics:effection/3_hallucinate/magic3b_check/new_log/log_check with storage magic:data

$data modify storage magic:data log_check set from storage game:logs last_logs[$(log_Num)]

function magics:effection/3_hallucinate/magic3b_check/log_report with storage magic:data

##检验
#/function magics:effection/3_hallucinate/magic3b_check/log_get {"log_Num":1}
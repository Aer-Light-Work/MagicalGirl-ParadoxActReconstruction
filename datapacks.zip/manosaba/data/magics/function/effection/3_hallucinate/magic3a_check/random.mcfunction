execute store result score @s general_random run random value 1..100

$execute if score @s general_random matches $(probability).. run return run tellraw @s {"text":"没有看到有用的信息...",color:yellow}

execute store result storage supplies:data posZ int 1 run execute at @s as @n[tag=supply] run function magics:effection/3_hallucinate/magic3a_check/supply
execute store result storage supplies:data item_num int 1 run random value 9..25
function supplies:supply_frame/supply_give with storage supplies:data
scoreboard players set @s dwitchProg 1
tellraw @s {"text":"按照看到的画面找到了某样东西...",color:green}
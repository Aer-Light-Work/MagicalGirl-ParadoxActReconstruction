
execute if entity @s[tag=dining_table] run return 1000

execute if entity @s[tag=storage_room] run return 1001

execute if entity @s[tag=outside] run return 1002

execute if entity @s[tag=atrium] run return 1003

execute if entity @s[tag=shower_room] run return 1004

execute if entity @s[tag=libaray] run return 1005

execute if entity @s[tag=play_room] run return 1006

execute if entity @s[tag=lobby_table] run return 1007

execute if entity @s[tag=burn_room] run return 1008

execute if entity @s[tag=noah_studio] run return 1009

execute if entity @s[tag=infirmary] run return 1010

return 1000
#对所有有reach23a_active标签的玩家执行检测
execute as @a[tag=reach23a_active] at @s run function magics:effection/23_reach/magic23a_check

#如果还有reach23a_active玩家，继续循环
execute if entity @a[tag=reach23a_active] run schedule function magics:effection/23_reach/magic23a_tick 1t

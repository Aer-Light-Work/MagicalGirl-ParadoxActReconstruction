##组件头
#移除标签
tag @s remove reach23a_active

#移除属性修改
attribute @s minecraft:block_interaction_range modifier remove magic_23a
attribute @s minecraft:entity_interaction_range modifier remove magic_23a

#清理计分板
scoreboard players set @s reach23a_timer 0

#特效
particle dust{color:[0.4,0.8,1.0],scale:1.0} ~ ~1 ~ 0.5 0.5 0.5 0.1 10 force

#声音
execute as @s at @s run playsound entity.ender_eye.death ambient @a ~ ~ ~ 0.5


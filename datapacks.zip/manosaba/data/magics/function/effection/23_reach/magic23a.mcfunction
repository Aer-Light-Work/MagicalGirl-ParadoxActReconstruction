##组件头
#魔耗
scoreboard players remove @s MP 50
#cd
scoreboard players set @s cd1 10

##效果
#给予标签和初始化计时器
tag @s add reach23a_active
scoreboard players set @s reach23a_timer 0

#增加交互距离
attribute @s minecraft:block_interaction_range modifier add magic_23a 4.0 add_value
attribute @s minecraft:entity_interaction_range modifier add magic_23a 4.0 add_value

#特效
particle dust{color:[0.4,0.8,1.0],scale:1.5} ~ ~1 ~ 0.5 0.5 0.5 0.1 10 normal

#声音
execute as @s at @s run playsound entity.enderman.teleport ambient @a ~ ~ ~ 0.5

#启动检测循环
schedule function magics:effection/23_reach/magic23a_tick 1t

#增加计时器
scoreboard players add @s reach23a_timer 1

#持续粒子特效
particle dust{color:[0.4,0.8,1.0],scale:1.0} ~ ~1 ~ 0.3 0.3 0.3 0.05 3 force

#5秒(100tick)后自动移除
execute if score @s reach23a_timer matches 100.. run function magics:effection/23_reach/magic23a_end

##组件头
#移除标签
tag @s remove reach23b_active

#移除属性修改
attribute @s minecraft:block_interaction_range modifier remove magic_23b
attribute @s minecraft:entity_interaction_range modifier remove magic_23b

#清理计分板
scoreboard players set @s reach23b_timer 0

#特效
particle dust{color:[1.0,0.4,0.8],scale:1.0} ~ ~1 ~ 0.5 0.5 0.5 0.1 10 force

#声音
execute as @s at @s run playsound entity.ender_eye.death ambient @a ~ ~ ~ 0.5

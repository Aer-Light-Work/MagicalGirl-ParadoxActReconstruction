#增加计时器
scoreboard players add @s reach23b_timer 1

#持续粒子特效
particle dust{color:[1.0,0.4,0.8],scale:1.5} ~ ~1 ~ 0.5 0.5 0.5 0.05 5 force

#8秒(160tick)后自动移除
execute if score @s reach23b_timer matches 160.. run function magics:effection/23_reach/magic23b_end

##组件头
#魔耗
scoreboard players remove @s MP 80
#cd
scoreboard players set @s cd2 15

##效果
#标记玩家和初始化计时器
tag @s add reach23b_active
scoreboard players set @s reach23b_timer 0

#设置攻击距离和交互距离
attribute @s minecraft:block_interaction_range modifier add magic_23b 49.0 add_value
attribute @s minecraft:entity_interaction_range modifier add magic_23b 49.0 add_value

#特效
particle dust{color:[1.0,0.4,0.8],scale:2.0} ~ ~1 ~ 0.8 0.8 0.8 0.1 15 force

#声音
execute as @s at @s run playsound entity.ender_eye.launch ambient @a ~ ~ ~ 0.8 1.2

#启动检测循环
schedule function magics:effection/23_reach/magic23b_tick 1t

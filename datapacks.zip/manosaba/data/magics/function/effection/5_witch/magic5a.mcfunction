##组件头
#魔耗
scoreboard players remove @s MP 5
#cd
scoreboard players set @s cd1 60

##效果
execute as @s[tag=!5a_give] run function magics:magic_give/5/magic5a_give_curse
tag @s add 5a_give

effect give @s slowness 3 4 true
effect give @s hunger 3 0 true
effect give @s blindness 3 0 true

tag @s add 5a
schedule function magics:effection/5_witch/magic5a_mp 3s

#特效
particle witch ~ ~1.5 ~ 0.5 0.5 0.5 0 20 normal
#声音
execute as @s at @s run playsound block.enchantment_table.use ambient @a ~ ~ ~ 0.5
##效果
execute as @a[tag=5a] run scoreboard players add @s MP 40
execute as @a[tag=5a,scores={witchProg=..70}] run scoreboard players add @s dwitchProg 5 

#特效
execute as @a[tag=5a] run particle witch ~ ~1.5 ~ 0.5 0.5 0.5 0 20 normal
#声音
execute as @a[tag=5a] at @s run playsound block.enchantment_table.use ambient @a ~ ~ ~ 0.5

tag @a remove 5a
##组件头
#魔耗
scoreboard players remove @s MP 280
#cd
scoreboard players set @s cd2 666

##效果
#祝福
execute as @a[tag=5a_bless] run scoreboard players add @s undead 1
execute as @a[tag=5a_bless] run effect give @s resistance 3 4 true
execute as @a[tag=5a_bless] run summon lightning_bolt ~ ~ ~
execute as @a[tag=5a_bless] run tellraw @s [{text:"* "},{text:"你会得到恩宠",color:"green"}]
execute as @a[tag=5a_bless] run playsound item.trident.thunder ambient @a ~ ~ ~ 0.5
#诅咒
execute as @a[tag=5a_curse] run effect give @s wither 120 4 true
execute as @a[tag=5a_curse] run effect give @s blindness 120 4 true
execute as @a[tag=5a_curse] run summon lightning_bolt ~ ~ ~
execute as @a[tag=5a_curse] run tellraw @s [{text:"* "},{text:"成为祭品吧",color:"dark_red"}]
execute as @a[tag=5a_curse] run playsound item.trident.thunder ambient @a ~ ~ ~ 0.5


effect give @s resistance 3 4 true
summon lightning_bolt ~ ~ ~
playsound item.trident.thunder ambient @a ~ ~ ~ 0.5
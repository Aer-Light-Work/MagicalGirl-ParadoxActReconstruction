tag @a remove 5a_bless
tag @a remove 5a_curse

tag @s add 5a_curse
effect give @s slowness 3 4 false
effect give @s weakness 3 0 false
effect give @s blindness 3 0 false

tellraw @s [{text:"* "},{text:"头晕晕的，可能是被下咒了?",color:red}]
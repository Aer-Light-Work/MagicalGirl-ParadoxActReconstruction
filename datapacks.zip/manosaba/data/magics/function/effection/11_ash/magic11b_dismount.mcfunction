# dismount所有骑乘者
execute on passengers run ride @s dismount

# dismount效果
particle dust{color:[0.3,0.3,0.3],scale:2.0} ~ ~ ~ 1.2 1.2 1.2 0.1 40 force
particle explosion ~ ~ ~ 0.5 0.5 0.5 0.1 5 force
playsound entity.phantom.death ambient @a ~ ~ ~ 1.0

# 移除灵尘
kill @s
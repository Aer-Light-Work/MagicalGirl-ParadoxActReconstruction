# 11a尘术tick处理 - 只在有尘时运行，避免持续tick
execute as @e[type=marker,tag=magic11a_ash] at @s run function magics:effection/11_ash/magic11a_update

# 只有当还有尘存在时才继续调度，实现自动停止
execute if entity @e[type=marker,tag=magic11a_ash] run schedule function magics:effection/11_ash/magic11a_tick 1t
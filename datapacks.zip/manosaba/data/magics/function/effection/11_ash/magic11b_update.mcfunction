# 减少生命周期
execute store result score #spirit_lifetime raycast_distance run data get entity @s data.lifetime
scoreboard players remove #spirit_lifetime raycast_distance 1
execute store result entity @s data.lifetime int 1 run scoreboard players get #spirit_lifetime raycast_distance

# 如果生命周期结束或碰到方块，dismount玩家并移除灵尘
execute if score #spirit_lifetime raycast_distance matches ..0 run function magics:effection/11_ash/magic11b_dismount

execute unless block ~ ~-0.4 ~ #minecraft:air run function magics:effection/11_ash/magic11b_dismount
execute if score #spirit_lifetime raycast_distance matches ..0 run return 0
execute unless block ~ ~-0.4 ~ #minecraft:air run return 0

execute unless block ~ ~1 ~ #minecraft:air run function magics:effection/11_ash/magic11b_dismount
execute if score #spirit_lifetime raycast_distance matches ..0 run return 0
execute unless block ~ ~1 ~ #minecraft:air run return 0

# 获取骑乘者的视角方向并向前移动
execute on passengers at @s run tp @e[type=block_display,tag=magic11b_spirit_ash,distance=..1,limit=1] ~ ~ ~ ~ ~
tp @s ^ ^ ^0.4

# 生成灵尘粒子特效
particle dust{color:[0.3,0.3,0.3],scale:1.2} ~ ~ ~ 0.4 0.4 0.4 0.05 8 force
particle smoke ~ ~ ~ 0.3 0.3 0.3 0.02 5 force
particle ash ~ ~ ~ 0.5 0.5 0.5 0.01 3 force
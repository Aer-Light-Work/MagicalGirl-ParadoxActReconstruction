# 11b灵尘术tick处理 - 只在有灵尘时运行，避免持续tick
execute as @e[type=block_display,tag=magic11b_spirit_ash] at @s run function magics:effection/11_ash/magic11b_update

# 只有当还有灵尘存在时才继续调度，实现自动停止
execute if entity @e[type=block_display,tag=magic11b_spirit_ash] run schedule function magics:effection/11_ash/magic11b_tick 1t
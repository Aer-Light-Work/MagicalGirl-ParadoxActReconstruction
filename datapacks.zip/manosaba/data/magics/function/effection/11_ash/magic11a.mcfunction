##组件头
#魔耗
scoreboard players remove @s MP 40
#cd
scoreboard players set @s cd1 10

##效果
#召唤一团尘向前移动
execute anchored eyes positioned ^ ^ ^ run summon marker ^ ^ ^2 {Tags:["magic11a_ash"],data:{lifetime:40}}

# 设置尘的旋转信息和owner num
execute anchored eyes positioned ^ ^ ^ as @e[type=marker,tag=magic11a_ash,distance=..5,limit=1,sort=nearest] run data modify entity @s Rotation set from entity @p[distance=..10] Rotation
execute as @e[type=marker,tag=magic11a_ash,distance=..10,sort=nearest,limit=1] run scoreboard players operation @s num = @p[distance=..10] num

#启动尘效果处理 - 只在有尘时才调度
execute if entity @e[type=marker,tag=magic11a_ash] run schedule function magics:effection/11_ash/magic11a_tick 1t

#音效和粒子
playsound block.sand.break ambient @a ~ ~ ~ 1.0
particle dust{color:[0.5,0.4,0.3],scale:1.0} ~ ~1 ~ 0.5 0.5 0.5 0.1 20 force
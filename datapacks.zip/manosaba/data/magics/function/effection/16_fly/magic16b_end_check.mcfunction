#对所有标记为fly_target_end的玩家执行结束函数
execute as @a[tag=fly_target_end] run function magics:effection/16_fly/magic16b_end

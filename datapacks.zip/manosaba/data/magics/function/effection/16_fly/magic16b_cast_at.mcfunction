#给目标玩家添加标记
tag @s add fly_target
tag @s add fly_target_end

#启用浮空模式（10秒）
attribute @s minecraft:gravity base set 0

#设置浮空状态
scoreboard players set @s fly_state 1

#给予漂浮效果
effect give @s levitation 2 1 true

#通知目标
tellraw @s [{"text":"[浮空]","color":"#4169e1","bold":true},{"text":" 被施加了浮空诅咒！"}]

#特效
particle cloud ~ ~1 ~ 0.5 0.5 0.5 0 15 force
particle cloud ~ ~1 ~ 0.5 0.5 0.5 0 15 force

#声音
playsound entity.ender_dragon.flap ambient @a ~ ~ ~ 0.5

#设置10秒后恢复重力（使用标签确保在正确的玩家身上执行）
schedule function magics:effection/16_fly/magic16b_end_check 10s

#清理标记
tag @s remove fly_target

#检查当前状态并切换
execute if score @s fly_state matches 0 run attribute @s minecraft:gravity base set 0
execute if score @s fly_state matches 0 run tellraw @s [{"text":"[浮空]","color":"#87ceeb","bold":true},{"text":" 已启用浮空模式"}]
execute if score @s fly_state matches 0 run particle cloud ~ ~1 ~ 0.3 0.3 0.3 0 5 normal
execute if score @s fly_state matches 0 run effect give @s levitation 2 1 true

scoreboard players add @s fly_state 1

execute if score @s fly_state matches 2 run attribute @s minecraft:gravity base reset
execute if score @s fly_state matches 2 run tellraw @s [{"text":"[浮空]","color":"#87ceeb","bold":true},{"text":" 已禁用浮空模式"}]
execute if score @s fly_state matches 2 run particle cloud ~ ~1 ~ 0.3 0.3 0.3 0 5 normal
execute if score @s fly_state matches 2 run effect give @s minecraft:slow_falling 2 1
execute if score @s fly_state matches 2 run scoreboard players set @s fly_state 0

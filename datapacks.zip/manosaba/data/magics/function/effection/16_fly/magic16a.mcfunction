##组件头
#魔耗
scoreboard players remove @s MP 50
#cd
scoreboard players set @s cd1 4

##效果
#切换重力状态
function magics:effection/16_fly/magic16a_toggle

#给予漂浮效果

#特效
particle cloud ~ ~1 ~ 0.5 0.5 0.5 0 10 normal

#声音
execute as @s at @s run playsound entity.ender_dragon.flap ambient @a ~ ~ ~ 0.5

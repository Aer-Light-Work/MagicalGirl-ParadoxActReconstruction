#恢复重力
attribute @s minecraft:gravity base reset

#重置状态
scoreboard players set @s fly_state 0

#清理标记
tag @s remove fly_target_end

#通知玩家
tellraw @s [{"text":"[浮空]","color":"#4169e1","bold":true},{"text":" 浮空诅咒已解除"}]

#特效
particle cloud ~ ~1 ~ 0.3 0.3 0.3 0 5 normal

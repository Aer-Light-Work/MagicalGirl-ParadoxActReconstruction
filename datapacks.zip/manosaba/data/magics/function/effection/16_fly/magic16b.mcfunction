##组件头
#魔耗
scoreboard players remove @s MP 50
#cd
scoreboard players set @s cd2 8

#初始化射线计数
scoreboard players set @s raycast_distance 0

tag @s add fly_caster

execute at @s positioned ~ ~1.6 ~ run function magics:effection/16_fly/magic16b_cast_step

tag @s remove fly_caster

#特效和声音
execute as @s at @s run playsound entity.ender_dragon.flap ambient @a[distance=..30] ~ ~ ~ 0.5

#启用浮空模式
attribute @s minecraft:gravity base set 0

#更新状态
scoreboard players set @s fly_state 1

#提示
tellraw @s [{"text":"[浮空]","color":"#87ceeb","bold":true},{"text":" 已启用浮空模式"}]

#特效
particle cloud ~ ~1 ~ 0.3 0.3 0.3 0 5 normal

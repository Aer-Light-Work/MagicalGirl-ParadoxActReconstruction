##组件头
#魔耗
scoreboard players remove @s MP 30
#cd
scoreboard players set @s cd1 5

#生成位置标记
execute as @s at @s run summon armor_stand ^ ^ ^1 {Marker:1b,Invisible:1b,attributes:[{id:scale,base:0.001}],Tags:["magic1a","pos"],Silent:true}
#存储标记位置坐标
execute at @s as @n[type=armor_stand,tag=magic1a,tag=pos] store result score @s posX run data get entity @s Pos[0] 1000
execute at @s as @n[type=armor_stand,tag=magic1a,tag=pos] store result score @s posY run data get entity @s Pos[1] 1000
execute at @s as @n[type=armor_stand,tag=magic1a,tag=pos] store result score @s posZ run data get entity @s Pos[2] 1000
#存储玩家初始位置坐标
execute as @s store result score @s posX run data get entity @s Pos[0] 1000
execute as @s store result score @s posY run data get entity @s Pos[1] 1000
execute as @s store result score @s posZ run data get entity @s Pos[2] 1000
#作差
execute as @s at @s run scoreboard players operation @n[type=armor_stand,tag=magic1a,tag=pos] posX -= @s posX
execute as @s at @s run scoreboard players operation @n[type=armor_stand,tag=magic1a,tag=pos] posY -= @s posY
execute as @s at @s run scoreboard players operation @n[type=armor_stand,tag=magic1a,tag=pos] posZ -= @s posZ
#生成子弹&子弹外观
$execute as @s anchored eyes run summon arrow ^ ^ ^1 {item:{id:tipped_arrow,components:{potion_contents:{custom_color:13761279,custom_effects:[{id:"slowness",amplifier:1,duration:600,show_icon:false}]}}},Invulnerable:1b,Tags:["bullet","magic1a","pre"],Motion:[0.0,0.0,0.0],Owner:$(UUID),life:1199,damage:2,SoundEvent:block.glass.break,PierceLevel:10,LeftOwner:false}
execute as @s anchored eyes run summon item ^ ^ ^1 {Invulnerable:1b,Tags:["bulletAP","magic1a","pre"],Item:{id:ice,components:{enchantment_glint_override:1b}},PickupDelay:32767,Age:4800}
#压力值转换系数
scoreboard players set @s strplus 100
scoreboard players operation @s strplus += @s witchProg
#乘算压力系数
execute as @s at @s run scoreboard players operation @n[type=armor_stand,tag=magic1a,tag=pos] posX *= @s strplus
execute as @s at @s run scoreboard players operation @n[type=armor_stand,tag=magic1a,tag=pos] posY *= @s strplus
execute as @s at @s run scoreboard players operation @n[type=armor_stand,tag=magic1a,tag=pos] posZ *= @s strplus
#修改子弹动量
execute at @s as @e[tag=magic1a,tag=pre] store result entity @s Motion[0] double 0.000015 run scoreboard players get @n[type=armor_stand,tag=magic1a,tag=pos] posX
execute at @s as @e[tag=magic1a,tag=pre] store result entity @s Motion[1] double 0.000015 run scoreboard players get @n[type=armor_stand,tag=magic1a,tag=pos] posY
execute at @s as @e[tag=magic1a,tag=pre] store result entity @s Motion[2] double 0.000015 run scoreboard players get @n[type=armor_stand,tag=magic1a,tag=pos] posZ
#声音
execute as @s at @s run playsound block.amethyst_block.chime ambient @a ~ ~ ~ 0.5
execute as @s at @s run playsound block.amethyst_block.hit ambient @a ~ ~ ~ 0.5

##组件尾
execute at @s run tag @n[type=arrow,tag=magic1a,tag=pre] remove pre
execute at @s run tag @n[type=item,tag=magic1a,tag=pre] remove pre
execute at @s run kill @n[type=armor_stand,tag=magic1a,tag=pos]
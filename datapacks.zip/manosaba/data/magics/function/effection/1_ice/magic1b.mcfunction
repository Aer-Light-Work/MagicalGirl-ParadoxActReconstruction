##组件头
#魔耗
execute as @a[tag=1b] run scoreboard players remove @s MP 100
#cd-calc.
execute as @a[tag=1b] run scoreboard players set @s cd2 180
execute as @a[tag=1b] run scoreboard players set @s strplus 50
execute as @a[tag=1b] run scoreboard players operation @s witchProg -= @s strplus
execute as @a[tag=1b] run scoreboard players operation @s cd2 -= @s witchProg
execute as @a[tag=1b] run scoreboard players operation @s cd2 -= @s witchProg
execute as @a[tag=1b] run scoreboard players operation @s witchProg += @s strplus
execute as @a[tag=1b] run scoreboard players set @s strplus 0

#item
item replace entity @a[tag=1b] hotbar.7 with coal[custom_name=[{text:"❆",color:white,bold:false,italic:false},{text:"凝剑",color:aqua,bold:true,italic:false},{text:"❆",color:white,bold:false,italic:false}],lore=[{text:""},{text:"坚冰所凝成的长剑，锋利程度尚可",color:white,bold:false,italic:false}],max_damage=999,damage=0,custom_data={noDrop:1b,sharp:1b},item_model="magics:magic1b_inhand",attribute_modifiers=[{type:attack_damage,slot:"hand",id:"manosaba:magic1b",amount:5,operation:"add_value"},{type:attack_speed,slot:"hand",id:"manosaba:magic1b",amount:-3,operation:"add_value"},{type:sweeping_damage_ratio,slot:"hand",id:"manosaba:magic1b",amount:0.5,operation:"add_value"}],!max_stack_size]

#sound
execute as @a[tag=1b] at @s run playsound block.beacon.activate ambient @a[distance=..10] ~ ~ ~ 0.8

#tag change
tag @a[tag=1b] add 1b2
tag @a[tag=1b] remove 1b

#持续时间终止
schedule function magics:effection/1_ice/magic1b_over 10s
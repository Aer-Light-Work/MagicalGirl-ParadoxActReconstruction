##组件头
#魔耗
scoreboard players remove @s MP 60
#cd
scoreboard players set @s cd1 30
scoreboard players set @s damage_dealt 0
##效果
#给予怪力标签和初始化计时器
tag @s add power13a
scoreboard players set @s power13a_timer 0

#设置属性 - 使用不同的修饰符ID
attribute @s minecraft:attack_knockback modifier add magic_13a_knockback 4 add_value
attribute @s minecraft:attack_damage modifier add magic_13a_damage 8 add_value

#音效和粒子
playsound entity.lightning_bolt.thunder ambient @a ~ ~ ~ 1.0
particle electric_spark ~ ~1 ~ 0.5 0.5 0.5 0.1 10 force

#启动检测循环
schedule function magics:effection/13_power/magic13a_tick 1t

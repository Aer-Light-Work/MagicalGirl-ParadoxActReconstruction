#增加计时器
scoreboard players add @s power13a_timer 1

#持续粒子特效
particle electric_spark ~ ~1 ~ 0.3 0.3 0.3 0.05 3 force

#检测是否造成伤害（damage_dealt > 0 或 absorbed > 0 或 resisted > 0）
execute if score @s damage_dealt matches 1.. run function magics:effection/13_power/magic13a_hit
execute if score @s damage_dealt_absorbed matches 1.. run function magics:effection/13_power/magic13a_hit
execute if score @s damage_dealt_resisted matches 1.. run function magics:effection/13_power/magic13a_hit

#检测后重置伤害计数
execute if score @s damage_dealt matches 1.. run scoreboard players set @s damage_dealt 0
execute if score @s damage_dealt_absorbed matches 1.. run scoreboard players set @s damage_dealt_absorbed 0
execute if score @s damage_dealt_resisted matches 1.. run scoreboard players set @s damage_dealt_resisted 0

#10秒(200tick)后自动移除
execute if score @s power13a_timer matches 200.. run function magics:effection/13_power/magic13a_end

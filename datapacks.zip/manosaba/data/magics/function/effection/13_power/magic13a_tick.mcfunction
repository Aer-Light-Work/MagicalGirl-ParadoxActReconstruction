#对所有有power13a标签的玩家执行检测
execute as @a[tag=power13a] at @s run function magics:effection/13_power/magic13a_check
#如果还有power13a玩家，继续循环
execute if entity @a[tag=power13a] run schedule function magics:effection/13_power/magic13a_tick 1t

#移除怪力效果
tag @s remove power13a

#恢复属性 - 移除添加的修饰符
attribute @s minecraft:attack_knockback modifier remove magic_13a_knockback
attribute @s minecraft:attack_damage modifier remove magic_13a_damage

#清理计分板
scoreboard players set @s power13a_timer 0

#攻击命中时的效果
particle electric_spark ~ ~1 ~ 1.0 1.0 1.0 0.2 20 force
playsound entity.lightning_bolt.impact ambient @a ~ ~ ~ 1.0
playsound entity.player.attack.strong ambient @a ~ ~ ~ 1.0

#立即移除效果
function magics:effection/13_power/magic13a_end

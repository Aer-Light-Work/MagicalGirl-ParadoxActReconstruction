#魔耗
scoreboard players remove @s MP 90

#cd
scoreboard players set @s cd2 120

#给予力量II效果 30秒(600tick)
effect give @s strength 30 1 false

#音效 - 多层次的音效
playsound entity.lightning_bolt.impact ambient @a ~ ~ ~ 1.0
playsound entity.player.attack.strong ambient @a ~ ~ ~ 1.2
playsound block.anvil.land ambient @a ~ ~ ~ 0.8

#粒子特效 - 多种粒子组合
particle electric_spark ~ ~1 ~ 1.0 1.0 1.0 0.3 20 force
particle explosion ~ ~1 ~ 0.5 0.5 0.5 0.1 10 force
particle flame ~ ~1 ~ 0.8 0.8 0.8 0.2 15 force

# 减少生命周期
execute store result score #firework_lifetime raycast_distance run data get entity @s data.lifetime
scoreboard players remove #firework_lifetime raycast_distance 1
execute store result entity @s data.lifetime int 1 run scoreboard players get #firework_lifetime raycast_distance

# 如果生命周期结束，播放爆炸效果并移除
execute if score #firework_lifetime raycast_distance matches ..0 run particle firework ~ ~ ~ 1 1 1 0.1 5 force
execute if score #firework_lifetime raycast_distance matches ..0 run playsound entity.firework_rocket.blast ambient @a[distance=..40] ~ ~ ~ 2.0
execute if score #firework_lifetime raycast_distance matches ..0 run kill @s
execute if score #firework_lifetime raycast_distance matches ..0 run return 0

# 向上移动
tp @s ~ ~0.4 ~

# 生成烟花轨迹粒子
particle firework ~ ~ ~ 0.1 0.1 0.1 0.01 1 force
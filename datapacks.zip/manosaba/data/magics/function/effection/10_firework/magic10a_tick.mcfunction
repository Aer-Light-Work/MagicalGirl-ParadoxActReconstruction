# 10a烟花tick处理 - 只在有烟花时运行，避免持续tick
execute as @e[type=marker,tag=magic10a_firework] at @s run function magics:effection/10_firework/magic10a_update

# 只有当还有烟花存在时才继续调度，实现自动停止
execute if entity @e[type=marker,tag=magic10a_firework] run schedule function magics:effection/10_firework/magic10a_tick 1t
##组件头
#魔耗
scoreboard players remove @s MP 80
#cd
scoreboard players set @s cd2 10

##效果
#向前方发射四个烟花marker，分散角度
# 使用anchor eyes确保从眼部高度发射
execute anchored eyes positioned ^ ^ ^ rotated ~-15 ~ run summon marker ^ ^ ^2 {Tags:["magic10b_firework","firework_left2"],data:{lifetime:80,owner_uuid:[I;0,0,0,0]}}
execute anchored eyes positioned ^ ^ ^ rotated ~-5 ~ run summon marker ^ ^ ^2 {Tags:["magic10b_firework","firework_left1"],data:{lifetime:80,owner_uuid:[I;0,0,0,0]}}
execute anchored eyes positioned ^ ^ ^ rotated ~5 ~ run summon marker ^ ^ ^2 {Tags:["magic10b_firework","firework_right1"],data:{lifetime:80,owner_uuid:[I;0,0,0,0]}}
execute anchored eyes positioned ^ ^ ^ rotated ~15 ~ run summon marker ^ ^ ^2 {Tags:["magic10b_firework","firework_right2"],data:{lifetime:80,owner_uuid:[I;0,0,0,0]}}

# 设置每个烟花的旋转信息
execute anchored eyes positioned ^ ^ ^ rotated ~-15 ~ as @e[type=marker,tag=firework_left2,distance=..5,limit=1,sort=nearest] run data modify entity @s Rotation set from entity @p[distance=..10] Rotation
execute anchored eyes positioned ^ ^ ^ rotated ~-15 ~ as @e[type=marker,tag=firework_left2,distance=..5,limit=1,sort=nearest] store result score #player_rotation raycast_distance run data get entity @p[distance=..10] Rotation[0]
execute anchored eyes positioned ^ ^ ^ rotated ~-15 ~ as @e[type=marker,tag=firework_left2,distance=..5,limit=1,sort=nearest] run scoreboard players remove #player_rotation raycast_distance 15
execute anchored eyes positioned ^ ^ ^ rotated ~-15 ~ as @e[type=marker,tag=firework_left2,distance=..5,limit=1,sort=nearest] store result entity @s Rotation[0] float 1 run scoreboard players get #player_rotation raycast_distance

execute anchored eyes positioned ^ ^ ^ rotated ~-5 ~ as @e[type=marker,tag=firework_left1,distance=..5,limit=1,sort=nearest] run data modify entity @s Rotation set from entity @p[distance=..10] Rotation
execute anchored eyes positioned ^ ^ ^ rotated ~-5 ~ as @e[type=marker,tag=firework_left1,distance=..5,limit=1,sort=nearest] store result score #player_rotation raycast_distance run data get entity @p[distance=..10] Rotation[0]
execute anchored eyes positioned ^ ^ ^ rotated ~-5 ~ as @e[type=marker,tag=firework_left1,distance=..5,limit=1,sort=nearest] run scoreboard players remove #player_rotation raycast_distance 5
execute anchored eyes positioned ^ ^ ^ rotated ~-5 ~ as @e[type=marker,tag=firework_left1,distance=..5,limit=1,sort=nearest] store result entity @s Rotation[0] float 1 run scoreboard players get #player_rotation raycast_distance

execute anchored eyes positioned ^ ^ ^ rotated ~5 ~ as @e[type=marker,tag=firework_right1,distance=..5,limit=1,sort=nearest] run data modify entity @s Rotation set from entity @p[distance=..10] Rotation
execute anchored eyes positioned ^ ^ ^ rotated ~5 ~ as @e[type=marker,tag=firework_right1,distance=..5,limit=1,sort=nearest] store result score #player_rotation raycast_distance run data get entity @p[distance=..10] Rotation[0]
execute anchored eyes positioned ^ ^ ^ rotated ~5 ~ as @e[type=marker,tag=firework_right1,distance=..5,limit=1,sort=nearest] run scoreboard players add #player_rotation raycast_distance 5
execute anchored eyes positioned ^ ^ ^ rotated ~5 ~ as @e[type=marker,tag=firework_right1,distance=..5,limit=1,sort=nearest] store result entity @s Rotation[0] float 1 run scoreboard players get #player_rotation raycast_distance

execute anchored eyes positioned ^ ^ ^ rotated ~15 ~ as @e[type=marker,tag=firework_right2,distance=..5,limit=1,sort=nearest] run data modify entity @s Rotation set from entity @p[distance=..10] Rotation
execute anchored eyes positioned ^ ^ ^ rotated ~15 ~ as @e[type=marker,tag=firework_right2,distance=..5,limit=1,sort=nearest] store result score #player_rotation raycast_distance run data get entity @p[distance=..10] Rotation[0]
execute anchored eyes positioned ^ ^ ^ rotated ~15 ~ as @e[type=marker,tag=firework_right2,distance=..5,limit=1,sort=nearest] run scoreboard players add #player_rotation raycast_distance 15
execute anchored eyes positioned ^ ^ ^ rotated ~15 ~ as @e[type=marker,tag=firework_right2,distance=..5,limit=1,sort=nearest] store result entity @s Rotation[0] float 1 run scoreboard players get #player_rotation raycast_distance

#设置所有烟花的owner
execute as @e[type=marker,tag=magic10b_firework,distance=..10] run data modify entity @s data.owner_uuid set from entity @p[distance=..10] UUID

#启动烟花效果处理 - 只在有烟花时才调度
execute if entity @e[type=marker,tag=magic10b_firework] run schedule function magics:effection/10_firework/magic10b_tick 1t

#音效
playsound entity.firework_rocket.launch ambient @a ~ ~ ~ 1.0
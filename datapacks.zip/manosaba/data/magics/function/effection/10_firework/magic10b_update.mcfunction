# 减少生命周期
execute store result score #firework_lifetime raycast_distance run data get entity @s data.lifetime
scoreboard players remove #firework_lifetime raycast_distance 1
execute store result entity @s data.lifetime int 1 run scoreboard players get #firework_lifetime raycast_distance

# 如果生命周期结束，移除烟花
execute if score #firework_lifetime raycast_distance matches ..0 run particle firework ~ ~ ~ 1 1 1 0.1 5 force
execute if score #firework_lifetime raycast_distance matches ..0 run playsound entity.firework_rocket.blast ambient @a[distance=..40] ~ ~ ~ 2.0
execute if score #firework_lifetime raycast_distance matches ..0 run kill @s
execute if score #firework_lifetime raycast_distance matches ..0 run return 0

# 向前移动烟花 - 使用简单的前进移动
tp @s ^ ^ ^0.6



# 生成烟花粒子特效
particle firework ~ ~ ~ 0.1 0.1 0.1 0.02 3 force
particle flame ~ ~ ~ 0.1 0.1 0.1 0.01 2 force

# 检测周围的实体并给予发光效果
effect give @e[type=!marker,distance=..4] glowing 10 0
# 检测周围的实体并给予清除隐身

effect clear @a[distance=..4] invisibility

# 如果碰到方块，提前结束
execute unless block ~ ~ ~ #minecraft:air run kill @s
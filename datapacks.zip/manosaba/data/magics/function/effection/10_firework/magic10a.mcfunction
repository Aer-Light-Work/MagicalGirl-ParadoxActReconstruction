##组件头
#魔耗
scoreboard players remove @s MP 80
#cd
scoreboard players set @s cd1 60

##效果
#向头顶发射烟花效果 - 使用schedule而不是持续tick
summon marker ~ ~3 ~ {Tags:["magic10a_firework"],data:{lifetime:40,owner_uuid:[I;0,0,0,0]}}
data modify entity @e[type=marker,tag=magic10a_firework,limit=1,sort=nearest] data.owner_uuid set from entity @s UUID

#给自己发光效果
effect give @s glowing 30 0

title @a[distance=0.01..15] title {text:"\u0001",font:"manosaba:flash"}
playsound manosaba:ear_ringing ambient @a[distance=0.01..15] ~ ~ ~ 1.0

#启动烟花效果处理 - 使用递归schedule
schedule function magics:effection/10_firework/magic10a_tick 1t

#音效
playsound entity.firework_rocket.launch ambient @a ~ ~ ~ 1.0
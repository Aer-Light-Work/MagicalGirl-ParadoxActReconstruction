#增加诅咒计数
scoreboard players add @s eye_curse_count 1

#根据诅咒次数计算生命值上限减少值
#每次诅咒-5，所以总减少值 = 诅咒次数 * 5
#移除旧的诅咒modifier
attribute @s minecraft:max_health modifier remove eye_curse_health

#添加新的诅咒modifier（根据诅咒次数）
execute if score @s eye_curse_count matches 1 run attribute @s minecraft:max_health modifier add eye_curse_health -5 add_value
execute if score @s eye_curse_count matches 2 run attribute @s minecraft:max_health modifier add eye_curse_health -10 add_value
execute if score @s eye_curse_count matches 3 run attribute @s minecraft:max_health modifier add eye_curse_health -15 add_value
execute if score @s eye_curse_count matches 4 run attribute @s minecraft:max_health modifier add eye_curse_health -20 add_value
execute if score @s eye_curse_count matches 5.. run attribute @s minecraft:max_health modifier add eye_curse_health -25 add_value

#获得暂时的失明、缓慢、虚弱
effect give @s blindness 10 0 true
effect give @s slowness 10 1 true
effect give @s weakness 10 1 true

#移除被洞察效果
tag @s remove eye_insight
playsound minecraft:entity.elder_guardian.curse player @s ~ ~ ~ 1 0.95

#给目标提示（显示诅咒次数和警告）
execute if score @s eye_curse_count matches 1 run tellraw @s [{text:"✗ "},{text:"你遭到了诅咒！",color:"#8b0000",bold:true},{text:" [1/5]",color:gray}]
execute if score @s eye_curse_count matches 2 run tellraw @s [{text:"✗ "},{text:"你遭到了诅咒！",color:"#8b0000",bold:true},{text:" [2/5]",color:gray}]
execute if score @s eye_curse_count matches 3 run tellraw @s [{text:"✗ "},{text:"你遭到了诅咒！",color:"#8b0000",bold:true},{text:" [3/5]",color:gray}]
execute if score @s eye_curse_count matches 4 run tellraw @s [{text:"✗ "},{text:"你遭到了诅咒！",color:"#8b0000",bold:true},{text:" [4/5] "},{text:"⚠ 再诅咒一次将死亡！",color:"#ff0000",bold:true}]
execute if score @s eye_curse_count matches 5.. run tellraw @s [{text:"✗ "},{text:"你遭到了诅咒！",color:"#8b0000",bold:true},{text:" [5/5] "},{text:"💀 致命诅咒！",color:"#ff0000",bold:true}]

#5次诅咒时直接杀死目标
execute if score @s eye_curse_count matches 5.. run kill @s

#特效
particle soul ~ ~ ~ 0.5 1 0.5 0 20 force

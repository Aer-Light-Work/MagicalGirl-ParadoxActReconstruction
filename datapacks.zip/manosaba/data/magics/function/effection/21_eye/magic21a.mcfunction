##组件头
#魔耗
scoreboard players remove @s MP 15
#cd
scoreboard players set @s cd1 2

##效果
#标记施法者
tag @s add eye_caster

#面向最近的玩家
execute at @s run rotate @s facing entity @e[type=player,tag=!eye_caster,limit=1,sort=nearest]

#获取目标玩家的UUID并记录
execute at @s run function magics:effection/21_eye/magic21a_mark

#特效
particle end_rod ~ ~1.6 ~ 0.3 0.3 0.3 0.5 10 normal

#声音/
playsound minecraft:entity.elder_guardian.curse player @s ~ ~ ~ 1 0.95


tag @s remove eye_caster

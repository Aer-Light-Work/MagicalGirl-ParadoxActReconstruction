#记录被洞察玩家的UUID到计分板
scoreboard players operation @s eye_insight_num = @s UUID0

##2魔法的旋转粒子
#旋转
execute at @e[type=armor_stand,nbt={data:{doctor:b}}] as @n[type=armor_stand,nbt={data:{doctor:b}}] run rotate @s ~10 ~

#强化
execute at @e[type=armor_stand,nbt={data:{doctor:b}}] run \
     particle glow ^ ^ ^6 0.1 0.1 0.1 0 3 normal @a[tag=magic2a]
execute at @e[type=armor_stand,nbt={data:{doctor:b}}] run \
     particle glow ^ ^ ^-6 0.1 0.1 0.1 0 3 normal @a[tag=magic2a]

##2魔法持续粒子
#检查魔女
execute at @a[tag=magic2b,scores={role=3}] run particle raid_omen ~ ~3 ~ 0.5 0.5 0.5 1 1 normal @a[tag=2b]
#检查第三方
execute at @a[tag=magic2b,scores={role=4}] run particle reverse_portal ~ ~3 ~ 0.5 0.5 0.5 1 1 normal @a[tag=2b]
#检查压力50以上的玩家
execute at @a[tag=magic2b,scores={witchProg=50..,role=1}] run particle wax_on ~ ~3 ~ 0.5 0.5 0.5 1 1 normal @a[tag=2b]
execute at @a[tag=magic2b,scores={witchProg=50..,role=2}] run particle wax_on ~ ~3 ~ 0.5 0.5 0.5 1 1 normal @a[tag=2b]
#安全玩家
execute at @a[tag=magic2b,scores={witchProg=..49,role=1}] run particle composter ~ ~3 ~ 0.5 0.5 0.5 1 1 normal @a[tag=2b]
execute at @a[tag=magic2b,scores={witchProg=..49,role=2}] run particle composter ~ ~3 ~ 0.5 0.5 0.5 1 1 normal @a[tag=2b]

schedule function magics:effection/2_doctor/magic2b_tick 1t
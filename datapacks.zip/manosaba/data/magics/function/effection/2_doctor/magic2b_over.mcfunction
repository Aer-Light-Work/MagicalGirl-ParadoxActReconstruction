#tag-
tag @a[tag=2b] remove 2b
tag @a[tag=magic2b] remove magic2b
##2魔法的旋转粒子
#旋转
execute at @e[type=armor_stand,nbt={data:{doctor:a}}] as @n[type=armor_stand,nbt={data:{doctor:a}}] run rotate @s ~10 ~
#普通
execute at @e[type=armor_stand,nbt={data:{doctor:a}}] run \
     particle glow ^ ^ ^3.5 0.1 0.1 0.1 0 1 normal @a[tag=magic2a]
execute at @e[type=armor_stand,nbt={data:{doctor:a}}] run \
     particle glow ^ ^ ^-3.5 0.1 0.1 0.1 0 1 normal @a[tag=magic2a]

schedule function magics:effection/2_doctor/magic2a_tick 1t
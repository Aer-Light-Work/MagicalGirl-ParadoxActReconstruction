kill @e[type=armor_stand,nbt={data:{doctor:a}},predicate=magics:2_doctor/magic2a_clear]
kill @e[type=armor_stand,nbt={data:{doctor:b}},predicate=magics:2_doctor/magic2a_clear]
tag @a remove magic2a
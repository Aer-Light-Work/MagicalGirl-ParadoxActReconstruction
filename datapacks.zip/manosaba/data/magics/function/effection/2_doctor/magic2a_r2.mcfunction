##组件头
#魔耗
scoreboard players remove @s MP 35
#cd
scoreboard players set @s cd1 15

##特效
#选择可见目标
tag @s add magic2a
#生成
summon armor_stand ~ ~1 ~ \
    {\
        Invisible:true,\
        NoGravity:true,\
        DisabledSlots:16191,\
        data:{doctor:b},\
        Rotation:[0,0],\
        attributes:[{id:scale,base:0.01}],\
        active_effects:[{id:regeneration,amplifier:10,duration:20,show_particles:false}],\
        Silent:true\
    }
#清除
schedule function magics:effection/2_doctor/magic2a_clear 21t

##检查周围玩家状态
#检查虚假压力
execute if entity @a[distance=0.1..3.5,scores={fake_pressure=0..}] run return run tellraw @s [{text:"* "},{text:"周围的魔力像暗流涌动",color:"gold"}]

#检查压力60以上的玩家
execute if entity @a[distance=0.1..3.5,scores={witchProg=60..}] run return run tellraw @s [{text:"* "},{text:"周围的魔力像暗流涌动",color:"gold"}]

#检查压力35以上的玩家
execute if entity @a[distance=0.1..3.5,scores={witchProg=35..}] run return run tellraw @s [{text:"* "},{text:"周围的魔力有微弱波动",color:"yellow"}]

tellraw @s [{text:"* "},{text:"周围的魔力比较平静，目前是的",color: "dark_green"}]

##组件尾
scoreboard players set @s strplus 0
execute as @s run scoreboard players remove @s cd2 10
execute if entity @s[scores={cd2=..0}] run scoreboard players set @s cd2 1
##组件头
#魔耗
execute as @s run scoreboard players remove @s MP 100
#cd-calc.
execute as @s run scoreboard players set @s cd2 210
execute as @s run scoreboard players set @s strplus 60
execute as @s run scoreboard players operation @s witchProg -= @s strplus
execute as @s run scoreboard players operation @s cd2 -= @s witchProg
execute as @s run scoreboard players operation @s cd2 -= @s witchProg
execute as @s run scoreboard players operation @s witchProg += @s strplus
execute as @s run scoreboard players set @s strplus 0

##粒子
#选择可见目标
tag @s add magic2a
#生成
summon armor_stand ~ ~1 ~ \
    {\
        Invisible:true,\
        NoGravity:true,\
        DisabledSlots:16191,\
        data:{doctor:b},\
        Rotation:[0,0],\
        attributes:[{id:scale,base:0.01}],\
        active_effects:[{id:regeneration,amplifier:10,duration:20,show_particles:false}]\
    }
#清除
schedule function magics:effection/2_doctor/magic2a_clear 21t

#tag
execute as @a[distance=0.1..6] run tag @s add magic2b

#声音
playsound block.beacon.activate ambient @s ~ ~ ~ 0.8

#tag changes
tag @s add 2b

#持续时间终止
schedule function magics:effection/2_doctor/magic2b_over 3s
##组件头
#魔耗
scoreboard players remove @s MP 50
#cd
scoreboard players set @s cd1 3

#随机选择药水类型 (0-5)
scoreboard players set @s potion_random 0
execute store result score @s potion_random run random value 0..5

#根据随机数给予不同的药水
execute if score @s potion_random matches 0 run give @s lingering_potion[potion_contents={custom_color:8454144,custom_effects:[{id:wither,duration:600,amplifier:1}]},custom_name=[{"text":"凋零药水","italic":false}],max_stack_size=64]
execute if score @s potion_random matches 1 run give @s lingering_potion[potion_contents={custom_color:10329495,custom_effects:[{id:slowness,duration:800,amplifier:2}]},custom_name=[{"text":"缓慢药水","italic":false}],max_stack_size=64]
execute if score @s potion_random matches 2 run give @s lingering_potion[potion_contents={custom_color:11546150,custom_effects:[{id:instant_health,duration:600,amplifier:1}]},custom_name=[{"text":"治疗药水","italic":false}],max_stack_size=64]
execute if score @s potion_random matches 3 run give @s lingering_potion[potion_contents={custom_color:11546150,custom_effects:[{id:blindness,duration:600,amplifier:1}]},custom_name=[{"text":"失明药水","italic":false}],max_stack_size=64]
execute if score @s potion_random matches 4 run give @s lingering_potion[potion_contents={custom_color:3847130,custom_effects:[{id:speed,duration:600,amplifier:2}]},custom_name=[{"text":"速度药水","italic":false}],max_stack_size=64]
execute if score @s potion_random matches 5 run give @s lingering_potion[potion_contents={custom_color:16383998,custom_effects:[{id:levitation,duration:600,amplifier:1}]},custom_name=[{"text":"漂浮药水","italic":false}],max_stack_size=64]

#特效和声音
execute as @s at @s run playsound item.bottle.fill ambient @a[distance=..30] ~ ~ ~ 0.5

#提示
tellraw @s [{text:"[药水]",color:light_purple,bold:true},{text:" 获得一瓶随机滞留药水"}]

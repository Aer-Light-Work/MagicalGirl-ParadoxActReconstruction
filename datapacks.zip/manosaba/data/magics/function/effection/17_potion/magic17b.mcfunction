##组件头
#魔耗
scoreboard players remove @s MP 90
#cd
scoreboard players set @s cd2 6

#随机选择药水类型 (0-5)
scoreboard players set @s potion_random 0
execute store result score @s potion_random run random value 0..5

#根据随机数给予不同的药水
execute if score @s potion_random matches 0 run give @s lingering_potion[potion_contents={custom_color:4673362,custom_effects:[{id:invisibility,duration:1200,amplifier:1}]},custom_name=[{"text":"隐身药水","italic":false}],rarity=rare,max_stack_size=64,tooltip_display={hidden_components:[enchantments]}] 1
execute if score @s potion_random matches 1 run give @s lingering_potion[potion_contents={custom_color:16351261,custom_effects:[{id:instant_damage,duration:1200,amplifier:2}]},custom_name=[{"text":"重伤药水","italic":false}],rarity=rare,max_stack_size=64,tooltip_display={hidden_components:[enchantments]}] 1
execute if score @s potion_random matches 2 run give @s lingering_potion[potion_contents={custom_color:1481884,custom_effects:[{id:resistance,duration:1200,amplifier:2},{id:absorption,duration:1200,amplifier:1}]},custom_name=[{"text":"防御药水","italic":false}],rarity=rare,max_stack_size=64,tooltip_display={hidden_components:[enchantments]}] 1
execute if score @s potion_random matches 3 run give @s lingering_potion[potion_contents={custom_color:1908001,custom_effects:[{id:darkness,duration:2400,amplifier:1},{id:weakness,duration:1200,amplifier:1}]},custom_name=[{"text":"恐惧药水","italic":false}],rarity=rare,max_stack_size=64,tooltip_display={hidden_components:[enchantments]}] 1
execute if score @s potion_random matches 4 run give @s lingering_potion[potion_contents={custom_color:16383998,custom_effects:[{id:levitation,duration:700,amplifier:1},{id:slow_falling,duration:1500,amplifier:1}]},custom_name=[{"text":"浮空药水","italic":false}],rarity=rare,max_stack_size=64,tooltip_display={hidden_components:[enchantments]}] 1
execute if score @s potion_random matches 5 run give @s lingering_potion[potion_contents={custom_color:16383998,custom_effects:[{id:regeneration,duration:5000,amplifier:1},{id:instant_health,duration:100,amplifier:1}]},custom_name=[{"text":"治愈药水","italic":false}],rarity=rare,max_stack_size=64,tooltip_display={hidden_components:[enchantments]}] 1

#特效和声音
execute as @s at @s run playsound item.bottle.fill ambient @a[distance=..30] ~ ~ ~ 0.8

#提示
tellraw @s [{text:"[药水]",color:dark_purple,bold:true},{text:" 获得一瓶随机滞留药水"}]

execute as @a[tag=4a] run attribute @s movement_speed modifier remove magic_4a
tag @a[tag=4a] remove 4a
##效果
execute as @a[tag=4b] run effect clear @s invisibility
execute as @a[tag=4b] run effect clear @s resistance
execute as @a[tag=4b] run effect clear @s weakness
#速度
execute as @a[tag=4b] run attribute @s movement_speed modifier remove magic_4b
execute as @a[tag=4b] run attribute @s scale modifier remove magic_4b
#清除
execute as @a[tag=4b] run kill @n[type=cat,tag=4b_cat]
#特效
execute at @a[tag=4b] run particle cloud ~ ~ ~ 0.5 0.5 0.5 0 10 normal

tag @a remove 4b
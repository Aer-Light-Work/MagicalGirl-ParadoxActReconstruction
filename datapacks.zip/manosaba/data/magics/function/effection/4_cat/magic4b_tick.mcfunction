execute as @a[tag=4b] run tp @n[tag=4b_cat,type=cat] @s

schedule function magics:effection/4_cat/magic4b_tick 1t
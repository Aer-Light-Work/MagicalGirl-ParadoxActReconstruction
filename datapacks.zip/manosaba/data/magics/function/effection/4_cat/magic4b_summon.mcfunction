$summon cat ~ ~ ~ {\
variant:"minecraft:red",\
Health:20,\
Age:1,\
CollarColor:4,\
InLove:2147483647,\
attributes:[{id:max_health,base:20},{id:scale,base:1}],\
Owner:$(UUID),\
DeathTime:20,DeathLootTable:"minecraft:entities/villager",\
Invulnerable:true,\
Tags:["4b_cat"],\
NoAI:true}

execute as @s[team=num1] run team join num1 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num2] run team join num2 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num3] run team join num3 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num4] run team join num4 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num5] run team join num5 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num6] run team join num6 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num7] run team join num7 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num8] run team join num8 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num9] run team join num9 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num10] run team join num10 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num11] run team join num11 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num12] run team join num12 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num13] run team join num13 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num14] run team join num14 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num15] run team join num15 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num16] run team join num16 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num17] run team join num17 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num18] run team join num18 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num19] run team join num19 @n[type=cat,tag=4b_cat,distance=..0.5]
execute as @s[team=num20] run team join num20 @n[type=cat,tag=4b_cat,distance=..0.5]
##组件头
#魔耗
scoreboard players remove @s MP 80
#cd
scoreboard players set @s cd2 180

tag @s add 4b

#召唤
function magics:effection/4_cat/magic4b_summon with entity @s

#给予速度
attribute @s[scores={witchProg=..60}] movement_speed modifier add magic_4b 0.05 add_value
attribute @s[scores={witchProg=61..70}] movement_speed modifier add magic_4b 0.0625 add_value
attribute @s[scores={witchProg=71..80}] movement_speed modifier add magic_4b 0.075 add_value
attribute @s[scores={witchProg=81..90}] movement_speed modifier add magic_4b 0.0875 add_value
attribute @s[scores={witchProg=91..100}] movement_speed modifier add magic_4b 0.1 add_value
#时间
execute as @s[scores={witchProg=..60}] run schedule function magics:effection/4_cat/magic4b_end 15s
execute as @s[scores={witchProg=61..70}] run schedule function magics:effection/4_cat/magic4b_end 18.75s
execute as @s[scores={witchProg=71..80}] run schedule function magics:effection/4_cat/magic4b_end 22.5s
execute as @s[scores={witchProg=81..90}] run schedule function magics:effection/4_cat/magic4b_end 26.25s
execute as @s[scores={witchProg=91..100}] run schedule function magics:effection/4_cat/magic4b_end 30s

effect give @s invisibility 30 0 true
effect give @s resistance 30 100 true
effect give @s weakness 30 100 true

#体型
attribute @s scale modifier add magic_4b -0.85 add_value
#特效
particle cloud ~ ~ ~ 0.5 0.5 0.5 0 10 normal
#声音
execute as @s at @s run playsound entity.cat.stray_ambient ambient @a ~ ~ ~ 0.5
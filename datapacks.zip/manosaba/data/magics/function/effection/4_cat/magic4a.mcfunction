##组件头
#魔耗
scoreboard players remove @s MP 40
#cd
scoreboard players set @s cd1 8

##效果
#选择目标
tag @s add 4a
execute as @s[scores={magic2=0}] rotated ~37 0 as @e[distance=..6,tag=!4a,type=!cat] positioned \
    as @p[tag=4a,distance=..6] positioned ^-600 ^ ^-799 as @s[distance=1000..] \
    positioned ^600 ^ ^-799 as @s[distance=1000..] \
        run function magics:effection/4_cat/magic4a_damge_1

execute as @s[scores={magic2=1}] rotated ~37 0 as @e[distance=..6,tag=!4a,type=!cat] positioned \
    as @p[tag=4a,distance=..6] positioned ^-600 ^ ^-799 as @s[distance=1000..] \
    positioned ^600 ^ ^-799 as @s[distance=1000..] \
        run function magics:effection/4_cat/magic4a_damge_2


effect give @s night_vision infinite 0 true
attribute @s movement_speed modifier add magic_4a 0.05 add_value
schedule function magics:effection/4_cat/magic4a_speed 3s
execute as @s[scores={magic2=1}] run scoreboard players remove @s cd2 5
execute if entity @s[scores={cd2=..0}] run scoreboard players set @s cd2 1

#特效
particle angry_villager ~ ~3 ~ 0.5 0.5 0.5 0 5 normal
#声音
execute as @s at @s run playsound entity.cat.hiss ambient @a ~ ~ ~ 0.5
damage @s 2 player_attack by @p[tag=4a]
effect give @s slowness 3 2 false
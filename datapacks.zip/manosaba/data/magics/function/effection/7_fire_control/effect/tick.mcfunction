scoreboard players remove @a[tag=magic7_act] general_magic_duration 1
execute as @a[tag=magic7_act,scores={general_magic_duration=0}] run tag @s remove magic7_act

execute if entity @a[tag=magic7_act] run schedule function magics:effection/7_fire_control/effect/tick 1s
$scoreboard players set @s general_magic_duration $(duration)
tag @s add magic7_act
kill @e[type=item,distance=..5] 
execute if score @s magic2 matches 1 at @s as @e[type=mannequin,distance=..5] run damage @s 500 generic_kill
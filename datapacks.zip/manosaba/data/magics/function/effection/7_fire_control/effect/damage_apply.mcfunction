$execute as @a[nbt={last_hurt_by_player_memory_time:100,last_hurt_by_player:$(UUID)}] run damage @s $(damage) in_fire by @p[tag=attack_from]
$execute at @a[nbt={last_hurt_by_player_memory_time:100,last_hurt_by_player:$(UUID)}] run particle minecraft:flame ~ ~ ~ 0.6 1.2 0.6 0.1 30 normal

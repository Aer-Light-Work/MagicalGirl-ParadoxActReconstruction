advancement revoke @s only magics:7_fire_control/magic7a_effect

execute unless score @s magic2 matches 1 if entity @s[nbt={OnGround:1b}] store result storage magic:data damage float 1.1 run attribute @s attack_damage get
execute unless score @s magic2 matches 1 unless entity @s[nbt={OnGround:1b}] store result storage magic:data damage float 1.6 run attribute @s attack_damage get

execute if score @s magic2 matches 1 if entity @s[nbt={OnGround:1b}] store result storage magic:data damage float 1.5 run attribute @s attack_damage get
execute if score @s magic2 matches 1 unless entity @s[nbt={OnGround:1b}] store result storage magic:data damage float 2.3 run attribute @s attack_damage get

data modify storage magic:data UUID set from entity @s UUID
tag @a remove attack_from
tag @s add attack_from
function magics:effection/7_fire_control/effect/damage_apply with storage magic:data
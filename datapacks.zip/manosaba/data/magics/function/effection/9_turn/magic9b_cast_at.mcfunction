# 给目标实体添加标记，用于后续识别
tag @s add swap_target

# 在目标当前位置生成临时marker，记录目标位置
summon marker ~ ~0.2 ~ {Tags:["swap_target_pos"]}

# 在施法者位置生成临时marker，记录施法者位置  
execute as @p[tag=swap_user] at @s run summon marker ~ ~0.2 ~ {Tags:["swap_user_pos"]}

# 传送目标实体到施法者的原位置
execute as @e[type=marker,tag=swap_user_pos,limit=1] at @s run tp @e[tag=swap_target,limit=1] ~ ~ ~

# 传送施法者到目标的原位置
execute as @e[type=marker,tag=swap_target_pos,limit=1] at @s run tp @p[tag=swap_user] ~ ~ ~

# 清理标记和临时marker
tag @s remove swap_target
kill @e[type=marker,tag=swap_target_pos]
kill @e[type=marker,tag=swap_user_pos]

# 特效和声音
particle minecraft:portal ~ ~ ~ 0.5 1 0.5 0 20 force
execute as @p[tag=swap_user] at @s run particle minecraft:portal ~ ~ ~ 0.5 1 0.5 0 20 force
playsound entity.enderman.teleport ambient @a ~ ~ ~ 1.0
execute as @p[tag=swap_user] at @s run playsound entity.enderman.teleport ambient @a ~ ~ ~ 1.0
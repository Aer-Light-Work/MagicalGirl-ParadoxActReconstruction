##组件头
#魔耗
scoreboard players remove @s MP 60
#cd
scoreboard players set @s cd2 120

#初始化射线计数
scoreboard players set @s raycast_distance 0

tag @s add swap_user

execute at @s positioned ~ ~1.6 ~ run function magics:effection/9_turn/magic9b_cast_step
execute at @s run playsound minecraft:block.enchantment_table.use player @a[distance=..30] ~ ~ ~

tag @s remove swap_user
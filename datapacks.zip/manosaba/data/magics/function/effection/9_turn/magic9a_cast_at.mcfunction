

#effect give @s minecraft:wither 2 0
effect give @s minecraft:slowness 2 0
execute at @s run tp @s ~ ~ ~ ~180 ~


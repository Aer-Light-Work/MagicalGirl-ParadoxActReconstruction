##组件头
#魔耗
scoreboard players remove @s MP 5
#cd
scoreboard players set @s cd1 3

##效果
execute if entity @s[predicate=magics:8_invisibility/magic8a_uninv] run function magics:effection/8_invisibility/magic8a_uninv
execute if entity @s[predicate=!magics:8_invisibility/magic8a_uninv] run effect give @s speed 1 2 true
execute if entity @s[scores={magic2=1,cd2=1..}] run scoreboard players remove @s cd2 1
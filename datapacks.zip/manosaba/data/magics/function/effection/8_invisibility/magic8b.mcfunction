##组件头
#魔耗
scoreboard players remove @s MP 80
#cd
scoreboard players set @s cd2 180

##效果
function magics:effection/8_invisibility/magic8b_summon with entity @s

#时间
tag @s add 8b
execute as @s[scores={witchProg=..50}] run schedule function magics:effection/8_invisibility/magic8b_end 5s
execute as @s[scores={witchProg=51..60}] run schedule function magics:effection/8_invisibility/magic8b_end 6s
execute as @s[scores={witchProg=61..70}] run schedule function magics:effection/8_invisibility/magic8b_end 7s
execute as @s[scores={witchProg=71..80}] run schedule function magics:effection/8_invisibility/magic8b_end 8s
execute as @s[scores={witchProg=81..90}] run schedule function magics:effection/8_invisibility/magic8b_end 9s
execute as @s[scores={witchProg=91..100}] run schedule function magics:effection/8_invisibility/magic8b_end 10s
#buff
effect give @s invisibility 10 0 true
attribute @s movement_speed modifier add magic_8b 0.02 add_value

#返回
schedule function magics:magic_regive/8_invisibility/magic8c_regive 1t
tag @s add regive8c
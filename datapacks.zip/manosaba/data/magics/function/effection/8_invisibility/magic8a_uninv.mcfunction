tag @s add 8a

effect give @s invisibility infinite 0 true
effect give @s speed infinite 9 true
particle cloud ~ ~ ~ 0.5 0.5 0.5 0 10 normal

schedule function magics:effection/8_invisibility/magic8a_uninv_end 5t
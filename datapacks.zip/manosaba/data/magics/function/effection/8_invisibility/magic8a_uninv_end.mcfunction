effect clear @a[tag=8a] invisibility
effect clear @a[tag=8a] speed
execute at @a[tag=8a] run particle cloud ~ ~ ~ 0.5 0.5 0.5 0 10 normal

tag @a[tag=8a] remove 8a
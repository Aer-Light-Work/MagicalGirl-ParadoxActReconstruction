effect clear @a[tag=8b] invisibility
attribute @s movement_speed modifier remove magic_8b

kill @n[tag=8b_npc]

schedule function magics:magic_regive/8_invisibility/magic8b_regive 1t
tag @a[tag=8b] add regive8b

tag @a[tag=8b] remove 8b
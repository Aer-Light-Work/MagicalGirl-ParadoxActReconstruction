##组件头
#魔耗
scoreboard players remove @s MP 60
#cd
scoreboard players set @s cd1 20

##效果
#召唤魔力法阵block_display
summon block_display ~ ~0.1 ~ {Tags:["magic12a_circle"],data:{lifetime:200,owner_uuid:[I;0,0,0,0]},block_state:{Name:"minecraft:cyan_concrete"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-2f,-0.05f,-2f],scale:[4f,0.1f,4f]}}

#设置法阵的owner UUID
execute as @e[type=block_display,tag=magic12a_circle,distance=..5,limit=1,sort=nearest] run data modify entity @s data.owner_uuid set from entity @p[distance=..10] UUID

#启动法阵效果处理
execute if entity @e[type=block_display,tag=magic12a_circle] run schedule function magics:effection/12_charge/magic12a_tick 1t

#音效和粒子
playsound block.beacon.activate ambient @a ~ ~ ~ 1.0
playsound block.enchantment_table.use ambient @a ~ ~ ~ 0.8
particle enchant ~ ~1 ~ 2.0 0.5 2.0 0.5 50 force
particle end_rod ~ ~1 ~ 2.0 0.1 2.0 0.1 20 force
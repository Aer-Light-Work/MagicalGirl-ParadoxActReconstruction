##组件头
#魔耗
scoreboard players remove @s MP 80
#cd
scoreboard players set @s cd2 120

##效果
#给最近的玩家充能
execute as @p[distance=0.01..10] run scoreboard players add @s MP 100
execute as @p[distance=0.01..10] run effect give @s glowing 10 0
execute as @p[distance=0.01..10] run scoreboard players set @s cd1 1
execute as @p[distance=0.01..10] run scoreboard players set @s cd2 1

#音效和粒子
playsound entity.experience_orb.pickup ambient @a ~ ~ ~ 1.0
playsound block.beacon.power_select ambient @a ~ ~ ~ 0.8
particle happy_villager ~ ~1 ~ 1.0 1.0 1.0 0.2 30 force
particle enchant ~ ~1 ~ 1.0 1.0 1.0 0.3 40 force

#对目标玩家的特效
execute as @p[distance=0.01..10] at @s run particle end_rod ~ ~1 ~ 0.5 1.0 0.5 0.1 20 force
execute as @p[distance=0.01..10] at @s run playsound entity.player.levelup ambient @s ~ ~ ~ 0.5
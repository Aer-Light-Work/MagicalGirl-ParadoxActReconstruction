#减少生命周期
execute store result score #circle_lifetime raycast_distance run data get entity @s data.lifetime
scoreboard players remove #circle_lifetime raycast_distance 1
execute store result entity @s data.lifetime int 1 run scoreboard players get #circle_lifetime raycast_distance

#如果生命周期结束，移除法阵
execute if score #circle_lifetime raycast_distance matches ..0 run kill @s
execute if score #circle_lifetime raycast_distance matches ..0 run return 0

#每20tick(1秒)给范围内玩家回复MP - 使用取余运算
scoreboard players operation #circle_timer raycast_distance = #circle_lifetime raycast_distance
scoreboard players operation #circle_timer raycast_distance %= #20 raycast_distance
execute if score #circle_timer raycast_distance matches 0 run execute as @a[distance=..4] run scoreboard players add @s MP 4
execute if score #circle_timer raycast_distance matches 0 run execute as @a[distance=..4] run particle happy_villager ~ ~1 ~ 0.3 0.5 0.3 0.1 5 force

#法阵旋转效果
execute store result score #rotation raycast_distance run data get entity @s Rotation[0]
scoreboard players add #rotation raycast_distance 2
execute store result entity @s Rotation[0] float 1 run scoreboard players get #rotation raycast_distance

#法阵边缘特效
execute rotated ~0 0 positioned ^ ^ ^4 run particle end_rod ~ ~0.2 ~ 0.1 0.1 0.1 0.02 2 force

execute rotated ~90 0 positioned ^ ^ ^4 run particle end_rod ~ ~0.2 ~ 0.1 0.1 0.1 0.02 2 force

execute rotated ~180 0 positioned ^ ^ ^4 run particle end_rod ~ ~0.2 ~ 0.1 0.1 0.1 0.02 2 force

execute rotated ~270 0 positioned ^ ^ ^4 run particle end_rod ~ ~0.2 ~ 0.1 0.1 0.1 0.02 2 force


#中心光柱效果
particle enchant ~ ~1 ~ 0.5 0.5 0.5 0.1 3 force
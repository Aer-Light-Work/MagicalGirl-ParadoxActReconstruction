#12a魔力法阵tick处理
execute as @e[type=block_display,tag=magic12a_circle] at @s run function magics:effection/12_charge/magic12a_update

#只有当还有法阵存在时才继续调度
execute if entity @e[type=block_display,tag=magic12a_circle] run schedule function magics:effection/12_charge/magic12a_tick 1t
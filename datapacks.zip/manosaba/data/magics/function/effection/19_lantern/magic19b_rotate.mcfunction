# Magic 18b 法阵旋转效果 - 参考12a的旋转实现
# 每tick旋转2度

execute store result score #rotation raycast_distance run data get entity @s Rotation[0]
scoreboard players add #rotation raycast_distance 2
execute store result entity @s Rotation[0] float 1 run scoreboard players get #rotation raycast_distance

# 法阵边缘特效 - 四个方向的粒子
execute rotated ~0 0 positioned ^ ^ ^4 run particle soul ~ ~0.2 ~ 0.1 0.1 0.1 0.02 2 force

execute rotated ~90 0 positioned ^ ^ ^4 run particle soul ~ ~0.2 ~ 0.1 0.1 0.1 0.02 2 force

execute rotated ~180 0 positioned ^ ^ ^4 run particle soul ~ ~0.2 ~ 0.1 0.1 0.1 0.02 2 force

execute rotated ~270 0 positioned ^ ^ ^4 run particle soul ~ ~0.2 ~ 0.1 0.1 0.1 0.02 2 force

# 中心光柱效果
particle enchant ~ ~1 ~ 0.5 0.5 0.5 0.1 3 force

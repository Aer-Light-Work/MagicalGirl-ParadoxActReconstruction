##组件头
#魔耗
scoreboard players remove @s MP 80
#cd
scoreboard players set @s cd2 150

#召唤法阵block_display（正常显示在下方）
summon block_display ~ ~0.1 ~ {Tags:["magic19b_circle"],block_state:{Name:"minecraft:red_concrete_powder"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-2f,-0.05f,-2f],scale:[4f,0.1f,4f]}}

#简洁的法阵激活音效
playsound block.beacon.activate ambient @a[distance=..14] ~ ~ ~ 1.0
playsound entity.lightning_bolt.thunder ambient @a[distance=..6] ~ ~ ~ 0.4

#启动法阵旋转处理
execute if entity @e[type=block_display,tag=magic19b_circle] run schedule function magics:effection/19_lantern/magic19b_rotate_tick 1t

tag @s add magic19b_eat
#特效
particle glow ~ ~1 ~ 1 1 1 0 10 normal

schedule function magics:effection/19_lantern/magic19b_eat 5s


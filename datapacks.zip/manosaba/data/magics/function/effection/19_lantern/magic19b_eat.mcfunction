execute if entity @e[distance=0.01..5,type=minecraft:mannequin,tag=Corpse] run give @a[tag=magic19b_eat] minecraft:totem_of_undying

tag @a remove magic19b_eat

execute if entity @e[distance=0.01..5,type=minecraft:mannequin,tag=Corpse] run kill @n[distance=0..5,type=minecraft:mannequin,tag=Corpse]

#清理法阵block_display
kill @e[type=block_display,tag=magic19b_circle]

playsound entity.lightning_bolt.thunder ambient @a[distance=..10] ~ ~ ~ 0.5
#清理旋转调度
schedule clear magics:effection/19_lantern/magic19b_rotate_tick

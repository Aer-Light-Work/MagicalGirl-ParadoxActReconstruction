##组件头
#魔耗
scoreboard players remove @s MP 20
#cd
scoreboard players set @s cd1 15

##效果
#计算总玩家数（ready=1）
scoreboard players set @s lantern_total 0
execute as @a[scores={ready=1}] run scoreboard players add @p[tag=!19a] lantern_total 1
tag @s add 19a

#计算存活玩家数（ready=1 且 dead=0）
scoreboard players set @s lantern_alive 0
execute as @a[scores={ready=1,dead=0}] run scoreboard players add @p[tag=19a] lantern_alive 1

#显示存活玩家数量
tellraw @s [{text:"* "},{text:"存活玩家: ",color:gold},{score:{name:"@s",objective:"lantern_alive"},color:yellow},{text:"/",color:white},{score:{name:"@s",objective:"lantern_total"},color:yellow}]

#清理标签
tag @s remove 19a

#特效
particle glow_squid_ink ~ ~2 ~ 0.3 0.3 0.3 0 3 normal
#声音
execute as @s at @s run playsound block.lantern.place ambient @a ~ ~ ~ 0.5

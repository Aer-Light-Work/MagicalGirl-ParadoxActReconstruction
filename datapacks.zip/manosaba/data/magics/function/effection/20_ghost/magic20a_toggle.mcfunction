#检查当前状态并切换
execute if score @s ghost_state matches 0 run attribute @s minecraft:gravity base set 0
execute if score @s ghost_state matches 0 run effect give @s invisibility infinite 0 true
execute if score @s ghost_state matches 0 run tellraw @s [{"text":"[幽灵]","color":"#b0c4de","bold":true},{"text":" 已启用幽灵形态"}]
execute if score @s ghost_state matches 0 run particle cloud ~ ~1 ~ 0.3 0.3 0.3 0 5 normal

scoreboard players add @s ghost_state 1

execute if score @s ghost_state matches 2 run attribute @s minecraft:gravity base reset
execute if score @s ghost_state matches 2 run effect clear @s invisibility
execute if score @s ghost_state matches 2 run tellraw @s [{"text":"[幽灵]","color":"#b0c4de","bold":true},{"text":" 已禁用幽灵形态"}]
execute if score @s ghost_state matches 2 run particle cloud ~ ~1 ~ 0.3 0.3 0.3 0 5 normal
execute if score @s ghost_state matches 2 run effect give @s minecraft:slow_falling 4 1
execute if score @s ghost_state matches 2 run scoreboard players set @s ghost_state 0

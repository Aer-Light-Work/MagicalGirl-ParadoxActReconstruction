##组件头
#魔耗
scoreboard players remove @s MP 80
#cd
scoreboard players set @s cd1 3

##效果
#切换幽灵形态
function magics:effection/20_ghost/magic20a_toggle

#特效
particle cloud ~ ~1 ~ 0.5 0.5 0.5 0 10 normal

#声音
execute as @s at @s run playsound entity.phantom.flap ambient @a ~ ~ ~ 0.5



# 给目标实体添加标记
tag @s add ghost_target

# 设置目标生命值上限为1
attribute @s minecraft:max_health base set 1

# 特效和声音
particle soul ~ ~ ~ 0.5 1 0.5 0 20 force
playsound entity.wither.hurt ambient @a ~ ~ ~ 1.0

# 清理标记
tag @s remove ghost_target

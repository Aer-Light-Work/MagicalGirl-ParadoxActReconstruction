##组件头
#魔耗
scoreboard players remove @s MP 100
#cd
scoreboard players set @s cd2 999

##效果
#标记施法者
tag @s add ghost_caster

#给自己永久凋零效果
effect give @s wither infinite 0 true

#初始化射线计数
scoreboard players set @s raycast_distance 0

#从眼睛位置开始射线追踪
execute at @s positioned ~ ~1.6 ~ run function magics:effection/20_ghost/magic20b_cast_step

#特效
particle soul ~ ~1.6 ~ 0.5 0.5 0.5 0 10 normal

#声音
execute as @s at @s run playsound entity.wither.spawn ambient @a ~ ~ ~ 0.5

tag @s remove ghost_caster

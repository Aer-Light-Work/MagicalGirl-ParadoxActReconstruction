#根据颜色显示粒子
execute if score @s portal24_point_color matches 1 run particle dust{color:[1.0,0.6,0.0],scale:1.5} ~ ~ ~ 0.2 0.2 0.2 0.05 5 force
execute if score @s portal24_point_color matches 2 run particle dust{color:[0.0,0.6,1.0],scale:1.5} ~ ~ ~ 0.2 0.2 0.2 0.05 5 force

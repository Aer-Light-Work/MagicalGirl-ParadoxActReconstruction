##组件头
#魔耗
scoreboard players remove @s MP 70
#cd
scoreboard players set @s cd1 3

##效果
#确定光点颜色（交替橙色和蓝色）
scoreboard players add @s portal24_count 1

#设置颜色
execute if score @s portal24_count matches 1 run scoreboard players set @s portal24_color 1
execute if score @s portal24_count matches 2 run scoreboard players set @s portal24_color 2

#删除同颜色的旧光点（保证每种颜色只有一个）
execute if score @s portal24_color matches 1 run kill @e[type=armor_stand,tag=portal24_point,scores={portal24_point_color=1}]
execute if score @s portal24_color matches 2 run kill @e[type=armor_stand,tag=portal24_point,scores={portal24_point_color=2}]

#重置计数器（循环：1->2->1->2...）
execute if score @s portal24_count matches 2.. run scoreboard players set @s portal24_count 0

#在脚下生成新光点
summon armor_stand ~ ~ ~ {NoGravity:1b,Invisible:1b,Tags:["portal24_point"]}

#将光点的owner和color设置为玩家的num和color
execute as @e[type=armor_stand,tag=portal24_point,sort=nearest,limit=1] run scoreboard players operation @s portal24_owner = @p[sort=nearest] num
execute as @e[type=armor_stand,tag=portal24_point,sort=nearest,limit=1] run scoreboard players operation @s portal24_point_color = @p[sort=nearest] portal24_color

#特效
particle dust{color:[1.0,0.6,0.0],scale:2.0} ~ ~ ~ 0.3 0.3 0.3 0.1 20 force

#声音
execute as @s at @s run playsound entity.enderman.teleport ambient @a ~ ~ ~ 0.6

#启动tick循环
tag @s add portal24_active

schedule function magics:effection/24_portal/magic24_tick 1t

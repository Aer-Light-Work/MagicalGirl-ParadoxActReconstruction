##组件头
#魔耗
scoreboard players remove @s MP 85
#cd
scoreboard players set @s cd2 3

##效果
#确定光点颜色（交替橙色和蓝色）
scoreboard players add @s portal24_count 1

#设置颜色
execute if score @s portal24_count matches 1 run scoreboard players set @s portal24_color 1
execute if score @s portal24_count matches 2 run scoreboard players set @s portal24_color 2

#重置计数器（循环：1->2->1->2...）
execute if score @s portal24_count matches 2.. run scoreboard players set @s portal24_count 0

#启动raycast找到指向位置
tag @s add portal24_casting
function magics:effection/24_portal/magic24b_raycast

#特效
particle dust{color:[0.0,0.6,1.0],scale:2.0} ~ ~ ~ 0.3 0.3 0.3 0.1 20 force

#声音
execute as @s at @s run playsound entity.ender_eye.launch ambient @a ~ ~ ~ 0.6

#启动tick循环
tag @s add portal24_active
schedule function magics:effection/24_portal/magic24_tick 1t

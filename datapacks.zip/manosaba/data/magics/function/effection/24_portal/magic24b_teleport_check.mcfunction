#检测玩家是否在光点上且按shift
execute as @a[tag=portal24b_active] at @s if entity @e[type=armor_stand,tag=portal24b_point,distance=..1] if predicate manosaba:is_sneaking as @e[type=armor_stand,tag=portal24b_point,distance=..1] if score @s portal24_owner = @p[sort=nearest] num run function magics:effection/24_portal/magic24b_teleport_execute

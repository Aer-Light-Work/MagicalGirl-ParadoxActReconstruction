#初始化距离计数器（如果还没有）
execute unless score @s raycast_distance matches 0.. run scoreboard players set @s raycast_distance 0

#增加距离计数
scoreboard players add @s raycast_distance 1

#检测是否碰到方块
execute unless block ~ ~ ~ #minecraft:replaceable run function magics:effection/24_portal/magic24b_create_point
execute if score @s raycast_distance matches 51.. run function magics:effection/24_portal/magic24b_create_point

#如果没有碰到障碍物且距离未超限，继续前进
execute if block ~ ~ ~ #minecraft:replaceable if score @s raycast_distance matches ..50 positioned ^ ^ ^1 run function magics:effection/24_portal/magic24b_raycast_loop

#重置距离计数器
scoreboard players set @s raycast_distance 0

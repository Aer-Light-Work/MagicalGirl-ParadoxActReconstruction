#对所有有portal24_active标签的玩家执行检测
execute as @a[tag=portal24_active] at @s run function magics:effection/24_portal/magic24_check

#递减传送冷却
scoreboard players remove @a[scores={portal24_tp_cd=1..}] portal24_tp_cd 1

#检测玩家是否在光点附近且蹲下，且冷却为0，如果是则传送
execute as @a[predicate=manosaba:is_sneaking,scores={portal24_tp_cd=0}] at @s if entity @e[type=armor_stand,tag=portal24_point,distance=..2.4] run function magics:effection/24_portal/magic24_teleport

#如果还有portal24_active玩家，继续循环
execute if entity @a[tag=portal24_active] run schedule function magics:effection/24_portal/magic24_tick 1t

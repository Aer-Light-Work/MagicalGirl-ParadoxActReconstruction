#获取最近的光点颜色
scoreboard players operation @s temp_nearest_color = @e[type=armor_stand,tag=portal24_point,sort=nearest,limit=1] portal24_point_color

#根据最近光点的颜色，找到另一个颜色的光点并传送
#如果最近的是橙色(1)，传送到蓝色(2)
execute if score @s temp_nearest_color matches 1 at @e[type=armor_stand,tag=portal24_point,scores={portal24_point_color=2},sort=nearest,limit=1] run tp @s ~ ~ ~

#如果最近的是蓝色(2)，传送到橙色(1)
execute if score @s temp_nearest_color matches 2 at @e[type=armor_stand,tag=portal24_point,scores={portal24_point_color=1},sort=nearest,limit=1] run tp @s ~ ~ ~

#传送特效
particle minecraft:portal ~ ~ ~ 0.5 0.5 0.5 1 20 force

#传送音效
execute at @s run playsound entity.enderman.teleport ambient @a ~ ~ ~ 1

#设置传送冷却（8tick）
scoreboard players set @s portal24_tp_cd 12

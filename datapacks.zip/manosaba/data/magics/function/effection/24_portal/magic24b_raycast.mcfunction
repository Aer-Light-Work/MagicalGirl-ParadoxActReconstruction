#raycast找到指向位置（最多50格）
execute as @s[tag=portal24_casting] anchored eyes positioned ^ ^ ^1 run function magics:effection/24_portal/magic24b_raycast_loop

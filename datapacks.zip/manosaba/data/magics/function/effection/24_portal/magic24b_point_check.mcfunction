#增加CD计时器
scoreboard players add @s portal24b_tp_cd 1

#根据CD显示粒子
execute if score @s portal24b_tp_cd matches 0 as @s run particle dust{color:[0.0,0.6,1.0],scale:1.5} ~ ~ ~ 0.2 0.2 0.2 0.05 5 force
execute if score @s portal24b_tp_cd matches 1.. as @s run particle dust{color:[1.0,0.0,0.0],scale:1.5} ~ ~ ~ 0.2 0.2 0.2 0.05 5 force

#CD计时（40tick = 2秒）
execute if score @s portal24b_tp_cd matches 40.. run scoreboard players set @s portal24b_tp_cd 0

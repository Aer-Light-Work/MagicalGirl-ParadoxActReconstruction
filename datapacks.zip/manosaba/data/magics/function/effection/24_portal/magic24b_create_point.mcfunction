#删除同颜色的旧光点（保证每种颜色只有一个）
execute if score @s portal24_color matches 1 run kill @e[type=armor_stand,tag=portal24_point,scores={portal24_point_color=1}]
execute if score @s portal24_color matches 2 run kill @e[type=armor_stand,tag=portal24_point,scores={portal24_point_color=2}]

#根据玩家视角生成光点
#仰头（pitch < 0）：生成在下方
execute if entity @s[x_rotation=-90..-1] run summon armor_stand ~ ~-2 ~ {NoGravity:1b,Invisible:1b,Tags:["portal24_point"]}

#低头（pitch > 0）：生成在上方
execute if entity @s[x_rotation=1..90] run summon armor_stand ~ ~1 ~ {NoGravity:1b,Invisible:1b,Tags:["portal24_point"]}

#水平视角（pitch = 0）：生成在原位置
execute if entity @s[x_rotation=0] run summon armor_stand ~ ~ ~ {NoGravity:1b,Invisible:1b,Tags:["portal24_point"]}

#将光点的owner和color设置为玩家的num和color
execute as @e[type=armor_stand,tag=portal24_point,sort=nearest,limit=1] run scoreboard players operation @s portal24_owner = @p[sort=nearest] num
execute as @e[type=armor_stand,tag=portal24_point,sort=nearest,limit=1] run scoreboard players operation @s portal24_point_color = @p[sort=nearest] portal24_color

#移除casting标签
tag @s remove portal24_casting

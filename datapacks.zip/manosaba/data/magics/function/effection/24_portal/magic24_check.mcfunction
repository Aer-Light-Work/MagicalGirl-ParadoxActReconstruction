#光点持续显示粒子
execute as @e[type=armor_stand,tag=portal24_point] at @s run function magics:effection/24_portal/magic24_particle

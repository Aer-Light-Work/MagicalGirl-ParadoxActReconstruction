#因子球消失特效
particle dust{color:[1.0,0.0,0.0],scale:1.5} ~ ~ ~ 0.6 0.6 0.6 0.2 20 force
particle soul ~ ~ ~ 0.5 0.5 0.5 0.1 10 force

#移除标签并杀死实体
tag @s remove magic22a_orb_active
kill @s

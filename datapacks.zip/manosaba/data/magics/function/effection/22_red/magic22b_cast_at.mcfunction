#对指向的玩家施加诅咒
#根据目标魔女化程度施加诅咒效果

#基础效果 - 失明
effect give @s blindness 5 0 true

#中等诅咒 - 凋零
execute if score @s witchProg matches 50.. run effect give @s wither 10 0 true
execute if score @s witchProg matches 50.. run effect give @s blindness 10 0 true
execute if score @s witchProg matches 50.. run particle dust{color:[0.5,0.0,0.0],scale:1.0} ~ ~ ~ 0.4 0.4 0.4 0.1 10 force

execute if score @s witchProg matches 80.. run scoreboard players add @s cd1 20
execute if score @s witchProg matches 80.. run scoreboard players add @s cd2 20
execute if score @s witchProg matches 80.. run particle dust{color:[1.0,0.0,0.0],scale:1.0} ~ ~ ~ 0.7 0.7 0.7 0.1 20 force
#特效
particle soul ~ ~ ~ 0.5 1 0.5 0 20 force


#声音
playsound minecraft:entity.elder_guardian.curse player @s ~ ~ ~ 1 0.95

#提示信息
execute if score @s witchProg matches ..49 run tellraw @s [{text:"✗ "},{text:"你被施加了诅咒！",color:"#8b0000",bold:true},{text:" [失明]",color:gray}]
execute if score @s witchProg matches 50..79 run tellraw @s [{text:"✗ "},{text:"你被施加了诅咒！",color:"#8b0000",bold:true},{text:" [失明+凋零]",color:gray}]
execute if score @s witchProg matches 80.. run tellraw @s [{text:"✗ "},{text:"你被施加了诅咒！",color:"#8b0000",bold:true},{text:" [失明+凋零+魔法抑制]",color:"#ff0000",bold:true}]

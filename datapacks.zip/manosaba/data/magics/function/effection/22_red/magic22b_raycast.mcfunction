#射线追踪 - 找到指向的玩家
#初始化射线计数
scoreboard players set @s raycast_distance 0

execute at @s positioned ~ ~1.6 ~ run function magics:effection/22_red/magic22b_cast_step

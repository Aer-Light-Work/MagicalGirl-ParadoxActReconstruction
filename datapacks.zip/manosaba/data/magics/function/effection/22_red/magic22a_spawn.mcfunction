#生成因子球 - marker实体
summon marker ~ ~ ~ {Tags:["magic22a_orb","magic22a_orb_active"],data:{lifetime:200}}

#启动tick循环
schedule function magics:effection/22_red/magic22a_tick 1t

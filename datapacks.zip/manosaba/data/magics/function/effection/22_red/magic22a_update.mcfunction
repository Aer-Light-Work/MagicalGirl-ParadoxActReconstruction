#减少生命周期
execute store result score #orb_lifetime raycast_distance run data get entity @s data.lifetime
scoreboard players remove #orb_lifetime raycast_distance 1
execute store result entity @s data.lifetime int 1 run scoreboard players get #orb_lifetime raycast_distance

#如果生命周期结束，移除球
execute if score #orb_lifetime raycast_distance matches ..0 run function magics:effection/22_red/magic22a_end
execute if score #orb_lifetime raycast_distance matches ..0 run return 0

#对附近玩家增加缓慢效果
execute as @a[distance=..5] run effect give @s slowness 3 0 true

#生成因子球粒子特效
particle dust{color:[1.0,1.0,1.0],scale:1.0} ~ ~ ~ 0.4 0.4 0.4 0.1 8 force
particle soul ~ ~ ~ 0.3 0.3 0.3 0.05 3 force

#每1.5秒一次 (每30 tick) 的效果
scoreboard players operation #temp raycast_distance = #orb_lifetime raycast_distance
scoreboard players operation #temp raycast_distance %= #30 raycast_distance
execute if score #temp raycast_distance matches 0 as @a[distance=..5] run scoreboard players remove @s[scores={witchProg=1..,role=1}] dwitchProg 1
execute if score #temp raycast_distance matches 0 as @a[distance=..5] run scoreboard players remove @s[scores={witchProg=1..,role=2}] dwitchProg 1
execute if score #temp raycast_distance matches 0 as @a[distance=..5] run scoreboard players remove @s[scores={witchProg=1..,role=4}] dwitchProg 1


execute if score #temp raycast_distance matches 0 run playsound entity.elder_guardian.hurt ambient @a ~ ~ ~ 0.5 1.0

#小爆炸特效 (每30 tick)
execute if score #temp raycast_distance matches 0 run particle explosion ~ ~ ~ 0.3 0.3 0.3 0.1 3 force
## awa
execute if score #temp raycast_distance matches 0 run particle flame ~ ~ ~ 0.5 0.5 0.5 0.05 5 force
execute if score #temp raycast_distance matches 0 run particle smoke ~ ~ ~ 0.4 0.4 0.4 0.08 4 force


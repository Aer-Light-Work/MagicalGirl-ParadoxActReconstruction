#生成追踪粒子
particle dust{color:[1.0,1.0,1.0],scale:0.8} ~ ~ ~ 0.2 0.2 0.2 0.05 3 force

#检查是否碰到方块，如果碰到则生成因子球
execute unless block ~ ~ ~ #minecraft:air run function magics:effection/22_red/magic22a_spawn
execute unless block ~ ~ ~ #minecraft:air run return 0

#增加射线计数
scoreboard players add @s raycast_distance 1

#检查是否达到12格距离上限
execute if score @s raycast_distance matches 12.. run function magics:effection/22_red/magic22a_spawn
execute if score @s raycast_distance matches 12.. run return 0

#如果没有碰到障碍物，继续前进
execute positioned ^ ^ ^1 run function magics:effection/22_red/magic22a_cast_step

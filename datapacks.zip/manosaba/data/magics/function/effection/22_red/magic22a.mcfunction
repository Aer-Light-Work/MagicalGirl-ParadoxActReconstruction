##组件头
#魔耗
scoreboard players remove @s MP 70
#cd
scoreboard players set @s cd1 8

##效果 - 在玩家视线指向位置生成因子球
# 执行raycast找到最终位置
execute as @s at @s anchored eyes run function magics:effection/22_red/magic22a_raycast

#特效
particle dust{color:[1.0,1.0,1.0],scale:1.5} ~ ~1.5 ~ 0.5 0.5 0.5 0 15 normal
#声音
execute as @s at @s run playsound block.beacon.activate ambient @a ~ ~ ~ 0.5
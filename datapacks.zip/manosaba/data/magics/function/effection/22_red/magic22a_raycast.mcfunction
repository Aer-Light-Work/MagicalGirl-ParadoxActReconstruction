#射线追踪 - 找到指向位置
#初始化射线计数
scoreboard players set @s raycast_distance 0

execute at @s positioned ~ ~1.6 ~ run function magics:effection/22_red/magic22a_cast_step

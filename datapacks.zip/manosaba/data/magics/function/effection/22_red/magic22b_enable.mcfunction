#移除禁用技能标签
tag @s remove magic22b_disabled

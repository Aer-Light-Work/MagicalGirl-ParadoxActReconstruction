#因子球tick处理 - 只在有球时运行
execute as @e[type=marker,tag=magic22a_orb_active] at @s run function magics:effection/22_red/magic22a_update

#只有当还有球存在时才继续调度
execute if entity @e[type=marker,tag=magic22a_orb_active] run schedule function magics:effection/22_red/magic22a_tick 1t

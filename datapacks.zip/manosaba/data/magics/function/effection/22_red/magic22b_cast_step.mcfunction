#生成追踪粒子
particle dust{color:[0.5,0.0,0.0],scale:0.8} ~ ~ ~ 0.2 0.2 0.2 0.05 3 force

#检查是否有玩家（排除施法者和非玩家实体），如果有则施加诅咒
execute positioned ~-0.5 ~-0.5 ~-0.5 if entity @a[dx=0,dy=0,dz=0,tag=!curse_user] run scoreboard players add @s raycast_distance 128
execute positioned ~-0.5 ~-0.5 ~-0.5 as @a[dx=0,dy=0,dz=0,tag=!curse_user] run function magics:effection/22_red/magic22b_cast_at

#增加射线计数
scoreboard players add @s raycast_distance 1

#检查是否碰到方块（障碍物）
execute unless block ~ ~ ~ #minecraft:air run return 0

#检查是否达到12格距离上限
execute if score @s raycast_distance matches 30.. run return 0

#如果没有找到玩家，继续前进
execute positioned ^ ^ ^1 run function magics:effection/22_red/magic22b_cast_step

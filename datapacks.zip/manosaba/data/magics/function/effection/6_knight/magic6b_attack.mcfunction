##效果
summon minecraft:falling_block ~ ~3 ~ {\
    BlockState:{Name:"red_banner"},\
    CancelDrop:true,\
    data:{knight:attack}}
summon block_display ~ ~3 ~ {block_state:{Name:red_banner},data:{knight:attack},Glowing:true,glow_color_override:12910592,interpolation_duration:20,transformation:{right_rotation:{angle:0,axis:[0,0,0]},scale:[1.7,1.7,1.7],left_rotation:{angle:0,axis:[0,0,0]},translation:[-0.85,-0.6,-0.85]}}
summon armor_stand ~ ~1 ~ \
    {\
        Invisible:true,\
        NoGravity:true,\
        DisabledSlots:16191,\
        data:{knight:attack},\
        Rotation:[0,0],\
        attributes:[{id:scale,base:0.01}],\
    }

function magics:effection/6_knight/magic6b_attack_tick
#声音
execute as @s at @s run playsound item.goat_horn.sound.2 ambient @a ~ ~ ~ 0.5
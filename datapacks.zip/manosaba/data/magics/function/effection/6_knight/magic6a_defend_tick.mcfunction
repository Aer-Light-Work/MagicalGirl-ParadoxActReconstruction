execute as @a[tag=6a_defend] run effect give @s absorption infinite 0 true
execute as @a[tag=6a_defend] run effect clear @s absorption

schedule function magics:effection/6_knight/magic6a_defend_tick 1t
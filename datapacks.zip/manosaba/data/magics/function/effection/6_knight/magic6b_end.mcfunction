execute at @n[type=block_display,nbt={data:{knight:attack}}] run playsound entity.item.break ambient @a ~ ~ ~ 0.5
execute at @n[type=block_display,nbt={data:{knight:defend}}] run playsound entity.item.break ambient @a ~ ~ ~ 0.5

kill @e[nbt={data:{knight:attack}}]
kill @e[nbt={data:{knight:defend}}]

schedule clear magics:effection/6_knight/magic6b_attack_tick
schedule clear magics:effection/6_knight/magic6b_defend_tick
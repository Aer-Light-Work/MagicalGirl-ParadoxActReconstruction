##组件头
#魔耗
scoreboard players remove @s MP 10
#cd
scoreboard players set @s cd1 30

##效果
#清除
attribute @s max_absorption modifier remove magic_6a_defend
tag @s remove 6a_defend
schedule clear magics:effection/6_knight/magic6a_defend_tick

#添加
schedule function magics:magic_regive/6_knight/magic6a_regive_attack 1t
tag @s add regive6a_attack

tellraw @s [{text:"* "},{text:"当前造成的伤害始终增加一点",color:"#ff1717"}]
attribute @s attack_damage modifier add magic_6a_attack 1 add_value
tag @s add 6a_attack
#声音
execute as @s at @s run playsound block.smithing_table.use ambient @a ~ ~ ~ 0.5
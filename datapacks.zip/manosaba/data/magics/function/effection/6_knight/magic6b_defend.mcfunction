##效果
summon minecraft:falling_block ~ ~3 ~ {\
    BlockState:{Name:"yellow_banner"},\
    CancelDrop:true,\
    data:{knight:defend}}
summon block_display ~ ~3 ~ {block_state:{Name:yellow_banner},data:{knight:defend},Glowing:true,glow_color_override:16771584,interpolation_duration:20,transformation:{right_rotation:{angle:0,axis:[0,0,0]},scale:[1.7,1.7,1.7],left_rotation:{angle:0,axis:[0,0,0]},translation:[-0.85,-0.6,-0.85]}}
summon armor_stand ~ ~1 ~ \
    {\
        Invisible:true,\
        NoGravity:true,\
        DisabledSlots:16191,\
        data:{knight:defend},\
        Rotation:[0,0],\
        attributes:[{id:scale,base:0.01}],\
    }

function magics:effection/6_knight/magic6b_defend_tick
#声音
execute as @s at @s run playsound item.goat_horn.sound.6 ambient @a ~ ~ ~ 0.5
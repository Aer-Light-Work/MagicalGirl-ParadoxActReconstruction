##组件头
#魔耗
scoreboard players remove @s MP 100
#cd
scoreboard players set @s cd2 150

##效果
execute as @s[tag=6a_attack] run function magics:effection/6_knight/magic6b_attack
execute as @s[tag=6a_defend] run function magics:effection/6_knight/magic6b_defend
#时间
execute as @s[scores={witchProg=..60}] run schedule function magics:effection/6_knight/magic6b_end 10s
execute as @s[scores={witchProg=61..70}] run schedule function magics:effection/6_knight/magic6b_end 11.25s
execute as @s[scores={witchProg=71..80}] run schedule function magics:effection/6_knight/magic6b_end 12.5s
execute as @s[scores={witchProg=81..90}] run schedule function magics:effection/6_knight/magic6b_end 13.75s
execute as @s[scores={witchProg=91..100}] run schedule function magics:effection/6_knight/magic6b_end 15s
##动画展示
#位置调整
execute at @n[type=falling_block,nbt={data:{knight:attack}}] run tp @n[type=block_display,nbt={data:{knight:attack}}] ~ ~1 ~
tp @n[type=armor_stand,nbt={data:{knight:attack}}] @n[type=falling_block,nbt={data:{knight:attack}}]
#旋转
execute at @e[type=armor_stand,nbt={data:{knight:attack}}] as @n[type=armor_stand,nbt={data:{knight:attack}}] run rotate @s ~5 ~
#粒子
execute at @e[type=armor_stand,nbt={data:{knight:attack}}] run \
     particle dust{color:12910592,scale:1} ^ ^ ^5 0.1 0.1 0.1 0 1 normal
execute at @e[type=armor_stand,nbt={data:{knight:attack}}] run \
     particle dust{color:12910592,scale:1} ^ ^ ^-5 0.1 0.1 0.1 0 1 normal
execute at @e[type=armor_stand,nbt={data:{knight:attack}}] run \
     particle dust{color:12910592,scale:1} ^5 ^ ^ 0.1 0.1 0.1 0 1 normal
execute at @e[type=armor_stand,nbt={data:{knight:attack}}] run \
     particle dust{color:12910592,scale:1} ^-5 ^ ^ 0.1 0.1 0.1 0 1 normal

##效果
execute at @e[type=armor_stand,nbt={data:{knight:attack}}] run effect give @a[distance=..5,tag=6a_attack] strength 1 2
execute at @e[type=armor_stand,nbt={data:{knight:attack}}] run effect give @a[distance=..5,tag=!6a_attack] weakness 1 0
execute at @e[type=armor_stand,nbt={data:{knight:attack}}] run effect give @a[distance=..5,tag=!6a_attack] slowness 1 0



schedule function magics:effection/6_knight/magic6b_attack_tick 1t
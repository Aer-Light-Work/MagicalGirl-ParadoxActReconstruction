##动画展示
#位置调整
execute at @n[type=falling_block,nbt={data:{knight:defend}}] run tp @n[type=block_display,nbt={data:{knight:defend}}] ~ ~1 ~
tp @n[type=armor_stand,nbt={data:{knight:defend}}] @n[type=block_display,nbt={data:{knight:defend}}]
#旋转
execute at @e[type=armor_stand,nbt={data:{knight:defend}}] as @n[type=armor_stand,nbt={data:{knight:defend}}] run rotate @s ~5 ~
#粒子
execute at @e[type=armor_stand,nbt={data:{knight:defend}}] run \
     particle dust{color:16771584,scale:1} ^ ^ ^5 0.1 0.1 0.1 0 1 normal
execute at @e[type=armor_stand,nbt={data:{knight:defend}}] run \
     particle dust{color:16771584,scale:1} ^ ^ ^-5 0.1 0.1 0.1 0 1 normal
execute at @e[type=armor_stand,nbt={data:{knight:defend}}] run \
     particle dust{color:16771584,scale:1} ^5 ^ ^ 0.1 0.1 0.1 0 1 normal
execute at @e[type=armor_stand,nbt={data:{knight:defend}}] run \
     particle dust{color:16771584,scale:1} ^-5 ^ ^ 0.1 0.1 0.1 0 1 normal

##效果
execute at @e[type=armor_stand,nbt={data:{knight:defend}}] run effect give @a[distance=..5,tag=6a_defend] resistance 1 2
execute at @e[type=armor_stand,nbt={data:{knight:defend}}] run effect give @a[distance=..5,tag=!6a_defend] weakness 1 0
execute at @e[type=armor_stand,nbt={data:{knight:defend}}] run effect give @a[distance=..5,tag=!6a_defend] slowness 1 0

schedule function magics:effection/6_knight/magic6b_defend_tick 1t
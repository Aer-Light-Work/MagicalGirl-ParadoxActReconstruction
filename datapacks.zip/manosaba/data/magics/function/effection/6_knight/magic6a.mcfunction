##组件头
#魔耗
scoreboard players remove @s MP 30
#cd
scoreboard players set @s cd1 5

##效果
#添加
schedule function magics:magic_regive/6_knight/magic6a_regive_defend 1t
tag @s add regive6a_defend

attribute @s max_absorption modifier add magic_6a_defend 1 add_value
tag @s add 6a_defend
function magics:effection/6_knight/magic6a_defend_tick

#声音
execute as @s at @s run playsound block.smithing_table.use ambient @a ~ ~ ~ 0.5
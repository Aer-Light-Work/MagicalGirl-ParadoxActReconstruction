execute as @a[tag=undead] run scoreboard players remove @s undead 1

#特效
execute at @a[tag=undead] run particle totem_of_undying ~ ~1.5 ~ 2 1 2 0 60
#声音
execute at @a[tag=undead] run playsound item.totem.use ambient @a ~ ~ ~ 0.5

#受伤状态重置
execute as @a[tag=undead] run function damage:damage_reset

execute as @a[tag=undead] run effect give @s resistance 5 4 false
execute as @a[tag=undead] run tellraw @s [{text:"* "},{text:"恩典发挥了他最后一抹力量...",color:"dark_red"}]
execute as @a[tag=undead] run tag @s remove undead
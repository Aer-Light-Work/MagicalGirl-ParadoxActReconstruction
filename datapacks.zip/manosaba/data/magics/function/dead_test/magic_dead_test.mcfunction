#本函数返回值为0时，直接阻止死亡组件推进  eg:
#execute if entity @s[scores={role=1}] run return 0
#本函数返回值为1时，死亡组件继续向下推进  eg:
#execute if entity @s[scores={role=2}] run return 1

#魔法5亡语检查
execute as @s[tag=5a_give,scores={magic2=1,MP=280..,cd2=0,judging=0}] run function magics:effection/5_witch/magic5b





#自动拦截大于等于一的undead数量
execute if entity @s[scores={undead=1..}] run scoreboard players set @s deadtest 0
execute if entity @s[scores={undead=1..}] run tag @s add undead
execute if entity @s[scores={undead=1..}] run schedule function magics:dead_test/dead_effection/undead 1t
execute if entity @s[scores={undead=1..}] run return 0
#其他通过
return 1
scoreboard objectives add appearance_type dummy
scoreboard objectives add appearance_num dummy
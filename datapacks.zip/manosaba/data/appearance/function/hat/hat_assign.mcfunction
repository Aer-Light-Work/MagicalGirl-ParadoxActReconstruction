
execute if score @s appearance_num matches 1 run function appearance:hat/televison_hat
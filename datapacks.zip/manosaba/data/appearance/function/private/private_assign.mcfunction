
execute if score @s appearance_num matches 1 run return run function appearance:private/sprake_hat

execute if score @s appearance_num matches 2 run return run function appearance:private/lyza_hat

execute if score @s appearance_num matches 3 run return run function appearance:private/tiroaw_hat

execute if score @s appearance_num matches 4 run return run function appearance:private/jingua_hat

execute if score @s appearance_num matches 5 run return run function appearance:private/chenlin_hat

execute if score @s appearance_num matches 6 run return run function appearance:private/mu_cat_ear

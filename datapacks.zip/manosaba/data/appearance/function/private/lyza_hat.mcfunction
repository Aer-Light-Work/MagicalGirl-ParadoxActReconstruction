item modify entity @s armor.head appearance:private/lyza_hat
execute unless entity @s[nbt={active_effects:[{id:"minecraft:invisibility"}]}] \
unless predicate appearance:private/lyza_hat run item replace entity @s armor.head with light_gray_stained_glass_pane[custom_name="装饰物",equippable={slot:'head'}]
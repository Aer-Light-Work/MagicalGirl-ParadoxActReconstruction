
execute if score @s appearance_num matches 1 run return run function appearance:appearance_frame/appearance_wear {"item_model":"manosaba:sprakehat"}

execute if score @s appearance_num matches 2 run return run function appearance:appearance_frame/appearance_wear {"item_model":"manosaba:lyza_hat"}

execute if score @s appearance_num matches 3 run return run function appearance:appearance_frame/appearance_wear {"item_model":"manosaba:tiroawhat"}

execute if score @s appearance_num matches 4 run return run function appearance:appearance_frame/appearance_wear {"item_model":"manosaba:mu_cat_ear"}

execute if score @s appearance_num matches 5 run return run function appearance:appearance_frame/appearance_wear {"item_model":"manosaba:jingua_hat"}

execute if score @s appearance_num matches 6 run return run function appearance:appearance_frame/appearance_wear {"item_model":"manosaba:chenlin_hat"}

execute if score @s appearance_num matches 7 run return run function appearance:appearance_frame/appearance_wear {"item_model":"manosaba:pupgpu33hat"}

execute if score @s appearance_num matches 8 run return run function appearance:appearance_frame/appearance_wear {"item_model":"manosaba:skadi_hat"}

advancement revoke @s only appearance:appearance
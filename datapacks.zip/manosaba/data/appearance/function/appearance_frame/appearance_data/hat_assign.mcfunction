
execute if score @s appearance_num matches 1 run function appearance:appearance_frame/appearance_wear {"item_model":"manosaba:television"}

advancement revoke @s only appearance:appearance
tag @s remove appearance
scoreboard players set @s appearance_type 0
scoreboard players set @s appearance_type 0
function appearance:appearance_frame/appearance_reset/head
clear @s light_gray_stained_glass_pane[custom_name="装饰物"]
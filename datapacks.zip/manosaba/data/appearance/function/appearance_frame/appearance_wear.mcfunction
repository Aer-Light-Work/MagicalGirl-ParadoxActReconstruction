#替换头部装饰
$item modify entity @s armor.head {\
    "function": "set_components",\
    "components": {\
        "item_model": "$(item_model)",\
        "equippable": {\
            "slot": "head"\
        },\
        "custom_data":{"appearance":1}\
    }\
}

$execute unless entity @s[nbt={active_effects:[{id:"minecraft:invisibility"}]}] unless predicate {\
    "condition": "entity_properties",\
    "entity": "this",\
    "predicate": {\
        "equipment": {\
            "head": {\
                "components": {\
                    "item_model": "$(item_model)"\
                }\
            }\
        }\
    }\
} run item replace entity @s armor.head with light_gray_stained_glass_pane[custom_name="装饰物",equippable={slot:'head'}]

advancement revoke @s only appearance:appearance
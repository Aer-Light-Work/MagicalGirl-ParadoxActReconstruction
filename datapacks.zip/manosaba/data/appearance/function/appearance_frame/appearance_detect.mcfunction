#清除指针
execute unless items entity @s armor.head light_gray_stained_glass_pane[custom_name="装饰物"] run clear @s light_gray_stained_glass_pane[custom_name="装饰物"]
execute if predicate appearance:slot_test/cursor_test run function appearance:appearance_frame/appearance_reset/cursor
execute if predicate appearance:slot_test/mainhand_test run function appearance:appearance_frame/appearance_reset/mainhand
execute if predicate appearance:slot_test/offhand_test run function appearance:appearance_frame/appearance_reset/offhand

execute if entity @s[nbt={active_effects:[{id:"minecraft:invisibility"}]}] run clear @s light_gray_stained_glass_pane[custom_name="装饰物"]
#分类
execute if score @s appearance_type matches 1 run return run function appearance:appearance_frame/appearance_data/private_assign

execute if score @s appearance_type matches 2 run return run function appearance:appearance_frame/appearance_data/hat_assign

advancement revoke @s only appearance:appearance
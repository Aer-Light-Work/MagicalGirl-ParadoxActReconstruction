item replace block 1029 43 999 container.0 from entity @s weapon.offhand
data modify block 1029 43 999 Items[0].components."minecraft:item_model" set from block 1029 43 999 Items[0].id
item replace entity @s weapon.offhand from block 1029 43 999 container.0
item modify entity @s weapon.offhand appearance:cursor_reset
item replace block 1029 43 999 container.0 from entity @s weapon.mainhand
data modify block 1029 43 999 Items[0].components."minecraft:item_model" set from block 1029 43 999 Items[0].id
item replace entity @s weapon.mainhand from block 1029 43 999 container.0
item modify entity @s weapon.mainhand appearance:cursor_reset
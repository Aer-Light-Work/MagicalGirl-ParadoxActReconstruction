item replace block 1029 43 999 container.0 from entity @s armor.head
data modify block 1029 43 999 Items[0].components."minecraft:item_model" set from block 1029 43 999 Items[0].id
item replace entity @s armor.head from block 1029 43 999 container.0
item modify entity @s armor.head appearance:cursor_reset
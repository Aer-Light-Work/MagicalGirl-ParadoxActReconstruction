tag @s add appearance
$scoreboard players set @s appearance_type $(type)
$scoreboard players set @s appearance_num $(num)
return 1
##范例
function appearance:appearance_frame/appearance_give {"type":1,"num":1}
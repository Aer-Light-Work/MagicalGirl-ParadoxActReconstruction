#minus
schedule clear lobby:game_start/minus_progress
scoreboard players set #lobby:start lobby_minus 0
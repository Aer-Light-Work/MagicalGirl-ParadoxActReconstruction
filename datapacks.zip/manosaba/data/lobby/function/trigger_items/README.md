
背包道具定义在 lobby_inv_effect 函数里
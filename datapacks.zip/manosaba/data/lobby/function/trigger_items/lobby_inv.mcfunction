#func
execute as @a[tag=lobby_inv_reset] run function lobby:trigger_items/lobby_inv_effect
#advancement reset
advancement revoke @a[tag=lobby_inv_reset] only manosaba:inv_monitor
#temp tag -
tag @a remove lobby_inv_reset

##给新进玩家加上准备道具
execute if score manosaba:data Gaming matches 0 as @a[gamemode=adventure] unless items entity @s hotbar.4 book run function manosaba:framework/players/inventory/inv_lobby
#自调用
execute if score manosaba:data Gaming matches 0 run schedule function lobby:trigger_items/inv_test_progress 1s
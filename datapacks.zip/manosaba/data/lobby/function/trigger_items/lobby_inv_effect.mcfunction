#condition
execute if score @s Playing matches 1.. run return fail
##item
#准备道具
execute unless score @s ready matches 0..1 run function lobby:trigger_items/item/ready
execute if score @s ready matches 0 run function lobby:trigger_items/item/ready
execute if score @s ready matches 1 run function lobby:trigger_items/item/unready
#开始游戏
execute if score #lobby:start lobby_minus matches 1.. run function lobby:trigger_items/item/unstart
execute if score #lobby:start lobby_minus matches 0 run function lobby:trigger_items/item/start
#小游戏

#教程
function lobby:trigger_items/item/tutorial1
#kill item
kill @e[type=item,nbt={Item:{components:{"minecraft:item_name":"noDrop"}}}]

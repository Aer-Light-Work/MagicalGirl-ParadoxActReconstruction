#admin
scoreboard players set @s isAdmin 1
#text
tellraw @s [{text:"*  ",color:white,italic:false},{text:"检验成功，请再次使用道具开始游戏\n",color:green,italic:true}]
#sound
execute as @s at @s run playsound manosaba:notice ambient @s ~ ~ ~ 0.3
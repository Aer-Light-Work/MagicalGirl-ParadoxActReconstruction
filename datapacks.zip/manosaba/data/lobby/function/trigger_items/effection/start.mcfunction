#advancement reset
advancement revoke @s only lobby:start
#return
execute if score manosaba:data Gaming matches 1 run return fail
#sound
execute as @a at @s run playsound ui.cartography_table.take_result ambient @a ~ ~ ~ 1 1.2

#condition
execute unless score @s isAdmin matches 1 run return run tellraw @s [{text:"*  ",color:white,italic:false},{text:"请确认所有玩家都已准备，且你具备命令权限\n",color:gold,italic:true},{text:"【我确认】",color:green,bold:true,italic:false,underlined:true,click_event:{action:"run_command",command:"/function lobby:trigger_items/effection/permission_check"}}]

##msg
#calc
execute as @a[scores={ready=1}] run scoreboard players add #lobby:ready alive 1
#msg
execute unless score #lobby:ready alive matches 4.. run tellraw @s [{text:"*  ",color:white,italic:false},{text:"至少需要四名玩家才可开始游戏！",color:red,italic:true}]
execute unless score #lobby:ready alive matches 4.. run playsound manosaba:illegal ambient @s ~ ~ ~ 1
#score reset
execute unless score #lobby:ready alive matches 4.. run return run scoreboard players set #lobby:ready alive 0
scoreboard players set #lobby:ready alive 0

#text
tellraw @a [{text:"*  ",color:white,italic:false},{text:"倒计时已开始",color:gold,italic:true},{text:"    *操作者:",color:gray,italic:true},{selector:"@s",color:gray,italic:true},{text:"*",color:gray,italic:true}]

#item
function lobby:trigger_items/item/unstart
execute as @a[gamemode=adventure] run function lobby:trigger_items/item/unstart

#start minus
function lobby:game_start/minus_start
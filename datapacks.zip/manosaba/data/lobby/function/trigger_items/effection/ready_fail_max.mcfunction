
#item
function lobby:trigger_items/item/ready

#sound
execute as @s at @s run playsound manosaba:illegal ambient @s ~ ~ ~ 1

#text
tellraw @s [{text:"*  ",color:white,bold:false,italic:false},{text:"加入失败，准备队列已满！",color:red,bold:false,italic:false}]

#score reset
scoreboard players set #lobby:online alive 0
scoreboard players set #lobby:readycheck alive 0
scoreboard players set #lobby:ready alive 0
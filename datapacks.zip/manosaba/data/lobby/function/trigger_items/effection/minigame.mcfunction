#advanment reset
advancement revoke @s only lobby:minigame
#score
scoreboard players set @s Playing 2
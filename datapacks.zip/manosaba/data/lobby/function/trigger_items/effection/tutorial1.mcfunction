#advancement reset
advancement revoke @s only lobby:tutorial1
#func
function lobby:tutorials/tutorial_1/tutorial1_start
#advancement reset
advancement revoke @s only lobby:spect
#condition
execute if score manosaba:data Gaming matches 1 if entity @s[scores={ready=1,dead=1},team=!Dead] run playsound manosaba:illegal ambient @s ~ ~ ~ 1
execute if score manosaba:data Gaming matches 1 if entity @s[scores={ready=1,dead=1},team=!Dead] run return run tellraw @s [{text:"* ",color:white,italic:false},{text:" 您当前为未确认死亡状态，无法进入观战状态，耐心等到下次开庭吧~",color:red,italic:true}]
execute if score manosaba:data Gaming matches 0 run return fail
#gamemode
gamemode spectator @s
#spect
spectate @r[scores={ready=1,dead=0}]
#sound
execute as @s at @s run playsound block.portal.travel ambient @s ~ ~ ~ 0.1 1
##开始游戏大厅倒数
#score
scoreboard players set #lobby:start lobby_minus 15
#func
function lobby:game_start/minus_progress
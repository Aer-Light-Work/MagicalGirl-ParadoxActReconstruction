##自调用进程

#title time
title @a times 0 21 0

#sound
execute if score #lobby:start lobby_minus matches 12..15 run function lobby:game_start/sounds/pitch1
execute if score #lobby:start lobby_minus matches 8..11 run function lobby:game_start/sounds/pitch2
execute if score #lobby:start lobby_minus matches 4..7 run function lobby:game_start/sounds/pitch3
execute if score #lobby:start lobby_minus matches 2..3 run function lobby:game_start/sounds/pitch4
execute if score #lobby:start lobby_minus matches 1 run function lobby:game_start/sounds/pitch5

execute if score #lobby:start lobby_minus matches 11 as @a at @s run playsound manosaba:button_charge ambient @s ~ ~ ~ 0.3
execute if score #lobby:start lobby_minus matches 1 as @a at @s run playsound manosaba:botton ambient @s ~ ~ ~ 0.358

#title
title @a title ""
title @a subtitle [{text:"『囚庭演定』 ",color:"#ED777F",italic:false,bold:true},{text:"将在  ",color:"yellow",italic:false,bold:false},{score:{name:"#lobby:start",objective:"lobby_minus"},color:"red",italic:false,bold:false},{text:"  秒后开始，请尽快准备！",color:"yellow",italic:false,bold:false}]
execute if score #lobby:start lobby_minus matches 12..15 run title @a actionbar [{text:"[  虚拟场景构建中...  ]",color:red}]
execute if score #lobby:start lobby_minus matches 8..11 run title @a actionbar [{text:"[ 交互项目生成中...  ]",color:gold}]
execute if score #lobby:start lobby_minus matches 4..7 run title @a actionbar [{text:"[  参演信息导入中...  ]",color:yellow}]
execute if score #lobby:start lobby_minus matches 2..3 run title @a actionbar [{text:"[  神经网络接入中...  ]",color:green}]
execute if score #lobby:start lobby_minus matches 1 run title @a actionbar [{text:"[  演定实例构建完毕！  ]",color:dark_green}]

#stat lock
execute if score #lobby:start lobby_minus matches 2 run scoreboard players set manosaba:data Gaming -1

#func game_start
execute if score #lobby:start lobby_minus matches 1 run schedule function manosaba:game/game_start 1s

#item kill
execute if score #lobby:start lobby_minus matches 1 run schedule function lobby:trigger_items/item_kill 1t

#score --
scoreboard players remove #lobby:start lobby_minus 1

#自调用
execute if score #lobby:start lobby_minus matches 1.. run schedule function lobby:game_start/minus_progress 1s
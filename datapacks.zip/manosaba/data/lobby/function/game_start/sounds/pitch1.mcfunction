execute as @a at @s run playsound block.note_block.basedrum ambient @s ~ ~ ~ 0.3 0.529732
execute as @a at @s run playsound block.note_block.pling ambient @s ~ ~ ~ 0.5 0.529732
execute as @a at @s run playsound block.note_block.pling ambient @s ~ ~ ~ 0.5 0.707107


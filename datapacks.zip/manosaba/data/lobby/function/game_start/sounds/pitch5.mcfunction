execute as @a at @s run playsound block.note_block.basedrum ambient @s ~ ~ ~ 0.3 0.529732
execute as @a at @s run playsound block.note_block.pling ambient @s ~ ~ ~ 0.5 1.059463
execute as @a at @s run playsound block.note_block.pling ambient @s ~ ~ ~ 0.5 1.414214
execute as @a at @s run playsound block.note_block.pling ambient @s ~ ~ ~ 0.5 1.781797
execute as @a at @s run playsound block.note_block.bit ambient @s ~ ~ ~ 0.5 1.781797
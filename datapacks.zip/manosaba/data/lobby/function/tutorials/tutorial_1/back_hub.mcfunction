#team leave
team leave @a[tag=BackHubDelay]

#hub
execute as @a[tag=BackHubDelay] run function manosaba:spectator/spectator_hub

#tag -
tag @a remove BackHubDelay
##cam4

#cam switch
execute as @s run spectate @e[type=cow,tag=tutorial1,limit=1,tag=cam4]

execute if score @s tutorialT matches 9 run effect give @s darkness 4 0 true

#sound
execute as @s at @s run playsound manosaba:owl ambient @s ~ ~ ~ 0.5

execute if score @s tutorialT matches 9 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 当一具",color:yellow,bold:false},\
    {text:"『未确认死亡』",color:gray,bold:true,underlined:true,hover_event:{action:"show_text",value:{text:"在进入魔女审判前，玩家列表无法看到有哪些玩家已经死亡，这些玩家即为未确认死亡状态",color:"#FFA0C9",italic:true}}},\
    {text:"的玩家遗体",color:yellow,bold:false},\
    {text:"被任意玩家调查",color:red,bold:false},\
    {text:"时，将暂停所有任务，进入",color:yellow,bold:false},\
    {text:"『调查阶段』\n",color:light_purple,bold:true,underlined:true,hover_event:{action:"show_text",value:{text:"持续 4min 的无任务自由活动阶段，可进行证据搜集，亦可进行杀人灭口...",color:"#FFA0C9",italic:true}}},\
    {text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 8 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 调查阶段时玩家需要勘察现场，搜集线索，分析案件细节，持续4分钟\n",color:yellow,bold:false},{text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 7 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 随后便会召开",color:yellow,bold:false},\
    {text:"『魔女审判』",color:red,bold:false},\
    {text:"，届时所有存活玩家会被传唤至审判庭，此时玩家列表中能够看到",color:yellow,bold:false},\
    {text:"『已死亡玩家』\n",color:dark_red,bold:true,underlined:true,hover_event:{action:"show_text",value:{text:"已死亡玩家的尸体再被发现时不再触发调查阶段",color:"#FFA0C9",italic:true}}},{text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 6 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 在庭上，玩家需要讨论出可能的凶手，并利用每轮讨论的投票环节",color:yellow,bold:false},\
    {text:"票选出嫌疑人\n",color:red,bold:false},\
    {text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 5 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 在庭审过程中",color:yellow,bold:false},\
    {text:"累积最高得票两次",color:red,bold:false},\
    {text:"的玩家/",color:yellow,bold:false},\
    {text:"超时投票中最高得票",color:red,bold:false},\
    {text:"的玩家将被",color:yellow,bold:false},\
    {text:"『处刑』\n",color:dark_red,bold:false},\
    {text:" ",color:yellow,bold:false}\
]
#sound
execute as @s at @s run playsound entity.player.levelup ambient @s ~ ~ ~ 0.3 0.8

#title
title @s times 30 200 30
title @s subtitle [{text:"Acacia   原著",color:white,bold:true}]
title @s title [{text:"缘",color:"#FF75B1",bold:true},{text:"梦",color:"#A87AFC",bold:true},{text:"织",color:"#FCF283",bold:true},{text:"绘",color:"#83FCB4",bold:true},{text:"   出品",color:white,bold:true}]
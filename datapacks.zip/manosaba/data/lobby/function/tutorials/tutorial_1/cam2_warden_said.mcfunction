##cam2

#cam switch
execute as @s run spectate @e[type=cow,tag=tutorial1,limit=1,tag=cam2]

#sound
execute as @s at @s run playsound manosaba:owl ambient @s ~ ~ ~ 0.5

execute if score @s tutorialT matches 27 run effect give @s darkness 4 0 true

execute if score @s tutorialT matches 27 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 接下来介绍玩家的",color:yellow,bold:false},\
    {text:"基本属性\n",color:light_purple,bold:false},\
    {text:" ",color:yellow,bold:false},\
]

execute if score @s tutorialT matches 26 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 在游戏开始时每名玩家会随机获取一组",color:yellow,bold:false},{text:" ",color:yellow,bold:false},\
    {text:"不重复的魔法\n",color:yellow,bold:true},{text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 25 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 除了被选为",color:yellow,bold:false},\
    {text:"『魔女阵营』",color:"#FFD2E9",bold:false},\
    {text:"的玩家外，每组魔法的",color:yellow,bold:false},\
    {text:"第二技能",color:gold,bold:false},\
    {text:"初始为",color:yellow,bold:false},\
    {text:"锁定状态\n",color:red,bold:false},{text:" ",color:yellow,bold:false},\
]

execute if score @s tutorialT matches 24 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 需要意志力低于一定程度后才可解锁\n",color:yellow,bold:false},{text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 23 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 玩家使用魔法需要消耗魔力值，魔力值的",color:yellow,bold:false},\
    {text:"『自然恢复上限』",color:"aqua",bold:true,underlined:true,hover_event:{action:"show_text",value:{text:"玩家魔力值小于100时，每秒可恢复4点MP，魔力值上无封顶",color:"#FFA0C9",italic:true}}},\
    {text:"为",color:yellow,bold:false},\
    {text:" 100",color:red,bold:true},\
    {text:"\n ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 22 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 除了魔法以外，玩家还有",color:yellow,bold:false},\
    {text:"一定概率",color:light_purple,bold:false},\
    {text:"能够从",color:yellow,bold:false},\
    {text:"三项天赋",color:gold,bold:false},\
    {text:"中选择一项，获得一些",color:yellow,bold:false},\
    {text:"特殊的效果\n",color:red,bold:false},\
    {text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 21 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 意志力则会",color:yellow,bold:false},\
    {text:"实时",color:red,bold:false},\
    {text:"根据玩家的游戏行为进行改变\n",color:yellow,bold:false},\
    {text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 20 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 意志力降至50%以下时",color:gold,bold:false},\
    {text:"，便会开始概率受到",color:yellow,bold:false},\
    {text:"『低意志影响』",color:dark_purple,bold:true,underlined:true,hover_event:{action:"show_text",value:{text:"概率获得各种匪夷所思的debuff，意志力越低概率越高，影响越严重",color:"#FFA0C9",italic:true}}},\
    {text:"，",color:yellow,bold:false},\
    {text:"『预备魔女』",color:"aqua",bold:false},\
    {text:"还有可能转化为",color:yellow,bold:false},\
    {text:"『杀意魔女』\n",color:dark_red,bold:false},{text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 19 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 不过，",color:yellow,bold:false},\
    {text:"意志力低",color:red,bold:false},\
    {text:"也会使得大部分",color:yellow,bold:false},\
    {text:"魔法的效果得到强化",color:gold,bold:false},\
    {text:"，意志力越低，魔法效果越强\n",color:yellow,bold:false},\
    {text:" ",color:yellow,bold:false}\
]


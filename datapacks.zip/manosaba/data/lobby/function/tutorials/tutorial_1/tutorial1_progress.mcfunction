##自调用组件 -3s

##34 music
execute as @a[scores={tutorialT=34}] at @s run playsound manosaba:opening ambient @s ~ ~ ~ 0.05

##warden_said
#cam1
execute as @a[scores={tutorialT=28..36}] run function lobby:tutorials/tutorial_1/cam1_warden_said
#cam2
execute as @a[scores={tutorialT=19..27}] run function lobby:tutorials/tutorial_1/cam2_warden_said
#cam3
execute as @a[scores={tutorialT=10..18}] run function lobby:tutorials/tutorial_1/cam3_warden_said
#cam4
execute as @a[scores={tutorialT=5..9}] run function lobby:tutorials/tutorial_1/cam4_warden_said
#cam5
execute as @a[scores={tutorialT=1..4}] run function lobby:tutorials/tutorial_1/cam5_warden_said

#title end
execute as @a[scores={tutorialT=1}] run function lobby:tutorials/tutorial_1/tutorial1_end_title

#score --
scoreboard players remove @a[scores={tutorialT=1..}] tutorialT 1

##hub回大厅
#actionbar
title @a[gamemode=spectator,scores={tutorialT=1..}] actionbar [{text:"输入  ",color:yellow},{text:"/trigger hub",color:red},{text:"  以退出教程",color:yellow}]

#观察者返回大厅
scoreboard players enable @a[gamemode=spectator,scores={tutorialT=1..}] hub
execute as @a[gamemode=spectator,scores={hub=1,tutorialT=1..}] run team leave @s
execute as @a[gamemode=spectator,scores={hub=1,tutorialT=1..}] run function manosaba:spectator/spectator_hub

#自调用
execute if entity @a[scores={tutorialT=1..}] run schedule function lobby:tutorials/tutorial_1/tutorial1_progress 3s replace
#legal check
execute if entity @s[scores={ready=1,dead=0}] run tellraw @s [{text:"*  ",color:white,italic:false},{text:"你处于准备状态，无法进入教程，请先取消准备！",color:red,italic:true},]
execute if entity @s[scores={ready=1,dead=0}] run return run playsound manosaba:illegal ambient @s ~ ~ ~ 1

#progress start
execute unless entity @a[scores={tutorialT=1..}] run schedule function lobby:tutorials/tutorial_1/tutorial1_progress 1t replace

#effect
effect give @s blindness 7 0 true
effect give @s darkness 7 0 true

#gamemode
tp @s 0 0 0

#team join
team join tutorial1 @s

#stopsound
stopsound @s

#score
scoreboard players set @s tutorialT 36

##cam3

#cam switch
execute as @s run spectate @e[type=cow,tag=tutorial1,limit=1,tag=cam3]

execute if score @s tutorialT matches 18 run effect give @s darkness 4 0 true

#sound
execute as @s at @s run playsound manosaba:owl ambient @s ~ ~ ~ 0.5

execute if score @s tutorialT matches 18 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 接下来是地图的探索系统\n",color:yellow,bold:false},{text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 17 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 游戏开始后，手持",color:yellow,bold:false},{text:" ",color:yellow,bold:false},\
    {text:"快捷栏中的地图",color:green,bold:false},{text:" ",color:yellow,bold:false},\
    {text:"即可查看地图，",color:yellow,bold:false},{text:" ",color:yellow,bold:false},\
    {text:"单击右键",color:red,bold:false},{text:" ",color:yellow,bold:false},\
    {text:"以切换地图位面\n",color:yellow,bold:false},{text:" ",color:yellow,bold:false},\
]
execute if score @s tutorialT matches 17 as @e[type=item_display,tag=map] at @s run particle dust{color:[1.0,1.0,0.5],scale:1.5} ~ ~0.2 ~ 0.45 0.45 0.45 2 32 force @a[scores={tutorialT=17}]

execute if score @s tutorialT matches 16 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 所有玩家都会收到",color:yellow,bold:false},\
    {text:"随机分配的日常任务",color:gold,bold:false},\
    {text:"，完成即可获得相应的奖励，预备魔女还",color:yellow,bold:false},\
    {text:"可获得越狱进度值\n",color:green,bold:false},\
    {text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 15 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 关于与",color:yellow,bold:false},\
    {text:"场景的交互",color:aqua,bold:false},\
    {text:"，你需要记住\n",color:yellow,bold:false},\
    {text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 14 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 快捷栏中的放大镜为地图交互道具，对准可交互点",color:yellow,bold:false},\
    {text:"『长按右键』",color:gold,bold:true,underlined:true,hover_event:{action:"show_text",value:{text:"有时交互点在例如木桶等可被右键的方块上时\n按下shift即可正常使用放大镜",color:"#FFA0C9",italic:true}}},\
    {text:"即可",color:yellow,bold:false},\
    {text:"调查",color:blue,bold:false},\
    {text:"该交互点\n",color:yellow,bold:false},\
    {text:" ",color:yellow,bold:false}\
]
execute if score @s tutorialT matches 14 as @e[type=item_display,tag=magnify] at @s run particle dust{color:[1.0,0.8,0.3],scale:2} ~ ~0.2 ~ 0.45 0.45 0.45 1.5 32 force @a[scores={tutorialT=14}]

execute if score @s tutorialT matches 13 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 地图中的",color:yellow,bold:false},\
    {text:"可交互点/物件",color:gold,bold:false},\
    {text:"将会以",color:yellow,bold:false},\
    {text:"发光点",color:red,bold:false},\
    {text:"的形式标记\n",color:yellow,bold:false},\
    {text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 12 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 另外，靠近玩家死亡后留下的遗体",color:yellow,bold:false},\
    {text:"打开背包",color:red,bold:false},\
    {text:"，点击背包中的",color:yellow,bold:false},\
    {text:"搜索遗体物品",color:light_purple,bold:false},\
    {text:"即可搜索遗体物品\n",color:yellow,bold:false},\
    {text:" ",color:yellow,bold:false}\
]
execute if score @s tutorialT matches 12 as @e[type=item_display,tag=search] at @s run particle dust{color:[0.75,0,0],scale:1.5} ~ ~0.2 ~ 0.45 0.45 0.45 2 32 force @a[scores={tutorialT=12}]


execute if score @s tutorialT matches 11 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 探索得到的各种饰品能够放进背包中",color:yellow,bold:false},\
    {text:"对应颜色的",color:gold,bold:false},\
    {text:"『饰品栏』",color:red,bold:false},\
    {text:"，以获得对应饰品效果\n",color:yellow,bold:false},\
    {text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 10 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 调查可调查掉落物 ",color:yellow,bold:false},\
    {text:"(如针管、损坏的武器等) ",color:gray,bold:false},\
    {text:"得到的",color:yellow,bold:false},\
    {text:"线索道具",color:blue,bold:false},\
    {text:"能够存入背包中的",color:yellow,bold:false},\
    {text:"『线索栏』",color:aqua,bold:false},\
    {text:"中，在庭审环节时",color:yellow,bold:false},\
    {text:"打开背包单击",color:red,bold:false},\
    {text:"即可出示\n",color:yellow,bold:false},\
    {text:" ",color:yellow,bold:false}\
]
execute if score @s tutorialT matches 10 as @e[type=item_display,tag=clues] at @s run particle dust{color:[0.0,0.0,1.0],scale:1.5} ~ ~0.2 ~ 0.45 0.45 0.45 2 32 force @a[scores={tutorialT=10}]

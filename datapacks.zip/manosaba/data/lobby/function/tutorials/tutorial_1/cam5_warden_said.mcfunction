##cam5

#cam switch
execute as @s run spectate @e[type=cow,tag=tutorial1,limit=1,tag=cam5]

execute if score @s tutorialT matches 4 run effect give @s darkness 4 0 true

#sound
execute as @s at @s run playsound manosaba:owl ambient @s ~ ~ ~ 0.5

execute if score @s tutorialT matches 4 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 『囚庭演定』",color:"#ED777F",bold:true},\
    {text:" 便是这样一个以你的视角，经历一次次的案件、一次次审判，并亲自走到一切尽头的故事...\n",color:yellow,bold:false},{text:" ",color:yellow,bold:false}\
]

execute if score @s tutorialT matches 3 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 玩家出局后，",color:yellow,bold:false},{text:" ",color:yellow,bold:false},\
    {text:"除了观赏",color:yellow,bold:false},{text:" ",color:red,bold:false},\
    {text:"这场荒谬的『悖演』外\n",color:yellow,bold:false},{text:" ",color:yellow,bold:false},\
]

execute if score @s tutorialT matches 2 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 亦可在大厅通过参与",color:yellow,bold:false},\
    {text:"『悖演间憩』",color:light_purple,bold:true,underlined:true,hover_event:{action:"show_text",value:{text:"一些趣味小游戏，胜者能够获得悖演残响奖励",color:"#FFA0C9",italic:true}}},\
    {text:"获取",color:yellow,bold:false},\
    {text:"『悖演残响』",color:dark_purple,bold:false},\
    {text:"，以购买一些",color:yellow,bold:false},\
    {text:"『超自然力量』",color:white,bold:true,underlined:true,hover_event:{action:"show_text",value:{text:"能够以各种形式干涉局内玩家，该功能整体偏趣味性",color:"#FFA0C9",italic:true}}},\
    {text:"，干涉局内仍存活的玩家\n",color:yellow,bold:false},{text:" ",color:yellow,bold:false},\
]

execute if score @s tutorialT matches 1 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:"啊...下班时间到了呢，那么我就先告辞了...\n ",color:yellow,bold:false},{text:" ",color:yellow,bold:false}\
]
execute if score @s tutorialT matches 1 run effect give @s darkness 5 0 true
execute if score @s tutorialT matches 1 run effect give @s blindness 5 0 true
execute if score @s tutorialT matches 1 run tag @s add BackHubDelay
execute if score @s tutorialT matches 1 run schedule function lobby:tutorials/tutorial_1/back_hub 3s
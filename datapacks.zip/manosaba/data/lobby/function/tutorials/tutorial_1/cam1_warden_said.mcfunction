##cam1

#gamemode
execute if score @s tutorialT matches 35 run gamemode spectator @s
#cam switch
execute as @s run spectate @e[type=cow,tag=tutorial1,limit=1,tag=cam1]

#sound
execute as @s at @s run playsound manosaba:owl ambient @s ~ ~ ~ 0.5

execute if score @s tutorialT matches 36 run tellraw @s [\
    {text:"\n ",color:yellow,bold:false},\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 咳咳...\n",color:yellow,bold:false},\
    {text:" ",color:yellow,bold:false},\
]

execute if score @s tutorialT matches 35 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 下面就让我这可爱的猫头鹰来给你介绍一下",color:yellow,bold:false},\
    {text:"『囚庭演定』",color:"#ED777F",bold:true},\
    {text:"玩法吧\n",color:yellow,bold:false},\
]

execute if score @s tutorialT matches 35 run tellraw @s [\
    {text:"   (将指针悬停在带有 ",color:red,bold:false},\
    {text:"下划线",color:yellow,bold:true,underlined:true,hover_event:{action:"show_text",value:{text:"...你很上道嘛",color:gray,italic:true}}},\
    {text:" 的文本上能够看到其注释)\n",color:red,bold:false,underlined:false},\
    {text:" ",color:yellow,bold:false},\
]

execute if score @s tutorialT matches 34 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 在 『囚庭演定』 中，一共有三个阵营，",color:yellow,bold:false},\
    {text:"『魔女阵营』",color:"#FFD2E9",bold:false},\
    {text:"、",color:yellow,bold:false},\
    {text:"『预备魔女阵营』",color:aqua,bold:false},\
    {text:"、",color:yellow,bold:false},\
    {text:"『杀意魔女阵营』\n",color:dark_red,bold:false},\
    {text:" ",color:yellow,bold:false},\
]
execute if score @s tutorialT matches 34 as @e[type=item_display,tag=role1] at @s run particle dust{color:[0.0,0.0,1.0],scale:1.5} ~ ~0.2 ~ 0.45 0.45 0.45 2 32 force @a[scores={tutorialT=34}]
execute if score @s tutorialT matches 34 as @e[type=item_display,tag=role23] at @s run particle dust{color:[1.0,0.8,0.8],scale:1.5} ~ ~0.2 ~ 0.45 0.45 0.45 2 32 force @a[scores={tutorialT=34}]
execute if score @s tutorialT matches 34 as @e[type=item_display,tag=role4] at @s run particle dust{color:[1.0,0.0,0.0],scale:1.5} ~ ~0.2 ~ 0.45 0.45 0.45 2 32 force @a[scores={tutorialT=34}]

execute if score @s tutorialT matches 33 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 『魔女阵营』中分为",color:yellow,bold:false},\
    {text:"『魔女』",color:"#FFD2E9",bold:false},\
    {text:"与",color:yellow,bold:false},\
    {text:"『共犯』",color:gold,bold:false},\
    {text:"两种身份",color:yellow,bold:false},\
    {text:"\n ",color:yellow,bold:false},\
]
execute if score @s tutorialT matches 33 as @e[type=item_display,tag=role23] at @s run particle dust{color:[1.0,0.8,0.8],scale:1.5} ~ ~0.2 ~ 0.45 0.45 0.45 2 32 force @a[scores={tutorialT=33}]

execute if score @s tutorialT matches 32 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 『魔女』",color:"#FFD2E9",bold:false},\
    {text:" 在游戏开始 ",color:yellow,bold:false},\
    {text:"3",color:red,bold:false},\
    {text:" min 后可获得一把 ",color:yellow,bold:false},\
    {text:"『仪礼剑』",color:"red",bold:true,underlined:true,hover_event:{action:"show_text",value:{text:"冷却3分钟，主动激活后可作为武器使用10秒，20攻击力，有攻击冷却",color:"#FFA0C9",italic:true}}},\
    {text:"，而",color:yellow,bold:false},\
    {text:" 『共犯』",color:"gold",bold:false},\
    {text:"无自带的攻击手段\n",color:yellow,bold:false},\
    {text:" ",color:yellow,bold:false},\
]

execute if score @s tutorialT matches 31 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 『魔女阵营』的获胜目标是将所有",color:yellow,bold:false},\
    {text:"非本阵营的玩家",color:gold,bold:false},\
    {text:"全部杀死",color:red,bold:false},\
    {text:"，真是残忍呢，呵呵...\n",color:yellow,bold:false},\
    {text:" ",color:yellow,bold:false},\
]
execute if score @s tutorialT matches 31 as @e[type=item_display,tag=role23] at @s run particle dust{color:[1.0,0.8,0.8],scale:1.5} ~ ~0.2 ~ 0.45 0.45 0.45 2 32 force @a[scores={tutorialT=31}]

execute if score @s tutorialT matches 30 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 『预备魔女』",color:"aqua",bold:false},\
    {text:"阵营的获胜目标是完成地图中的任务，获取的",color:yellow,bold:false},\
    {text:"越狱进度达到100%",color:gold,bold:false},\
    {text:"；亦或是场上",color:yellow,bold:false},\
    {text:"不再存在其它两个阵营的玩家",color:red,bold:false},\
    {text:"时获胜\n",color:yellow,bold:false},\
    {text:" "}\
]
execute if score @s tutorialT matches 30 as @e[type=item_display,tag=role1] at @s run particle dust{color:[0.0,0.0,1.0],scale:1.5} ~ ~0.2 ~ 0.45 0.45 0.45 2 32 force @a[scores={tutorialT=30}]

execute if score @s tutorialT matches 29 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 『杀意魔女』",color:"dark_red",bold:false},\
    {text:"由低",color:yellow,bold:false},\
    {text:"『意志力』",color:"#986077",bold:true,underlined:true,hover_event:{action:"show_text",value:{text:"玩家基础属性，玩家经历可影响其数值，之后会详述",color:"#FFA0C9",italic:true}}},\
    {text:"的",color:yellow,bold:false},\
    {text:" 『预备魔女』",color:"aqua",bold:false},\
    {text:"概率转化而来\n",color:yellow,bold:false},\
    {text:" ",color:yellow,bold:false},\
]
execute if score @s tutorialT matches 29 as @e[type=item_display,tag=role4] at @s run particle dust{color:[1.0,0.0,0.0],scale:1.5} ~ ~0.2 ~ 0.45 0.45 0.45 2 32 force @a[scores={tutorialT=29}]

execute if score @s tutorialT matches 28 run tellraw @s [\
    {text:"[",color:gold,bold:false},{text:" 典狱长 ",color:white,bold:true},{text:"] ",color:gold,bold:false},\
    {text:" 其获胜目标是",color:yellow,bold:false},\
    {text:"杀死除了自己以外的所有玩家\n",color:red,bold:false},\
    {text:" ",color:yellow,bold:false},\
]

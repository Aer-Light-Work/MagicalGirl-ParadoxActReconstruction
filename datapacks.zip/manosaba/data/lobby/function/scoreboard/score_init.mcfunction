#start_minus
scoreboard objectives add lobby_minus dummy


#hub
scoreboard objectives add hub trigger
